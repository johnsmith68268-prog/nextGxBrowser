(() => {
var __webpack_modules__ = ({
"./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js"(module, __unused_webpack_exports, __webpack_require__) {
/* module decorator */ module = __webpack_require__.nmd(module);
(function (global, factory) {
  if (typeof define === "function" && define.amd) {
    define("webextension-polyfill", ["module"], factory);
  } else if (true) {
    factory(module);
  } else { var mod }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.12.0 - Tue May 14 2024 18:01:29 */
  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */
  /* vim: set sts=2 sw=2 et tw=80: */
  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
    throw new Error("This script should only be loaded in a browser extension.");
  }
  if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";

    // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.
    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };
      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }

      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */
      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }
        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }
          return super.get(key);
        }
      }

      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */
      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };

      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */
      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };
      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";

      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */
      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }
          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }
          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args);

                // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.
                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };

      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */
      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }
        });
      };
      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);

      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */
      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },
          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }
            if (!(prop in target)) {
              return undefined;
            }
            let value = target[prop];
            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.

              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,
                get() {
                  return target[prop];
                },
                set(value) {
                  target[prop] = value;
                }
              });
              return value;
            }
            cache[prop] = value;
            return value;
          },
          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }
            return true;
          },
          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },
          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }
        };

        // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.
        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };

      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */
      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },
        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },
        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }
      });
      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }

        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */
        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {} /* wrappers */, {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      });
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }

        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */
        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;
          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }
          const isResultThenable = result !== true && isThenable(result);

          // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.
          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          }

          // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).
          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;
              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }
              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          };

          // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.
          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          }

          // Let Chrome know that the listener is replying.
          return true;
        };
      });
      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };
      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }
        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }
        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };
      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };

    // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.
    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = globalThis.browser;
  }
});


},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
id: moduleId,
loaded: false,
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);

// Flag the module as loaded
module.loaded = true;
// Return the exports of the module
return module.exports;

}

// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/node_module_decorator
(() => {
__webpack_require__.nmd = (module) => {
  module.paths = [];
  if (!module.children) module.children = [];
  return module;
};
})();
// webpack/runtime/rspack_version
(() => {
__webpack_require__.rv = () => ("1.6.6")
})();
// webpack/runtime/rspack_unique_id
(() => {
__webpack_require__.ruid = "bundler=rspack@1.6.6";
})();
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";

;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+logger@2.0.1/node_modules/@adguard/logger/dist/es/index.mjs
/**
 * Checks if error has message.
 *
 * @param error Error object.
 *
 * @returns True if error has message.
 */
function isErrorWithMessage(error) {
    return (typeof error === 'object'
        && error !== null
        && 'message' in error
        && typeof error.message === 'string');
}
/**
 * Converts error to the error with a message.
 *
 * @param maybeError Possible error.
 *
 * @returns Error with a message.
 */
function toErrorWithMessage(maybeError) {
    if (isErrorWithMessage(maybeError)) {
        return maybeError;
    }
    try {
        return new Error(JSON.stringify(maybeError));
    }
    catch {
        // fallback in case there's an error stringifying the maybeError
        // like with circular references, for example.
        return new Error(String(maybeError));
    }
}
/**
 * Converts an error object to an error with a message. This method might be helpful to handle thrown errors.
 *
 * @param error Error object.
 *
 * @returns Message of the error.
 */
function getErrorMessage(error) {
    return toErrorWithMessage(error).message;
}

/**
 * Pads a number with leading zeros.
 *
 * @param num The number to pad.
 * @param size The number of digits to pad to.
 *
 * @returns The padded number.
 */
const pad = (num, size = 2) => {
    return num.toString().padStart(size, '0');
};
/**
 * Formats a date into an ISO 8601-like string with milliseconds.
 *
 * @param {Date|number} date The date object or timestamp to format.
 *
 * @returns {string} The formatted date string.
 */
const formatTime = (date) => {
    const d = (date instanceof Date) ? date : new Date(date);
    const year = d.getFullYear();
    const month = pad(d.getMonth() + 1); // Months are 0-based
    const day = pad(d.getDate());
    const hour = pad(d.getHours());
    const minute = pad(d.getMinutes());
    const second = pad(d.getSeconds());
    const millisecond = pad(d.getMilliseconds(), 3); // Milliseconds are 3 digits
    return `${year}-${month}-${day}T${hour}:${minute}:${second}:${millisecond}`;
};

/**
 * String presentation of log levels, for convenient users usage.
 * Ordered in the same way as LogLevelNumeric.
 *
 * First three levels will be shown to users, and the last two are for developers.
 */
var es_LogLevel;
(function (LogLevel) {
    /**
     * For errors.
     */
    LogLevel["Error"] = "error";
    /**
     * For not critical errors.
     */
    LogLevel["Warn"] = "warn";
    /**
     * For important information.
     * Use for general operational messages.
     */
    LogLevel["Info"] = "info";
    /**
     * For debugging purposes, e.g. Inside conditions, loops or some edge cases.
     */
    LogLevel["Debug"] = "debug";
    /**
     * For ultra-detailed, step-by-step traces (like stack traces or flow tracking).
     */
    LogLevel["Verbose"] = "verbose";
})(es_LogLevel || (es_LogLevel = {}));
/**
 * Log levels map, which maps number level to string level.
 * Ordered in the same way as LogLevelNumeric.
 */
const levelMapNumToString = {
    [1 /* LogLevelNumeric.Error */]: es_LogLevel.Error,
    [2 /* LogLevelNumeric.Warn */]: es_LogLevel.Warn,
    [3 /* LogLevelNumeric.Info */]: es_LogLevel.Info,
    [4 /* LogLevelNumeric.Debug */]: es_LogLevel.Debug,
    [5 /* LogLevelNumeric.Verbose */]: es_LogLevel.Verbose,
};
/**
 * Log levels map, which maps string level to number level.
 */
const levelMapStringToNum = Object.entries(levelMapNumToString)
    .reduce((acc, [key, value]) => {
    // Here, key is originally a string since Object.entries() returns [string, string][].
    // We need to cast the key to LogLevelNumeric correctly without causing type mismatches.
    const numericKey = Number(key);
    if (!Number.isNaN(numericKey)) {
        acc[value] = numericKey;
    }
    return acc;
}, {});
/**
 * Methods supported by console. Used to manage levels.
 * Ordered in the same way as LogLevelNumeric.
 */
var es_LogMethod;
(function (LogMethod) {
    LogMethod["Error"] = "error";
    LogMethod["Warn"] = "warn";
    LogMethod["Info"] = "info";
    LogMethod["Debug"] = "debug";
    LogMethod["Trace"] = "trace";
})(es_LogMethod || (es_LogMethod = {}));
/**
 * Simple logger with log levels.
 */
class Logger {
    currentLevelValue = 3 /* LogLevelNumeric.Info */;
    writer;
    /**
     * Constructor.
     *
     * @param writer Writer object.
     */
    constructor(writer = console) {
        this.writer = writer;
        // bind the logging methods to avoid losing context
        this.error = this.error.bind(this);
        this.warn = this.warn.bind(this);
        this.info = this.info.bind(this);
        this.debug = this.debug.bind(this);
        this.trace = this.trace.bind(this);
    }
    /**
     * Print error messages.
     * Use when something went wrong.
     *
     * @param args Printed arguments.
     */
    error(...args) {
        this.print(1 /* LogLevelNumeric.Error */, es_LogMethod.Error, args);
    }
    /**
     * Print warn messages.
     * Use when Something might go wrong.
     *
     * @param args Printed arguments.
     */
    warn(...args) {
        this.print(2 /* LogLevelNumeric.Warn */, es_LogMethod.Warn, args);
    }
    /**
     * Print messages you want to disclose to users.
     * Use for general operational messages.
     *
     * @param args Printed arguments.
     */
    info(...args) {
        this.print(3 /* LogLevelNumeric.Info */, es_LogMethod.Info, args);
    }
    /**
     * Print debug messages. Usually used for technical information.
     *
     * @param args Printed arguments.
     */
    debug(...args) {
        this.print(4 /* LogLevelNumeric.Debug */, es_LogMethod.Debug, args);
    }
    /**
     * Print trace messages.
     * Ultra-detailed, step-by-step traces (like stack traces or flow tracking).
     *
     * @param args Printed arguments.
     */
    trace(...args) {
        this.print(5 /* LogLevelNumeric.Verbose */, es_LogMethod.Trace, args);
    }
    /**
     * Getter for log level.
     *
     * @returns Logger level.
     */
    get currentLevel() {
        return levelMapNumToString[this.currentLevelValue];
    }
    /**
     * Setter for log level. With this method log level can be updated dynamically.
     *
     * @param logLevel Logger level.
     *
     * @throws Error if log level is not supported.
     */
    set currentLevel(logLevel) {
        const level = levelMapStringToNum[logLevel];
        if (level === undefined) {
            throw new Error(`Logger supports only the following levels: ${[Object.values(es_LogLevel).join(', ')]}`);
        }
        this.currentLevelValue = level;
    }
    /**
     * Converts error to string, and adds stack trace.
     *
     * @param error Error to print.
     *
     * @returns Error message.
     */
    static errorToString(error) {
        const message = getErrorMessage(error);
        return `${message}\nStack trace:\n${error.stack}`;
    }
    /**
     * Prints error message with stack trace.
     * It prints the message with the stack trace in a collapsed group.
     * This is useful for debugging purposes, as it allows to see the stack trace
     * without cluttering the console with too many messages.
     *
     * @param formattedTime Formatted time.
     * @param formattedArgs Formatted arguments.
     */
    printWithStackTrace(formattedTime, formattedArgs) {
        // If grouping is not supported, print just expanded trace, but this
        // leads to a lot of dirty logs in the console, since the stack trace
        // will be printed for every message.
        if (!this.writer.groupCollapsed || !this.writer.groupEnd) {
            // Print expanded trace
            this.writer.trace(formattedTime, ...formattedArgs);
            return;
        }
        // Print collapsed trace to make logs more readable and access to stack
        // trace by clicking on the group.
        this.writer.groupCollapsed(formattedTime, ...formattedArgs);
        this.writer.trace();
        this.writer.groupEnd();
    }
    /**
     * Wrapper over log methods.
     *
     * @param level Logger level.
     * @param method Logger method.
     * @param args Printed arguments.
     */
    print(level, method, args) {
        // Skip writing if the basic conditions are not met.
        if (this.currentLevelValue < level) {
            return;
        }
        // Do not print if no arguments are passed.
        if (!args || args.length === 0 || !args[0]) {
            return;
        }
        const formattedArgs = args.map((value) => {
            if (value instanceof Error) {
                return Logger.errorToString(value);
            }
            if (value && typeof value.message === 'string') {
                return value.message;
            }
            if (typeof value === 'object' && value !== null) {
                return JSON.stringify(value);
            }
            return String(value);
        });
        const formattedTime = `${formatTime(new Date())}:`;
        /**
         * If current log level is Debug or Verbose, print all channels with stack
         * trace via using writer.trace method to help identify the location of the
         * log.
         *
         * Exception is Error method, because it is already contains build-in
         * stack trace.
         */
        if (this.currentLevelValue >= levelMapStringToNum[es_LogLevel.Debug]
            && method !== es_LogMethod.Error) {
            this.printWithStackTrace(formattedTime, formattedArgs);
            return;
        }
        // Otherwise just print with requested method of writer.
        this.writer[method](formattedTime, ...formattedArgs);
    }
}



;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+tswebextension@7.0.1_@adguard+re2-wasm@1.2.0_typescript@5.6.3/node_modules/@adguard/tswebextension/dist/common/logger.js


/**
 * Export logger implementation.
 */
const logger = new Logger(console);
/**
 * Stringify object via JSON.stringify without specified keys.
 *
 * @param obj Object to stringify.
 * @param excludedKeys Keys to exclude.
 *
 * @returns Stringified object without excludedKeys (checking nested keys too).
 */
const stringifyObjectWithoutKeys = (obj, excludedKeys) => {
    return JSON.stringify(obj, (key, value) => (excludedKeys.includes(key) ? undefined : value), 2);
};



;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+tswebextension@7.0.1_@adguard+re2-wasm@1.2.0_typescript@5.6.3/node_modules/@adguard/tswebextension/dist/common/selector-validator.js


/**
 * This class applies cookie rules in page context.
 *
 * - Removes cookies matching rules
 * - Listens to new cookies, then tries to apply rules to them.
 */
let CookieController$1 = class CookieController {
    /**
     * Default cookie polling interval.
     */
    DEFAULT_COOKIE_POLLING_INTERVAL_MS = 1000;
    /**
     * On rule applied callback.
     */
    onRuleAppliedCallback;
    /**
     * Is current context third-party.
     */
    isThirdPartyContext = false;
    /**
     * Constructor.
     *
     * @param callback On rule applied callback.
     */
    constructor(callback) {
        this.onRuleAppliedCallback = callback;
        this.isThirdPartyContext = this.isThirdPartyFrame();
    }
    /**
     * Applies rules.
     *
     * @param rules Rules to apply.
     */
    apply(rules) {
        this.applyRules(rules);
        let lastCookie = document.cookie;
        this.listenCookieChange((oldValue, newValue) => {
            if (newValue === lastCookie) {
                // Skip changes made by this class
                return;
            }
            this.applyRules(rules);
            lastCookie = document.cookie;
        });
        window.addEventListener('beforeunload', () => {
            this.applyRules(rules);
        });
    }
    /**
     * Polling document cookie.
     *
     * @param callback Callback to be called periodically.
     * @param interval Polling interval.
     */
    listenCookieChange(callback, interval = this.DEFAULT_COOKIE_POLLING_INTERVAL_MS) {
        let lastCookie = document.cookie;
        setInterval(() => {
            const { cookie } = document;
            if (cookie !== lastCookie) {
                try {
                    callback(lastCookie, cookie);
                }
                finally {
                    lastCookie = cookie;
                }
            }
        }, interval);
    }
    /**
     * Checks if current context is third-party.
     *
     * @returns True if current context is third-party.
     */
    // eslint-disable-next-line class-methods-use-this
    isThirdPartyFrame() {
        try {
            return window.self !== window.top && document.location.hostname !== window.parent.location.hostname;
        }
        catch (e) {
            return true;
        }
    }
    /**
     * Applies rules to document cookies.
     *
     * Inspired by remove-cookie scriptlet.
     *
     * @see {@link https://github.com/AdguardTeam/Scriptlets/blob/master/src/scriptlets/remove-cookie.js}
     *
     * @param rules Rules to apply.
     */
    applyRules(rules) {
        document.cookie.split(';').forEach((cookieStr) => {
            const pos = cookieStr.indexOf('=');
            if (pos === -1) {
                return;
            }
            const cookieName = cookieStr.slice(0, pos).trim();
            const cookieValue = cookieStr.slice(pos + 1).trim();
            const matchingRules = rules.filter((r) => {
                if (this.isThirdPartyContext !== r.isThirdParty) {
                    return false;
                }
                const regex = r.match ? CookieController.toRegExp(r.match) : CookieController.toRegExp('/.?/');
                return regex.test(cookieName);
            });
            const importantRules = matchingRules.filter((r) => r.isImportant);
            if (importantRules.length > 0) {
                importantRules.forEach((rule) => {
                    this.applyRule(rule, cookieName, cookieValue);
                });
            }
            else {
                const allowlistRules = matchingRules.filter((r) => r.isAllowlist);
                if (allowlistRules.length > 0) {
                    allowlistRules.forEach((rule) => {
                        this.applyRule(rule, cookieName, cookieValue);
                    });
                }
                else {
                    matchingRules.forEach((rule) => {
                        this.applyRule(rule, cookieName, cookieValue);
                    });
                }
            }
        });
    }
    /**
     * Applies rule.
     *
     * @param rule Rule to apply.
     * @param cookieName Cookie name.
     * @param cookieValue Cookie value.
     */
    applyRule(rule, cookieName, cookieValue) {
        if (!rule.isAllowlist) {
            const hostParts = document.location.hostname.split('.');
            for (let i = 0; i <= hostParts.length - 1; i += 1) {
                const hostName = hostParts.slice(i).join('.');
                if (hostName) {
                    CookieController.removeCookieFromHost(cookieName, hostName);
                }
            }
        }
        this.onRuleAppliedCallback({
            cookieName,
            cookieValue,
            cookieDomain: document.location.hostname,
            thirdParty: rule.isThirdParty,
            filterId: rule.filterId,
            ruleIndex: rule.ruleIndex,
            isAllowlist: rule.isAllowlist,
            isImportant: rule.isImportant,
            isDocumentLevel: rule.isDocumentLevel,
            isCsp: false,
            isCookie: true,
            advancedModifier: null,
        });
    }
    /**
     * Removes cookie for host.
     *
     * @param cookieName Cookie name.
     * @param hostName Host name.
     */
    static removeCookieFromHost(cookieName, hostName) {
        const cookieSpec = `${cookieName}=`;
        const domain1 = `; domain=${hostName}`;
        const domain2 = `; domain=.${hostName}`;
        const path = '; path=/';
        const expiration = '; expires=Thu, 01 Jan 1970 00:00:00 GMT';
        document.cookie = cookieSpec + expiration;
        document.cookie = cookieSpec + domain1 + expiration;
        document.cookie = cookieSpec + domain2 + expiration;
        document.cookie = cookieSpec + path + expiration;
        document.cookie = cookieSpec + domain1 + path + expiration;
        document.cookie = cookieSpec + domain2 + path + expiration;
    }
    /**
     * Converts cookie rule match to regular expression.
     *
     * @param str String to convert.
     *
     * @returns Regular expression.
     */
    static toRegExp(str) {
        if (str[0] === '/' && str[str.length - 1] === '/') {
            return new RegExp(str.slice(1, -1));
        }
        const escaped = str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        return new RegExp(`^${escaped}$`);
    }
};

/**
 * CSS.supports() function name for selector validation.
 */
const SELECTOR_FUNCTION = 'selector';
/**
 * Splits a CSS selector list at top-level commas, respecting quoted strings
 * and parenthesized/bracketed groups.
 *
 * "Top-level" means a comma that is NOT inside:
 * - Quotes (single or double).
 * - Parentheses (e.g., `:is(...)`, `:has(...)`).
 * - Square brackets (e.g., `[attr="..."]`).
 *
 * We use a hand-written parser instead of `@adguard/css-tokenizer` because
 * this code runs in content scripts where the tokenizer is not bundled.
 *
 * @param selectorList A single selector or comma-separated selector list.
 *
 * @returns Array of trimmed individual selector strings.
 */
function splitSelectorList(selectorList) {
    const parts = [];
    let current = 0;
    let parenDepth = 0;
    let bracketDepth = 0;
    let inDoubleQuote = false;
    let inSingleQuote = false;
    let lastSplit = 0;
    while (current < selectorList.length) {
        const ch = selectorList[current];
        if (ch === '\\') {
            // Skip escaped character
            current += 2;
            continue;
        }
        if (inDoubleQuote) {
            if (ch === '"') {
                inDoubleQuote = false;
            }
        }
        else if (inSingleQuote) {
            if (ch === "'") {
                inSingleQuote = false;
            }
        }
        else {
            switch (ch) {
                case '"':
                    inDoubleQuote = true;
                    break;
                case "'":
                    inSingleQuote = true;
                    break;
                case '(':
                    parenDepth += 1;
                    break;
                case ')':
                    parenDepth -= 1;
                    break;
                case '[':
                    bracketDepth += 1;
                    break;
                case ']':
                    bracketDepth -= 1;
                    break;
                case ',':
                    if (parenDepth === 0 && bracketDepth === 0) {
                        parts.push(selectorList.slice(lastSplit, current).trim());
                        lastSplit = current + 1;
                    }
                    break;
            }
        }
        current += 1;
    }
    parts.push(selectorList.slice(lastSplit).trim());
    return parts;
}
/**
 * Tests whether a CSS selector (or space-joined group) is valid via CSS.supports().
 * Returns false on any exception or invalid syntax.
 *
 * @param selector Selector string to validate.
 *
 * @returns True if the browser considers the selector valid.
 */
function isSelectorSupported(selector) {
    try {
        return CSS.supports(`${SELECTOR_FUNCTION}(${selector})`);
    }
    catch (e) {
        logger.debug(`[tsweb.selector-validator]: CSS.supports threw for "${selector}":`, e);
        return false;
    }
}
/**
 * Validates a single selector that may be a comma-separated list.
 * Splits at top-level commas and validates each part individually because
 * `CSS.supports('selector(A, B)')` fails due to comma ambiguity.
 *
 * @param selector A possibly comma-containing selector string.
 *
 * @returns True if the selector (or all parts of the list) is valid.
 */
function validateCommaSelector(selector) {
    const parts = splitSelectorList(selector);
    if (parts.length > 1) {
        // True comma-separated list — ALL parts must be valid (matches browser behavior).
        return parts.every((part) => part.length > 0 && isSelectorSupported(part));
    }
    // Contains comma but not at top level (e.g., `[attr="a,b"]`) — validate as-is.
    return isSelectorSupported(selector);
}
/**
 * Validates a batch of CSS selectors using a two-tier approach:
 * - Fast path: validates all selectors joined as a selector list at once.
 * - Slow path: if the batch is invalid, validates each selector individually
 *   to identify and exclude the broken ones.
 *
 * For selectors that are comma-separated lists (e.g., `.a, .b`), each part
 * is validated individually because `CSS.supports('selector(A, B)')` fails
 * in browsers due to comma ambiguity.
 *
 * Must be called in page/content script context — `CSS.supports()` is not
 * available in service workers or background pages.
 *
 * @param selectors Array of individual CSS selectors.
 *
 * @returns Object with `valid` and `invalid` selector arrays.
 */
function validateSelectors(selectors) {
    if (selectors.length === 0) {
        return { valid: [], invalid: [] };
    }
    // Fast path: try batch validation first.
    // Joining selectors with spaces creates a valid compound selector argument
    // for CSS.supports('selector(A B C)'). Commas inside pseudo-classes like
    // `:is(.a, .b)` do NOT break this because browsers parse them as part of
    // the balanced parentheses within the `selector()` function argument.
    // Only TRUE top-level commas (e.g., `.a, .b`) cause CSS.supports to fail
    // because they are ambiguous with CSS.supports' own argument separators.
    // Since ~99% of real filter selectors have no top-level commas, this single
    // call handles the vast majority of page loads with zero overhead.
    if (isSelectorSupported(selectors.join(' '))) {
        return { valid: selectors, invalid: [] };
    }
    // Batch failed — either a selector is genuinely invalid, or a selector
    // contains a top-level comma which made CSS.supports reject the batch.
    // Strategy: partition selectors into "has comma" vs "no comma" groups.
    // If a comma-containing selector caused the failure, re-batching the
    // non-comma group will pass and we avoid O(n) individual checks for them.
    const noCommaSelectors = [];
    let hasCommaSelector = false;
    for (const selector of selectors) {
        if (selector.includes(',')) {
            hasCommaSelector = true;
        }
        else {
            noCommaSelectors.push(selector);
        }
    }
    // Re-batch the non-comma group. If this passes, all non-comma selectors
    // are valid and we only need individual checks for comma-containing ones.
    // We skip this when there are no comma selectors because in that case the
    // initial batch failure means at least one non-comma selector is invalid
    // and we must check them individually anyway.
    const allNoCommaValid = hasCommaSelector
        && noCommaSelectors.length > 0
        && isSelectorSupported(noCommaSelectors.join(' '));
    // Build result arrays preserving original order.
    const valid = [];
    const invalid = [];
    for (const selector of selectors) {
        let isValid;
        if (!selector.includes(',')) {
            isValid = allNoCommaValid || isSelectorSupported(selector);
        }
        else {
            isValid = validateCommaSelector(selector);
        }
        if (isValid) {
            valid.push(selector);
        }
        else {
            invalid.push(selector);
            logger.warn(`[tsweb.selector-validator]: Invalid CSS selector skipped: "${selector}"`);
        }
    }
    return { valid, invalid };
}



// EXTERNAL MODULE: ./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js
var browser_polyfill = __webpack_require__("./node_modules/.pnpm/webextension-polyfill@0.12.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
var browser_polyfill_default = /*#__PURE__*/__webpack_require__.n(browser_polyfill);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+tswebextension@7.0.1_@adguard+re2-wasm@1.2.0_typescript@5.6.3/node_modules/@adguard/tswebextension/dist/common/message-constants.js
/**
 * @file
 * This file contains constants for communication between background and content scripts.
 * This constants are separated from message.ts to reduce bundle size,
 * because rollup cannot tree-shake tswebextension library code.
 */
/**
 * Name of the message handler.
 * It is needed for determining specific tswebextension message from other messages.
 */
const MESSAGE_HANDLER_NAME = 'tsWebExtension';
/**
 * Message types for communication between background and content scripts.
 */
var message_constants_MessageType;
(function (MessageType) {
    MessageType["ProcessShouldCollapse"] = "processShouldCollapse";
    MessageType["GetCosmeticData"] = "getCosmeticData";
    MessageType["GetCookieRules"] = "getCookieRules";
    MessageType["SaveCookieLogEvent"] = "saveCookieLogEvent";
    MessageType["InitAssistant"] = "initAssistant";
    MessageType["CloseAssistant"] = "closeAssistant";
    MessageType["AssistantCreateRule"] = "assistantCreateRule";
    MessageType["SaveCssHitsStats"] = "saveCssHitsStats";
})(message_constants_MessageType || (message_constants_MessageType = {}));



;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+tswebextension@7.0.1_@adguard+re2-wasm@1.2.0_typescript@5.6.3/node_modules/@adguard/tswebextension/dist/common/send-app-message.js



// TODO check if we can return typed message here
/**
 * Sends message to the background page.
 *
 * @param message Message to send.
 * @param message.payload Payload of the message.
 * @param message.type Message type.
 *
 * @returns Promise resolved with response from the background page.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sendAppMessage = async (message) => {
    return browser_polyfill.runtime.sendMessage({ handlerName: MESSAGE_HANDLER_NAME, ...message });
};



;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+extended-css@2.3.0/node_modules/@adguard/extended-css/dist/extended-css.esm.js
/**
 * @adguard/extended-css - v2.3.0 - Thu Oct 15 2026
 * https://github.com/AdGuardSoftwareLimited/ext-extended-css#readme
 * Copyright (c) 2026 AdGuard. Licensed GPL-3.0
 */
const EXTENDED_CSS_VERSION = '2.3.0';
const LEFT_SQUARE_BRACKET = '[';
const RIGHT_SQUARE_BRACKET = ']';
const LEFT_PARENTHESIS = '(';
const RIGHT_PARENTHESIS = ')';
const LEFT_CURLY_BRACKET = '{';
const RIGHT_CURLY_BRACKET = '}';
const BRACKET = {
  SQUARE: {
    LEFT: LEFT_SQUARE_BRACKET,
    RIGHT: RIGHT_SQUARE_BRACKET
  },
  PARENTHESES: {
    LEFT: LEFT_PARENTHESIS,
    RIGHT: RIGHT_PARENTHESIS
  },
  CURLY: {
    LEFT: LEFT_CURLY_BRACKET,
    RIGHT: RIGHT_CURLY_BRACKET
  }
};
const SLASH = '/';
const BACKSLASH = '\\';
const SPACE = ' ';
const COMMA = ',';
const DOT = '.';
const SEMICOLON = ';';
const COLON = ':';
const SINGLE_QUOTE = '\'';
const DOUBLE_QUOTE = '"';

// do not consider hyphen `-` as separated mark
// to avoid pseudo-class names splitting
// e.g. 'matches-css' or 'if-not'

const CARET = '^';
const DOLLAR_SIGN = '$';
const EQUAL_SIGN = '=';
const TAB = '\t';
const CARRIAGE_RETURN = '\r';
const LINE_FEED = '\n';
const FORM_FEED = '\f';
const WHITE_SPACE_CHARACTERS = [SPACE, TAB, CARRIAGE_RETURN, LINE_FEED, FORM_FEED];

// for universal selector and attributes
const ASTERISK = '*';
const ID_MARKER = '#';
const CLASS_MARKER = DOT;
const DESCENDANT_COMBINATOR = SPACE;
const CHILD_COMBINATOR = '>';
const NEXT_SIBLING_COMBINATOR = '+';
const SUBSEQUENT_SIBLING_COMBINATOR = '~';
const COMBINATORS = [DESCENDANT_COMBINATOR, CHILD_COMBINATOR, NEXT_SIBLING_COMBINATOR, SUBSEQUENT_SIBLING_COMBINATOR];
const SUPPORTED_SELECTOR_MARKS = [LEFT_SQUARE_BRACKET, RIGHT_SQUARE_BRACKET, LEFT_PARENTHESIS, RIGHT_PARENTHESIS, LEFT_CURLY_BRACKET, RIGHT_CURLY_BRACKET, SLASH, BACKSLASH, SEMICOLON, COLON, COMMA, SINGLE_QUOTE, DOUBLE_QUOTE, CARET, DOLLAR_SIGN, ASTERISK, ID_MARKER, CLASS_MARKER, DESCENDANT_COMBINATOR, CHILD_COMBINATOR, NEXT_SIBLING_COMBINATOR, SUBSEQUENT_SIBLING_COMBINATOR, TAB, CARRIAGE_RETURN, LINE_FEED, FORM_FEED];

/**
 * Limited list of available symbols before slash `/`
 * to check whether it is valid regexp pattern opening.
 */
const POSSIBLE_MARKS_BEFORE_REGEXP = {
  COMMON: [
  // e.g. ':matches-attr(/data-/)'
  LEFT_PARENTHESIS,
  // e.g. `:matches-attr('/data-/')`
  SINGLE_QUOTE,
  // e.g. ':matches-attr("/data-/")'
  DOUBLE_QUOTE,
  // e.g. ':matches-attr(check=/data-v-/)'
  EQUAL_SIGN,
  // e.g. ':matches-property(inner./_test/=null)'
  DOT,
  // e.g. ':matches-css(height:/20px/)'
  COLON,
  // ':matches-css-after( content  :   /(\\d+\\s)*me/  )'
  SPACE],
  CONTAINS: [
  // e.g. ':contains(/text/)'
  LEFT_PARENTHESIS,
  // e.g. `:contains('/text/')`
  SINGLE_QUOTE,
  // e.g. ':contains("/text/")'
  DOUBLE_QUOTE]
};
const SUPPORTED_STYLE_DECLARATION_MARKS = [
// divider between property and value in declaration
COLON,
// divider between declarations
SEMICOLON,
// sometimes is needed for value wrapping
// e.g. 'content: "-"'
SINGLE_QUOTE, DOUBLE_QUOTE,
// needed for quote escaping inside the same-type quotes
BACKSLASH,
// whitespaces
SPACE, TAB, CARRIAGE_RETURN, LINE_FEED, FORM_FEED];

// absolute:
const CONTAINS_PSEUDO = 'contains';
const HAS_TEXT_PSEUDO = 'has-text';
const ABP_CONTAINS_PSEUDO = '-abp-contains';
const MATCHES_CSS_PSEUDO = 'matches-css';
const MATCHES_CSS_BEFORE_PSEUDO = 'matches-css-before';
const MATCHES_CSS_AFTER_PSEUDO = 'matches-css-after';
const MATCHES_ATTR_PSEUDO_CLASS_MARKER = 'matches-attr';
const MATCHES_PROPERTY_PSEUDO_CLASS_MARKER = 'matches-property';
const XPATH_PSEUDO_CLASS_MARKER = 'xpath';
const NTH_ANCESTOR_PSEUDO_CLASS_MARKER = 'nth-ancestor';
const CONTAINS_PSEUDO_NAMES = [CONTAINS_PSEUDO, HAS_TEXT_PSEUDO, ABP_CONTAINS_PSEUDO];

/**
 * Pseudo-class :upward() can get number or selector arg
 * and if the arg is selector it should be standard, not extended
 * so :upward pseudo-class is always absolute.
 */
const UPWARD_PSEUDO_CLASS_MARKER = 'upward';

/**
 * Pseudo-class `:remove()` and pseudo-property `remove`
 * are used for element actions, not for element selecting.
 *
 * Selector text should not contain the pseudo-class
 * so selector parser should consider it as invalid
 * and both are handled by stylesheet parser.
 */
const REMOVE_PSEUDO_MARKER = 'remove';

/**
 * Pseudo-classes `:remove-attr()` and `:remove-class()` are action operators:
 * they remove matching attributes or classes instead of selecting elements.
 *
 * Selector text should not contain these pseudo-classes,
 * so the selector parser considers them invalid,
 * and they are handled by the stylesheet parser.
 */
const REMOVE_ATTR_PSEUDO_MARKER = 'remove-attr';
const REMOVE_CLASS_PSEUDO_MARKER = 'remove-class';

/**
 * Action pseudo-class markers which are handled by the stylesheet parser
 * and should never reach the selector parser.
 */
const ACTION_PSEUDO_MARKERS = [REMOVE_PSEUDO_MARKER, REMOVE_ATTR_PSEUDO_MARKER, REMOVE_CLASS_PSEUDO_MARKER];
/**
 * Action pseudo-class markers which are stored in rule styles
 * and are not CSS properties.
 */
const ACTION_STYLE_MARKERS = [REMOVE_ATTR_PSEUDO_MARKER, REMOVE_CLASS_PSEUDO_MARKER];
// relative:
const HAS_PSEUDO_CLASS_MARKER = 'has';
const ABP_HAS_PSEUDO_CLASS_MARKER = '-abp-has';
const HAS_PSEUDO_CLASS_MARKERS = [HAS_PSEUDO_CLASS_MARKER, ABP_HAS_PSEUDO_CLASS_MARKER];
const IS_PSEUDO_CLASS_MARKER = 'is';
const NOT_PSEUDO_CLASS_MARKER = 'not';

// standalone (no-argument pseudo-classes that test the element
// itself, not a selector-list of related elements):
const EMPTY_TRIMMED_PSEUDO_CLASS_MARKER = 'empty-trimmed';
const STANDALONE_PSEUDO_CLASSES = [EMPTY_TRIMMED_PSEUDO_CLASS_MARKER];
const ABSOLUTE_PSEUDO_CLASSES = [CONTAINS_PSEUDO, HAS_TEXT_PSEUDO, ABP_CONTAINS_PSEUDO, MATCHES_CSS_PSEUDO, MATCHES_CSS_BEFORE_PSEUDO, MATCHES_CSS_AFTER_PSEUDO, MATCHES_ATTR_PSEUDO_CLASS_MARKER, MATCHES_PROPERTY_PSEUDO_CLASS_MARKER, XPATH_PSEUDO_CLASS_MARKER, NTH_ANCESTOR_PSEUDO_CLASS_MARKER, UPWARD_PSEUDO_CLASS_MARKER];
const RELATIVE_PSEUDO_CLASSES = [...HAS_PSEUDO_CLASS_MARKERS, IS_PSEUDO_CLASS_MARKER, NOT_PSEUDO_CLASS_MARKER];
const SUPPORTED_PSEUDO_CLASSES = [...ABSOLUTE_PSEUDO_CLASSES, ...RELATIVE_PSEUDO_CLASSES, ...STANDALONE_PSEUDO_CLASSES];

// these pseudo-classes should be part of RegularSelector value
// if its arg does not contain extended selectors.
// the ast will be checked after the selector is completely parsed
const OPTIMIZATION_PSEUDO_CLASSES = [NOT_PSEUDO_CLASS_MARKER, IS_PSEUDO_CLASS_MARKER];

/**
 * ':scope' is used for extended pseudo-class :has(), if-not(), :is() and :not().
 */
const SCOPE_CSS_PSEUDO_CLASS = ':scope';

/**
 * ':after' and ':before' are needed for :matches-css() pseudo-class
 * all other are needed for :has() limitation after regular pseudo-elements.
 *
 * @see {@link https://bugs.chromium.org/p/chromium/issues/detail?id=669058#c54} [case 3]
 */
const REGULAR_PSEUDO_ELEMENTS = {
  AFTER: 'after',
  BACKDROP: 'backdrop',
  BEFORE: 'before',
  CUE: 'cue',
  CUE_REGION: 'cue-region',
  FIRST_LETTER: 'first-letter',
  FIRST_LINE: 'first-line',
  FILE_SELECTION_BUTTON: 'file-selector-button',
  GRAMMAR_ERROR: 'grammar-error',
  MARKER: 'marker',
  PART: 'part',
  PLACEHOLDER: 'placeholder',
  SELECTION: 'selection',
  SLOTTED: 'slotted',
  SPELLING_ERROR: 'spelling-error',
  TARGET_TEXT: 'target-text'
};

// ExtendedCss does not support at-rules
// https://developer.mozilla.org/en-US/docs/Web/CSS/At-rule
const AT_RULE_MARKER = '@';
const CONTENT_CSS_PROPERTY = 'content';
const PSEUDO_PROPERTY_POSITIVE_VALUE = 'true';
const DEBUG_PSEUDO_PROPERTY_GLOBAL_VALUE = 'global';
const STANDALONE_ERROR_PREFIX = {
  NO_ARGUMENTS: 'Standalone pseudo-class does not accept arguments'
};
const NO_SELECTOR_ERROR_PREFIX = 'Selector should be defined';
const STYLE_ERROR_PREFIX = {
  NO_STYLE: 'No style declaration found',
  NO_SELECTOR: `${NO_SELECTOR_ERROR_PREFIX} before style declaration in stylesheet`,
  INVALID_STYLE: 'Invalid style declaration',
  UNCLOSED_STYLE: 'Unclosed style declaration',
  NO_PROPERTY: 'Missing style property in declaration',
  NO_VALUE: 'Missing style value in declaration',
  NO_STYLE_OR_ACTION: 'Style should be declared or action pseudo-class should be used',
  NO_COMMENT: 'Comments are not supported'
};
const NO_AT_RULE_ERROR_PREFIX = 'At-rules are not supported';

/**
 * Error message shape shared by all action pseudo-classes.
 */

/**
 * Creates error messages for an action pseudo-class.
 *
 * @param marker Action pseudo-class marker, e.g. 'remove-attr'.
 *
 * @returns Error messages of the action pseudo-class.
 */
const createActionErrorPrefix = marker => {
  return {
    INVALID_ACTION: `Invalid :${marker}() pseudo-class in selector`,
    NO_TARGET_SELECTOR: `${NO_SELECTOR_ERROR_PREFIX} before :${marker}() pseudo-class`,
    MULTIPLE_USAGE: `Pseudo-class :${marker}() appears more than once in selector`,
    INVALID_POSITION: `Pseudo-class :${marker}() should be at the end of selector`,
    INVALID_ARG: `Invalid argument of :${marker}() pseudo-class`
  };
};
const REMOVE_ERROR_PREFIX = createActionErrorPrefix(REMOVE_PSEUDO_MARKER);
const REMOVE_ATTR_ERROR_PREFIX = createActionErrorPrefix(REMOVE_ATTR_PSEUDO_MARKER);
const REMOVE_CLASS_ERROR_PREFIX = createActionErrorPrefix(REMOVE_CLASS_PSEUDO_MARKER);

/**
 * Maps an action pseudo-class marker to its error messages.
 */
const ACTION_ERROR_PREFIXES = {
  [REMOVE_PSEUDO_MARKER]: REMOVE_ERROR_PREFIX,
  [REMOVE_ATTR_PSEUDO_MARKER]: REMOVE_ATTR_ERROR_PREFIX,
  [REMOVE_CLASS_PSEUDO_MARKER]: REMOVE_CLASS_ERROR_PREFIX
};

/**
 * Quote mark of a quoted string.
 */

const MATCHING_ELEMENT_ERROR_PREFIX = 'Error while matching element';
const MAX_STYLE_PROTECTION_COUNT = 50;

/**
 * Maximum number of times an action (e.g. `:remove-attr()`) is applied
 * to the same element with the same argument.
 * Needed to avoid an endless loop if the page keeps re-adding
 * the removed attribute or class.
 */
const MAX_ACTION_REMOVALS_COUNT = 50;
const ID_ATTRIBUTE = 'id';
const CLASS_ATTRIBUTE = 'class';
const STYLE_ATTRIBUTE = 'style';

/**
 * Regexp that matches backward compatible syntaxes.
 */
const REGEXP_VALID_OLD_SYNTAX = /\[-(?:ext)-([a-z-_]+)=(["'])((?:(?=(\\?))\4.)*?)\2\]/g;

/**
 * Marker for checking invalid selector after old-syntax normalizing by selector converter.
 */
const INVALID_OLD_SYNTAX_MARKER = '[-ext-';

/**
 * Complex replacement function.
 * Undo quote escaping inside of an extended selector.
 *
 * @param match     Whole matched string.
 * @param name      Group 1.
 * @param quoteChar Group 2.
 * @param rawValue  Group 3.
 *
 * @returns Converted string.
 */
const evaluateMatch = (match, name, quoteChar, rawValue) => {
  // Unescape quotes
  const re = new RegExp(`([^\\\\]|^)\\\\${quoteChar}`, 'g');
  const value = rawValue.replace(re, `$1${quoteChar}`);
  return `:${name}(${value})`;
};

// ':scope' pseudo may be at start of :has() argument
// but ExtCssDocument.querySelectorAll() already use it for selecting exact element descendants
const SCOPE_MARKER_REGEXP = /\(:scope >/g;
const SCOPE_REPLACER = '(>';
const MATCHES_CSS_PSEUDO_ELEMENT_REGEXP = /(:matches-css)-(before|after)\(/g;
const convertMatchesCss = (match, extendedPseudoClass, regularPseudoElement) => {
  // ':matches-css-before('  -->  ':matches-css(before, '
  // ':matches-css-after('   -->  ':matches-css(after, '
  return `${extendedPseudoClass}${BRACKET.PARENTHESES.LEFT}${regularPseudoElement}${COMMA}`;
};

/**
 * Handles old syntax and :scope inside :has().
 *
 * @param selector Trimmed selector to normalize.
 *
 * @returns Normalized selector.
 * @throws An error on invalid old extended syntax selector.
 */
const normalize = selector => {
  const normalizedSelector = selector.replace(REGEXP_VALID_OLD_SYNTAX, evaluateMatch).replace(SCOPE_MARKER_REGEXP, SCOPE_REPLACER).replace(MATCHES_CSS_PSEUDO_ELEMENT_REGEXP, convertMatchesCss);

  // validate old syntax after normalizing
  // e.g. '[-ext-matches-css-before=\'content:  /^[A-Z][a-z]'
  if (normalizedSelector.includes(INVALID_OLD_SYNTAX_MARKER)) {
    throw new Error(`Invalid extended-css old syntax selector: '${selector}'`);
  }
  return normalizedSelector;
};

/**
 * Prepares the rawSelector before tokenization:
 * 1. Trims it.
 * 2. Converts old syntax `[-ext-pseudo-class="..."]` to new one `:pseudo-class(...)`.
 * 3. Handles :scope pseudo inside :has() pseudo-class arg.
 *
 * @param rawSelector Selector with no style declaration.
 * @returns Prepared selector with no style declaration.
 */
const convert = rawSelector => {
  const trimmedSelector = rawSelector.trim();
  return normalize(trimmedSelector);
};

/**
 * Possible token types.
 *
 * IMPORTANT: it is used as 'const' instead of 'enum' to avoid side effects
 * during ExtendedCss import into other libraries.
 */
const TOKEN_TYPE = {
  MARK: 'mark',
  WORD: 'word'
};
/**
 * Splits `input` string into tokens.
 *
 * @param input Input string to tokenize.
 * @param supportedMarks Array of supported marks to considered as `TOKEN_TYPE.MARK`;
 * all other will be considered as `TOKEN_TYPE.WORD`.
 *
 * @returns Array of tokens.
 */
const tokenize = (input, supportedMarks) => {
  // buffer is needed for words collecting while iterating
  let wordBuffer = '';
  // result collection
  const tokens = [];
  const selectorSymbols = input.split('');
  // iterate through selector chars and collect tokens
  selectorSymbols.forEach(symbol => {
    if (supportedMarks.includes(symbol)) {
      // if anything was collected to the buffer before
      if (wordBuffer.length > 0) {
        // now it is time to stop buffer collecting and save is as "word"
        tokens.push({
          type: TOKEN_TYPE.WORD,
          value: wordBuffer
        });
        // reset the buffer
        wordBuffer = '';
      }
      // save current symbol as "mark"
      tokens.push({
        type: TOKEN_TYPE.MARK,
        value: symbol
      });
      return;
    }
    // otherwise collect symbol to the buffer
    wordBuffer += symbol;
  });

  // save the last collected word
  if (wordBuffer.length > 0) {
    tokens.push({
      type: TOKEN_TYPE.WORD,
      value: wordBuffer
    });
  }
  return tokens;
};

/**
 * Prepares `rawSelector` and splits it into tokens.
 *
 * @param rawSelector Raw css selector.
 *
 * @returns Array of tokens supported for selector.
 */
const tokenizeSelector = rawSelector => {
  const selector = convert(rawSelector);
  return tokenize(selector, SUPPORTED_SELECTOR_MARKS);
};

/**
 * Splits `attribute` into tokens.
 *
 * @param attribute Input attribute.
 *
 * @returns Array of tokens supported for attribute.
 */
const tokenizeAttribute = attribute => {
  // equal sigh `=` in attribute is considered as `TOKEN_TYPE.MARK`
  return tokenize(attribute, [...SUPPORTED_SELECTOR_MARKS, EQUAL_SIGN]);
};

function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}

function toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}

function toPropertyKey(t) {
  var i = toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}

function _defineProperty(e, r, t) {
  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = t, e;
}

/**
 * Possible ast node types.
 *
 * IMPORTANT: it is used as 'const' instead of 'enum' to avoid side effects
 * during ExtendedCss import into other libraries.
 */
const NODE = {
  SELECTOR_LIST: 'SelectorList',
  SELECTOR: 'Selector',
  REGULAR_SELECTOR: 'RegularSelector',
  EXTENDED_SELECTOR: 'ExtendedSelector',
  ABSOLUTE_PSEUDO_CLASS: 'AbsolutePseudoClass',
  RELATIVE_PSEUDO_CLASS: 'RelativePseudoClass'
};

/**
 * Universal interface for all node types.
 */

/**
 * Class needed for creating ast nodes while selector parsing.
 * Used for SelectorList, Selector, ExtendedSelector.
 */
class AnySelectorNode {
  /**
   * Creates new ast node.
   *
   * @param type Ast node type.
   */
  constructor(type) {
    _defineProperty(this, "children", []);
    this.type = type;
  }

  /**
   * Adds child node to children array.
   *
   * @param child Ast node.
   */
  addChild(child) {
    this.children.push(child);
  }
}

/**
 * Class needed for creating RegularSelector ast node while selector parsing.
 */
class RegularSelectorNode extends AnySelectorNode {
  /**
   * Creates RegularSelector ast node.
   *
   * @param value Value of RegularSelector node.
   */
  constructor(value) {
    super(NODE.REGULAR_SELECTOR);
    this.value = value;
  }
}

/**
 * Class needed for creating RelativePseudoClass ast node while selector parsing.
 */
class RelativePseudoClassNode extends AnySelectorNode {
  /**
   * Creates RegularSelector ast node.
   *
   * @param name Name of RelativePseudoClass node.
   */
  constructor(name) {
    super(NODE.RELATIVE_PSEUDO_CLASS);
    this.name = name;
  }
}

/**
 * Class needed for creating AbsolutePseudoClass ast node while selector parsing.
 */
class AbsolutePseudoClassNode extends AnySelectorNode {
  /**
   * Creates AbsolutePseudoClass ast node.
   *
   * @param name Name of AbsolutePseudoClass node.
   */
  constructor(name) {
    super(NODE.ABSOLUTE_PSEUDO_CLASS);
    _defineProperty(this, "value", '');
    this.name = name;
  }
}

/* eslint-disable jsdoc/require-description-complete-sentence */

/**
 * Root node.
 *
 * SelectorList
 *   : Selector
 *     ...
 *   ;
 */

/**
 * Selector node.
 *
 * Selector
 *   : RegularSelector
 *   | ExtendedSelector
 *     ...
 *   ;
 */

/**
 * Regular selector node.
 * It can be selected by querySelectorAll().
 *
 * RegularSelector
 *   : type
 *   : value
 *   ;
 */

/**
 * Extended selector node.
 *
 * ExtendedSelector
 *   : AbsolutePseudoClass
 *   | RelativePseudoClass
 *   ;
 */

/**
 * Absolute extended pseudo-class node,
 * i.e. none-selector args.
 *
 * AbsolutePseudoClass
 *   : type
 *   : name
 *   : value
 *   ;
 */

/**
 * Relative extended pseudo-class node
 * i.e. selector as arg.
 *
 * RelativePseudoClass
 *   : type
 *   : name
 *   : SelectorList
 *   ;
 */

//
//  ast example
//
//  div.banner > div:has(span, p), a img.ad
//
//  SelectorList - div.banner > div:has(span, p), a img.ad
//      Selector - div.banner > div:has(span, p)
//          RegularSelector - div.banner > div
//          ExtendedSelector - :has(span, p)
//              PseudoClassSelector - :has
//              SelectorList - span, p
//                  Selector - span
//                      RegularSelector - span
//                  Selector - p
//                      RegularSelector - p
//      Selector - a img.ad
//          RegularSelector - a img.ad
//

/**
 * Some browsers do not support Array.prototype.flat()
 * e.g. Opera 42 which is used for browserstack tests.
 *
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/flat}
 *
 * @param input Array needed to be flatten.
 *
 * @returns Flatten array.
 * @throws An error if array cannot be flatten.
 */
const flatten = input => {
  const stack = [];
  input.forEach(el => stack.push(el));
  const res = [];
  while (stack.length) {
    // pop value from stack
    const next = stack.pop();
    if (!next) {
      throw new Error('Unable to make array flat');
    }
    if (Array.isArray(next)) {
      // push back array items, won't modify the original input
      next.forEach(el => stack.push(el));
    } else {
      res.push(next);
    }
  }
  // reverse to restore input order
  return res.reverse();
};

/**
 * Returns first item from `array`.
 *
 * @param array Input array.
 *
 * @returns First array item, or `undefined` if there is no such item.
 */
const getFirst = array => {
  return array[0];
};

/**
 * Returns last item from array.
 *
 * @param array Input array.
 *
 * @returns Last array item, or `undefined` if there is no such item.
 */
const getLast = array => {
  return array[array.length - 1];
};

/**
 * Returns array item which is previous to the last one
 * e.g. for `[5, 6, 7, 8]` returns `7`.
 *
 * @param array Input array.
 *
 * @returns Previous to last array item, or `undefined` if there is no such item.
 */
const getPrevToLast = array => {
  return array[array.length - 2];
};

/**
 * Takes array of ast node `children` and returns the child by the `index`.
 *
 * @param array Array of ast node children.
 * @param index Index of needed child in the array.
 * @param errorMessage Optional error message to throw.
 *
 * @returns Array item at `index` position.
 * @throws An error if there is no child with specified `index` in array.
 */
const getItemByIndex = (array, index, errorMessage) => {
  const indexChild = array[index];
  if (!indexChild) {
    throw new Error(errorMessage || `No array item found by index ${index}`);
  }
  return indexChild;
};

const NO_REGULAR_SELECTOR_ERROR = 'At least one of Selector node children should be RegularSelector';

/**
 * Checks whether the type of `astNode` is SelectorList.
 *
 * @param astNode Ast node.
 *
 * @returns True if astNode.type === SelectorList.
 */
const isSelectorListNode = astNode => {
  return (astNode === null || astNode === void 0 ? void 0 : astNode.type) === NODE.SELECTOR_LIST;
};

/**
 * Checks whether the type of `astNode` is Selector.
 *
 * @param astNode Ast node.
 *
 * @returns True if astNode.type === Selector.
 */
const isSelectorNode = astNode => {
  return (astNode === null || astNode === void 0 ? void 0 : astNode.type) === NODE.SELECTOR;
};

/**
 * Checks whether the type of `astNode` is RegularSelector.
 *
 * @param astNode Ast node.
 *
 * @returns True if astNode.type === RegularSelector.
 */
const isRegularSelectorNode = astNode => {
  return (astNode === null || astNode === void 0 ? void 0 : astNode.type) === NODE.REGULAR_SELECTOR;
};

/**
 * Checks whether the type of `astNode` is ExtendedSelector.
 *
 * @param astNode Ast node.
 *
 * @returns True if astNode.type === ExtendedSelector.
 */
const isExtendedSelectorNode = astNode => {
  return astNode.type === NODE.EXTENDED_SELECTOR;
};

/**
 * Checks whether the type of `astNode` is AbsolutePseudoClass.
 *
 * @param astNode Ast node.
 *
 * @returns True if astNode.type === AbsolutePseudoClass.
 */
const isAbsolutePseudoClassNode = astNode => {
  return (astNode === null || astNode === void 0 ? void 0 : astNode.type) === NODE.ABSOLUTE_PSEUDO_CLASS;
};

/**
 * Checks whether the type of `astNode` is RelativePseudoClass.
 *
 * @param astNode Ast node.
 *
 * @returns True if astNode.type === RelativePseudoClass.
 */
const isRelativePseudoClassNode = astNode => {
  return (astNode === null || astNode === void 0 ? void 0 : astNode.type) === NODE.RELATIVE_PSEUDO_CLASS;
};

/**
 * Returns name of `astNode`.
 *
 * @param astNode AbsolutePseudoClass or RelativePseudoClass node.
 *
 * @returns Name of `astNode`.
 * @throws An error on unsupported ast node or no name found.
 */
const getNodeName = astNode => {
  if (astNode === null) {
    throw new Error('Ast node should be defined');
  }
  if (!isAbsolutePseudoClassNode(astNode) && !isRelativePseudoClassNode(astNode)) {
    throw new Error('Only AbsolutePseudoClass or RelativePseudoClass ast node can have a name');
  }
  if (!astNode.name) {
    throw new Error('Extended pseudo-class should have a name');
  }
  return astNode.name;
};

/**
 * Returns value of `astNode`.
 *
 * @param astNode RegularSelector or AbsolutePseudoClass node.
 * @param errorMessage Optional error message if no value found.
 *
 * @returns Value of `astNode`.
 * @throws An error on unsupported ast node or no value found.
 */
const getNodeValue = (astNode, errorMessage) => {
  if (astNode === null) {
    throw new Error('Ast node should be defined');
  }
  if (!isRegularSelectorNode(astNode) && !isAbsolutePseudoClassNode(astNode)) {
    throw new Error('Only RegularSelector ot AbsolutePseudoClass ast node can have a value');
  }
  if (!astNode.value) {
    throw new Error(errorMessage || 'Ast RegularSelector ot AbsolutePseudoClass node should have a value');
  }
  return astNode.value;
};

/**
 * Returns only RegularSelector nodes from `children`.
 *
 * @param children Array of ast node children.
 *
 * @returns Array of RegularSelector nodes.
 */
const getRegularSelectorNodes = children => {
  return children.filter(isRegularSelectorNode);
};

/**
 * Returns the first RegularSelector node from `children`.
 *
 * @param children Array of ast node children.
 * @param errorMessage Optional error message if no value found.
 *
 * @returns Ast RegularSelector node.
 * @throws An error if no RegularSelector node found.
 */
const getFirstRegularChild = (children, errorMessage) => {
  const regularSelectorNodes = getRegularSelectorNodes(children);
  const firstRegularSelectorNode = getFirst(regularSelectorNodes);
  if (!firstRegularSelectorNode) {
    throw new Error(errorMessage || NO_REGULAR_SELECTOR_ERROR);
  }
  return firstRegularSelectorNode;
};

/**
 * Returns the last RegularSelector node from `children`.
 *
 * @param children Array of ast node children.
 *
 * @returns Ast RegularSelector node.
 * @throws An error if no RegularSelector node found.
 */
const getLastRegularChild = children => {
  const regularSelectorNodes = getRegularSelectorNodes(children);
  const lastRegularSelectorNode = getLast(regularSelectorNodes);
  if (!lastRegularSelectorNode) {
    throw new Error(NO_REGULAR_SELECTOR_ERROR);
  }
  return lastRegularSelectorNode;
};

/**
 * Returns the only child of `node`.
 *
 * @param node Ast node.
 * @param errorMessage Error message.
 *
 * @returns The only child of ast node.
 * @throws An error if none or more than one child found.
 */
const getNodeOnlyChild = (node, errorMessage) => {
  if (node.children.length !== 1) {
    throw new Error(errorMessage);
  }
  const onlyChild = getFirst(node.children);
  if (!onlyChild) {
    throw new Error(errorMessage);
  }
  return onlyChild;
};

/**
 * Takes ExtendedSelector node and returns its only child.
 *
 * @param extendedSelectorNode ExtendedSelector ast node.
 *
 * @returns AbsolutePseudoClass or RelativePseudoClass.
 * @throws An error if there is no specific pseudo-class ast node.
 */
const getPseudoClassNode = extendedSelectorNode => {
  return getNodeOnlyChild(extendedSelectorNode, 'Extended selector should be specified');
};

/**
 * Takes RelativePseudoClass node and returns its only child
 * which is relative SelectorList node.
 *
 * @param pseudoClassNode RelativePseudoClass.
 *
 * @returns Relative SelectorList node.
 * @throws An error if no selector list found.
 */
const getRelativeSelectorListNode = pseudoClassNode => {
  if (!isRelativePseudoClassNode(pseudoClassNode)) {
    throw new Error('Only RelativePseudoClass node can have relative SelectorList node as child');
  }
  return getNodeOnlyChild(pseudoClassNode, `Missing arg for :${getNodeName(pseudoClassNode)}() pseudo-class`);
};

const ATTRIBUTE_CASE_INSENSITIVE_FLAG = 'i';

/**
 * Checks whether the passed token is supported extended pseudo-class.
 *
 * @param tokenValue Token value to check.
 *
 * @returns True if `tokenValue` is one of supported extended pseudo-class names.
 */
const isSupportedPseudoClass = tokenValue => {
  return SUPPORTED_PSEUDO_CLASSES.includes(tokenValue);
};

/**
 * Checks whether the passed pseudo-class `name` should be optimized,
 * i.e. :not() and :is().
 *
 * @param name Pseudo-class name.
 *
 * @returns True if `name` is one if pseudo-class which should be optimized.
 */
const isOptimizationPseudoClass = name => {
  return OPTIMIZATION_PSEUDO_CLASSES.includes(name);
};

/**
 * Checks whether next to "space" token is a continuation of regular selector being processed.
 *
 * @param nextTokenType Type of token next to current one.
 * @param nextTokenValue Value of token next to current one.
 *
 * @returns True if next token seems to be a part of current regular selector.
 */
const doesRegularContinueAfterSpace = (nextTokenType, nextTokenValue) => {
  // regular selector does not continues after the current token
  if (!nextTokenType || !nextTokenValue) {
    return false;
  }
  return COMBINATORS.includes(nextTokenValue) || nextTokenType === TOKEN_TYPE.WORD
  // e.g. '#main *:has(> .ad)'
  || nextTokenValue === ASTERISK || nextTokenValue === ID_MARKER || nextTokenValue === CLASS_MARKER
  // e.g. 'div :where(.content)'
  || nextTokenValue === COLON
  // e.g. "div[class*=' ']"
  || nextTokenValue === SINGLE_QUOTE
  // e.g. 'div[class*=" "]'
  || nextTokenValue === DOUBLE_QUOTE || nextTokenValue === BRACKET.SQUARE.LEFT;
};

/**
 * Checks whether the regexp pattern for pseudo-class arg starts.
 * Needed for `context.isRegexpOpen` flag.
 *
 * @param context Selector parser context.
 * @param prevTokenValue Value of previous token.
 * @param bufferNodeValue Value of bufferNode.
 *
 * @returns True if current token seems to be a start of regexp pseudo-class arg pattern.
 * @throws An error on invalid regexp pattern.
 */
const isRegexpOpening = (context, prevTokenValue, bufferNodeValue) => {
  const lastExtendedPseudoClassName = getLast(context.extendedPseudoNamesStack);
  if (!lastExtendedPseudoClassName) {
    throw new Error('Regexp pattern allowed only in arg of extended pseudo-class');
  }
  // for regexp pattens the slash should not be escaped
  // const isRegexpPatternSlash = prevTokenValue !== BACKSLASH;
  // regexp pattern can be set as arg of pseudo-class
  // which means limited list of available symbols before slash `/`;
  // for :contains() pseudo-class regexp pattern should be at the beginning of arg
  if (CONTAINS_PSEUDO_NAMES.includes(lastExtendedPseudoClassName)) {
    return POSSIBLE_MARKS_BEFORE_REGEXP.CONTAINS.includes(prevTokenValue);
  }
  if (prevTokenValue === SLASH && lastExtendedPseudoClassName !== XPATH_PSEUDO_CLASS_MARKER) {
    const rawArgDesc = bufferNodeValue ? `in arg part: '${bufferNodeValue}'` : 'arg';
    throw new Error(`Invalid regexp pattern for :${lastExtendedPseudoClassName}() pseudo-class ${rawArgDesc}`);
  }

  // for other pseudo-classes regexp pattern can be either the whole arg or its part
  return POSSIBLE_MARKS_BEFORE_REGEXP.COMMON.includes(prevTokenValue);
};

/**
 * Checks whether the attribute starts.
 *
 * @param tokenValue Value of current token.
 * @param prevTokenValue Previous token value.
 *
 * @returns True if combination of current and previous token seems to be **a start** of attribute.
 */
const isAttributeOpening = (tokenValue, prevTokenValue) => {
  return tokenValue === BRACKET.SQUARE.LEFT && prevTokenValue !== BACKSLASH;
};

/**
 * Checks whether the attribute ends.
 *
 * @param context Selector parser context.
 *
 * @returns True if combination of current and previous token seems to be **an end** of attribute.
 * @throws An error on invalid attribute.
 */
const isAttributeClosing = context => {
  var _getPrevToLast;
  if (!context.isAttributeBracketsOpen) {
    return false;
  }
  // valid attributes may have extra spaces inside.
  // we get rid of them just to simplify the checking and they are skipped only here:
  //   - spaces will be collected to the ast with spaces as they were declared is selector
  //   - extra spaces in attribute are not relevant to attribute syntax validity
  //     e.g. 'a[ title ]' is the same as 'a[title]'
  //          'div[style *= "MARGIN" i]' is the same as 'div[style*="MARGIN"i]'
  const noSpaceAttr = context.attributeBuffer.split(SPACE).join('');
  // tokenize the prepared attribute string
  const attrTokens = tokenizeAttribute(noSpaceAttr);
  const firstAttrToken = getFirst(attrTokens);
  const firstAttrTokenType = firstAttrToken === null || firstAttrToken === void 0 ? void 0 : firstAttrToken.type;
  const firstAttrTokenValue = firstAttrToken === null || firstAttrToken === void 0 ? void 0 : firstAttrToken.value;
  // signal an error on any mark-type token except backslash
  // e.g. '[="margin"]'
  if (firstAttrTokenType === TOKEN_TYPE.MARK
  // backslash is allowed at start of attribute
  // e.g. '[\\:data-service-slot]'
  && firstAttrTokenValue !== BACKSLASH) {
    // eslint-disable-next-line max-len
    throw new Error(`'[${context.attributeBuffer}]' is not a valid attribute due to '${firstAttrTokenValue}' at start of it`);
  }
  const lastAttrToken = getLast(attrTokens);
  const lastAttrTokenType = lastAttrToken === null || lastAttrToken === void 0 ? void 0 : lastAttrToken.type;
  const lastAttrTokenValue = lastAttrToken === null || lastAttrToken === void 0 ? void 0 : lastAttrToken.value;
  if (lastAttrTokenValue === EQUAL_SIGN) {
    // e.g. '[style=]'
    throw new Error(`'[${context.attributeBuffer}]' is not a valid attribute due to '${EQUAL_SIGN}'`);
  }
  const equalSignIndex = attrTokens.findIndex(token => {
    return token.type === TOKEN_TYPE.MARK && token.value === EQUAL_SIGN;
  });
  const prevToLastAttrTokenValue = (_getPrevToLast = getPrevToLast(attrTokens)) === null || _getPrevToLast === void 0 ? void 0 : _getPrevToLast.value;
  if (equalSignIndex === -1) {
    // if there is no '=' inside attribute,
    // it must be just attribute name which means the word-type token before closing bracket
    // e.g. 'div[style]'
    if (lastAttrTokenType === TOKEN_TYPE.WORD) {
      return true;
    }
    return prevToLastAttrTokenValue === BACKSLASH
    // some weird attribute are valid too
    // e.g. '[class\\"ads-article\\"]'
    && (lastAttrTokenValue === DOUBLE_QUOTE
    // e.g. "[class\\'ads-article\\']"
    || lastAttrTokenValue === SINGLE_QUOTE);
  }

  // get the value of token next to `=`
  const nextToEqualSignToken = getItemByIndex(attrTokens, equalSignIndex + 1);
  const nextToEqualSignTokenValue = nextToEqualSignToken.value;
  // check whether the attribute value wrapper in quotes
  const isAttrValueQuote = nextToEqualSignTokenValue === SINGLE_QUOTE || nextToEqualSignTokenValue === DOUBLE_QUOTE;

  // for no quotes after `=` the last token before `]` should be a word-type one
  // e.g. 'div[style*=margin]'
  //      'div[style*=MARGIN i]'
  if (!isAttrValueQuote) {
    if (lastAttrTokenType === TOKEN_TYPE.WORD) {
      return true;
    }
    // otherwise signal an error
    // e.g. 'table[style*=border: 0px"]'
    throw new Error(`'[${context.attributeBuffer}]' is not a valid attribute`);
  }

  // otherwise if quotes for value are present
  // the last token before `]` can still be word-type token
  // e.g. 'div[style*="MARGIN" i]'
  if (lastAttrTokenType === TOKEN_TYPE.WORD && (lastAttrTokenValue === null || lastAttrTokenValue === void 0 ? void 0 : lastAttrTokenValue.toLocaleLowerCase()) === ATTRIBUTE_CASE_INSENSITIVE_FLAG) {
    return prevToLastAttrTokenValue === nextToEqualSignTokenValue;
  }

  // eventually if there is quotes for attribute value and last token is not a word,
  // the closing mark should be the same quote as opening one
  return lastAttrTokenValue === nextToEqualSignTokenValue;
};

/**
 * Checks whether the character is a whitespace character.
 *
 * @param char Character to check.
 *
 * @returns True if the character is a whitespace character.
 */
const isWhiteSpaceChar = char => {
  return char !== undefined && WHITE_SPACE_CHARACTERS.includes(char);
};

/**
 * Returns string without suffix.
 *
 * @param str Input string.
 * @param suffix Needed to remove.
 *
 * @returns String without suffix.
 */
const removeSuffix = (str, suffix) => {
  const index = str.indexOf(suffix, str.length - suffix.length);
  if (index >= 0) {
    return str.substring(0, index);
  }
  return str;
};

/**
 * Replaces all `pattern`s with `replacement` in `input` string.
 * String.replaceAll() polyfill because it is not supported by old browsers, e.g. Chrome 55.
 *
 * @see {@link https://caniuse.com/?search=String.replaceAll}
 *
 * @param input Input string to process.
 * @param pattern Find in the input string.
 * @param replacement Replace the pattern with.
 *
 * @returns Modified string.
 */
const replaceAll = (input, pattern, replacement) => {
  if (!input) {
    return input;
  }
  return input.split(pattern).join(replacement);
};

/**
 * Converts string pattern to regular expression.
 *
 * @param str String to convert.
 *
 * @returns Regular expression converted from pattern `str`.
 */
const toRegExp = str => {
  if (str.startsWith(SLASH) && str.endsWith(SLASH)) {
    return new RegExp(str.slice(1, -1));
  }
  const escaped = str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(escaped);
};

/**
 * Converts any simple type value to string type,
 * e.g. `undefined` -> `'undefined'`.
 *
 * @param value Any type value.
 *
 * @returns String representation of `value`.
 */
const convertTypeIntoString = value => {
  let output;
  switch (value) {
    case undefined:
      output = 'undefined';
      break;
    case null:
      output = 'null';
      break;
    default:
      output = value.toString();
  }
  return output;
};

/**
 * Converts instance of string value into other simple types,
 * e.g. `'null'` -> `null`, `'true'` -> `true`.
 *
 * @param value String-type value.
 *
 * @returns Its own type representation of string-type `value`.
 */
const convertTypeFromString = value => {
  const numValue = Number(value);
  let output;
  if (!Number.isNaN(numValue)) {
    output = numValue;
  } else {
    switch (value) {
      case 'undefined':
        output = undefined;
        break;
      case 'null':
        output = null;
        break;
      case 'true':
        output = true;
        break;
      case 'false':
        output = false;
        break;
      default:
        output = value;
    }
  }
  return output;
};

/**
 * Checks whether the passed `str` is a name of supported absolute extended pseudo-class,
 * e.g. :contains(), :matches-css() etc.
 *
 * @param str Token value to check.
 *
 * @returns True if `str` is one of absolute extended pseudo-class names.
 */
const isAbsolutePseudoClass = str => {
  return ABSOLUTE_PSEUDO_CLASSES.includes(str);
};

/**
 * Checks whether the passed `str` is a name of supported relative extended pseudo-class,
 * e.g. :has(), :not() etc.
 *
 * @param str Token value to check.
 *
 * @returns True if `str` is one of relative extended pseudo-class names.
 */
const isRelativePseudoClass = str => {
  return RELATIVE_PSEUDO_CLASSES.includes(str);
};

/**
 * Checks whether the passed `str` is a name of standalone extended pseudo-class,
 * i.e. a no-argument pseudo-class that tests the element itself (e.g. :empty-trimmed).
 *
 * @param str Token value to check.
 *
 * @returns True if `str` is one of standalone pseudo-class names.
 */
const isStandalonePseudoClass = str => {
  return STANDALONE_PSEUDO_CLASSES.includes(str);
};

/**
 * Regexp literal action argument, e.g. `/^data-/i`.
 * The second capture group contains the regexp flags.
 */
const REGEXP_ACTION_ARG = /^\/(.+)\/([imu]*)$/;

/**
 * Plain action argument: no whitespace, parentheses, quotes or commas.
 */
const PLAIN_ACTION_ARG = /^[^\s()'",]+$/;

/**
 * Checks whether the string is an action pseudo-class marker.
 *
 * @param marker Marker to check.
 *
 * @returns True if the string is an action pseudo-class marker.
 */
const isActionPseudoMarker = marker => {
  return ACTION_PSEUDO_MARKERS.includes(marker);
};

/**
 * Checks whether the string is an action pseudo-class marker stored in styles.
 *
 * @param marker Marker to check.
 *
 * @returns True if the string is an action style marker.
 */
const isActionStyleMarker = marker => {
  return ACTION_STYLE_MARKERS.includes(marker);
};

/**
 * Throws an error for invalid action pseudo-class usage.
 *
 * @param marker Action pseudo-class marker.
 * @param messageKey Key of the error message.
 * @param selector Selector which caused the error.
 *
 * @throws An error with the message for the action pseudo-class.
 */
const throwActionError = (marker, messageKey, selector) => {
  throw new Error(`${ACTION_ERROR_PREFIXES[marker][messageKey]}: '${selector}'`);
};

/**
 * Maximum number of cached action argument matchers.
 * The cache is bounded because the `beforeStyleApplied` callback
 * can supply new arguments on every pass.
 */
const MAX_ACTION_ARG_MATCHERS_COUNT = 100;

/**
 * Cache of compiled action argument matchers.
 * Entries are evicted in least-recently-used order when the cache is full.
 */
const actionArgMatchers = new Map();

/**
 * Checks whether a regexp literal argument compiles.
 *
 * @param arg Regexp literal argument.
 *
 * @returns True if the regexp is valid.
 */
const isValidRegexpArg = arg => {
  const match = arg.match(REGEXP_ACTION_ARG);
  if (!match) {
    return false;
  }
  try {
    new RegExp(match[1], match[2]);
    return true;
  } catch (e) {
    return false;
  }
};

/**
 * Normalizes an action argument: strips quotes, validates plain args
 * and compiles regexp literals.
 *
 * @param rawArg Raw action argument.
 *
 * @returns Normalized argument or an empty string if the argument is invalid.
 */
const normalizeActionArg = rawArg => {
  const arg = rawArg.trim();
  if (!arg) {
    return '';
  }
  if (arg.startsWith(SLASH)) {
    return isValidRegexpArg(arg) ? arg : '';
  }
  if (arg.length > 1 && (arg.startsWith(SINGLE_QUOTE) && arg.endsWith(SINGLE_QUOTE) || arg.startsWith(DOUBLE_QUOTE) && arg.endsWith(DOUBLE_QUOTE))) {
    const unquoted = arg.slice(1, -1);
    return PLAIN_ACTION_ARG.test(unquoted) ? unquoted : '';
  }
  return PLAIN_ACTION_ARG.test(arg) ? arg : '';
};

/**
 * Creates a matcher for an action argument.
 *
 * Plain arguments match exactly; regexp literal arguments match as regexps.
 * Invalid regexp arguments produce a matcher which never matches.
 *
 * @param arg Normalized action argument.
 *
 * @returns Matcher function for attribute or class names.
 */
const createActionArgMatcher = arg => {
  const cached = actionArgMatchers.get(arg);
  if (cached) {
    // refresh the entry to keep the cache least-recently-used
    actionArgMatchers.delete(arg);
    actionArgMatchers.set(arg, cached);
    return cached;
  }
  let matcher;
  const match = arg.match(REGEXP_ACTION_ARG);
  if (match) {
    try {
      const regexp = new RegExp(match[1], match[2]);
      matcher = value => {
        return regexp.test(value);
      };
    } catch (e) {
      matcher = () => {
        return false;
      };
    }
  } else {
    matcher = value => {
      return value === arg;
    };
  }

  // evict the least recently used entry if the cache is full
  if (actionArgMatchers.size >= MAX_ACTION_ARG_MATCHERS_COUNT) {
    const oldestArg = actionArgMatchers.keys().next().value;
    if (oldestArg !== undefined) {
      actionArgMatchers.delete(oldestArg);
    }
  }
  actionArgMatchers.set(arg, matcher);
  return matcher;
};

/**
 * Returns the node which is being collected
 * or null if there is no such one.
 *
 * @param context Selector parser context.
 *
 * @returns Buffer node or null.
 */
const getBufferNode = context => {
  if (context.pathToBufferNode.length === 0) {
    return null;
  }
  // buffer node is always the last in the pathToBufferNode stack
  return getLast(context.pathToBufferNode) || null;
};

/**
 * Returns the parent node to the 'buffer node' — which is the one being collected —
 * or null if there is no such one.
 *
 * @param context Selector parser context.
 *
 * @returns Parent node of buffer node or null.
 */
const getBufferNodeParent = context => {
  // at least two nodes should exist — the buffer node and its parent
  // otherwise return null
  if (context.pathToBufferNode.length < 2) {
    return null;
  }
  // since the buffer node is always the last in the pathToBufferNode stack
  // its parent is previous to it in the stack
  return getPrevToLast(context.pathToBufferNode) || null;
};

/**
 * Returns last RegularSelector ast node.
 * Needed for parsing of the complex selector with extended pseudo-class inside it.
 *
 * @param context Selector parser context.
 *
 * @returns Ast RegularSelector node.
 * @throws An error if:
 * - bufferNode is absent;
 * - type of bufferNode is unsupported;
 * - no RegularSelector in bufferNode.
 */
const getContextLastRegularSelectorNode = context => {
  const bufferNode = getBufferNode(context);
  if (!bufferNode) {
    throw new Error('No bufferNode found');
  }
  if (!isSelectorNode(bufferNode)) {
    throw new Error('Unsupported bufferNode type');
  }
  const lastRegularSelectorNode = getLastRegularChild(bufferNode.children);
  context.pathToBufferNode.push(lastRegularSelectorNode);
  return lastRegularSelectorNode;
};

/**
 * Updates needed buffer node value while tokens iterating.
 * For RegularSelector also collects token values to context.attributeBuffer
 * for proper attribute parsing.
 *
 * @param context Selector parser context.
 * @param tokenValue Value of current token.
 *
 * @throws An error if:
 * - no bufferNode;
 * - bufferNode.type is not RegularSelector or AbsolutePseudoClass.
 */
const updateBufferNode = (context, tokenValue) => {
  const bufferNode = getBufferNode(context);
  if (bufferNode === null) {
    throw new Error('No bufferNode to update');
  }
  if (isAbsolutePseudoClassNode(bufferNode)) {
    bufferNode.value += tokenValue;
  } else if (isRegularSelectorNode(bufferNode)) {
    bufferNode.value += tokenValue;
    if (context.isAttributeBracketsOpen) {
      context.attributeBuffer += tokenValue;
    }
  } else {
    // eslint-disable-next-line max-len
    throw new Error(`${bufferNode.type} node cannot be updated. Only RegularSelector and AbsolutePseudoClass are supported`);
  }
};

/**
 * Adds SelectorList node to context.ast at the start of ast collecting.
 *
 * @param context Selector parser context.
 */
const addSelectorListNode = context => {
  const selectorListNode = new AnySelectorNode(NODE.SELECTOR_LIST);
  context.ast = selectorListNode;
  context.pathToBufferNode.push(selectorListNode);
};

/**
 * Adds new node to buffer node children.
 * New added node will be considered as buffer node after it.
 *
 * @param context Selector parser context.
 * @param type Type of node to add.
 * @param tokenValue Optional, defaults to `''`, value of processing token.
 *
 * @throws An error if no bufferNode.
 */
const addAstNodeByType = function (context, type) {
  let tokenValue = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
  const bufferNode = getBufferNode(context);
  if (bufferNode === null) {
    throw new Error('No buffer node');
  }
  let node;
  if (type === NODE.REGULAR_SELECTOR) {
    node = new RegularSelectorNode(tokenValue);
  } else if (type === NODE.ABSOLUTE_PSEUDO_CLASS) {
    node = new AbsolutePseudoClassNode(tokenValue);
  } else if (type === NODE.RELATIVE_PSEUDO_CLASS) {
    node = new RelativePseudoClassNode(tokenValue);
  } else {
    // SelectorList || Selector || ExtendedSelector
    node = new AnySelectorNode(type);
  }
  bufferNode.addChild(node);
  context.pathToBufferNode.push(node);
};

/**
 * The very beginning of ast collecting.
 *
 * @param context Selector parser context.
 * @param tokenValue Value of regular selector.
 */
const initAst = (context, tokenValue) => {
  addSelectorListNode(context);
  addAstNodeByType(context, NODE.SELECTOR);
  // RegularSelector node is always the first child of Selector node
  addAstNodeByType(context, NODE.REGULAR_SELECTOR, tokenValue);
};

/**
 * Inits selector list subtree for relative extended pseudo-classes, e.g. :has(), :not().
 *
 * @param context Selector parser context.
 * @param tokenValue Optional, defaults to `''`, value of inner regular selector.
 */
const initRelativeSubtree = function (context) {
  let tokenValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
  addAstNodeByType(context, NODE.SELECTOR_LIST);
  addAstNodeByType(context, NODE.SELECTOR);
  addAstNodeByType(context, NODE.REGULAR_SELECTOR, tokenValue);
};

/**
 * Goes to closest parent specified by type.
 * Actually updates path to buffer node for proper ast collecting of selectors while parsing.
 *
 * @param context Selector parser context.
 * @param parentType Type of needed parent node in ast.
 */
const upToClosest = (context, parentType) => {
  for (let i = context.pathToBufferNode.length - 1; i >= 0; i -= 1) {
    var _context$pathToBuffer;
    if (((_context$pathToBuffer = context.pathToBufferNode[i]) === null || _context$pathToBuffer === void 0 ? void 0 : _context$pathToBuffer.type) === parentType) {
      context.pathToBufferNode = context.pathToBufferNode.slice(0, i + 1);
      break;
    }
  }
};

/**
 * Returns needed buffer node updated due to complex selector parsing.
 *
 * @param context Selector parser context.
 *
 * @returns Ast node for following selector parsing.
 * @throws An error if there is no upper SelectorNode is ast.
 */
const getUpdatedBufferNode = context => {
  // it may happen during the parsing of selector list
  // which is an argument of relative pseudo-class
  // e.g. '.banner:has(~span, ~p)'
  // parser position is here  ↑
  // so if after the comma the buffer node type is SelectorList and parent type is RelativePseudoClass
  // we should simply return the current buffer node
  const bufferNode = getBufferNode(context);
  if (bufferNode && isSelectorListNode(bufferNode) && isRelativePseudoClassNode(getBufferNodeParent(context))) {
    return bufferNode;
  }
  upToClosest(context, NODE.SELECTOR);
  const selectorNode = getBufferNode(context);
  if (!selectorNode) {
    throw new Error('No SelectorNode, impossible to continue selector parsing by ExtendedCss');
  }
  const lastSelectorNodeChild = getLast(selectorNode.children);
  const hasExtended = lastSelectorNodeChild && isExtendedSelectorNode(lastSelectorNodeChild)
  // parser position might be inside standard pseudo-class brackets which has space
  // e.g. 'div:contains(/а/):nth-child(100n + 2)'
  && context.standardPseudoBracketsStack.length === 0;
  const supposedPseudoClassNode = hasExtended && getFirst(lastSelectorNodeChild.children);
  let newNeededBufferNode = selectorNode;
  if (supposedPseudoClassNode) {
    // name of pseudo-class for last extended-node child for Selector node
    const lastExtendedPseudoName = hasExtended && supposedPseudoClassNode.name;
    const isLastExtendedNameRelative = lastExtendedPseudoName && isRelativePseudoClass(lastExtendedPseudoName);
    const isLastExtendedNameAbsolute = lastExtendedPseudoName && isAbsolutePseudoClass(lastExtendedPseudoName);
    const hasRelativeExtended = isLastExtendedNameRelative && context.extendedPseudoBracketsStack.length > 0 && context.extendedPseudoBracketsStack.length === context.extendedPseudoNamesStack.length;
    const hasAbsoluteExtended = isLastExtendedNameAbsolute && lastExtendedPseudoName === getLast(context.extendedPseudoNamesStack);
    if (hasRelativeExtended) {
      // return relative selector node to update later
      context.pathToBufferNode.push(lastSelectorNodeChild);
      newNeededBufferNode = supposedPseudoClassNode;
    } else if (hasAbsoluteExtended) {
      // return absolute selector node to update later
      context.pathToBufferNode.push(lastSelectorNodeChild);
      newNeededBufferNode = supposedPseudoClassNode;
    }
  } else if (hasExtended) {
    // return selector node to add new regular selector node later
    newNeededBufferNode = selectorNode;
  } else {
    // otherwise return last regular selector node to update later
    newNeededBufferNode = getContextLastRegularSelectorNode(context);
  }
  // update the path to buffer node properly
  context.pathToBufferNode.push(newNeededBufferNode);
  return newNeededBufferNode;
};

/**
 * Checks values of few next tokens on colon token `:` and:
 *  - updates buffer node for following standard pseudo-class;
 *  - adds extended selector ast node for following extended pseudo-class;
 *  - validates some cases of action pseudo-classes and `:has()` usage.
 *
 * @param context Selector parser context.
 * @param selector Selector.
 * @param tokenValue Value of current token.
 * @param nextTokenValue Value of token next to current one.
 * @param nextToNextTokenValue Value of token next to next to current one.
 *
 * @throws An error on action pseudo-class in selector
 * or :has() inside regular pseudo limitation.
 */
const handleNextTokenOnColon = (context, selector, tokenValue, nextTokenValue, nextToNextTokenValue) => {
  if (context.quoteCharacter) {
    // the colon is inside a quoted value and is not a pseudo-class start,
    // e.g. ':upward([data-x=":remove-attr(title)"])'
    updateBufferNode(context, tokenValue);
    return;
  }
  if (!nextTokenValue) {
    throw new Error(`Invalid colon ':' at the end of selector: '${selector}'`);
  }
  if (!isSupportedPseudoClass(nextTokenValue.toLowerCase())) {
    const actionMarker = nextTokenValue.toLowerCase();
    if (isActionPseudoMarker(actionMarker)) {
      // Action pseudo-classes should be handled before
      // as they are not about element selecting but actions with elements
      // e.g. 'body > div:empty:remove()'
      throwActionError(actionMarker, 'INVALID_ACTION', selector);
    }
    // if following token is not an extended pseudo
    // the colon should be collected to value of RegularSelector
    // e.g. '.entry_text:nth-child(2)'
    updateBufferNode(context, tokenValue);
    // check the token after the pseudo and do balance parentheses later
    // only if it is functional pseudo-class (standard with brackets, e.g. ':lang()').
    // no brackets balance needed for such case,
    // parser position is on first colon after the 'div':
    // e.g. 'div:last-child:has(button.privacy-policy__btn)'
    if (nextToNextTokenValue && nextToNextTokenValue === BRACKET.PARENTHESES.LEFT
    // no brackets balance needed for parentheses inside attribute value
    // e.g. 'a[href="javascript:void(0)"]'   <-- parser position is on colon `:`
    // before `void`           ↑
    && !context.isAttributeBracketsOpen) {
      context.standardPseudoNamesStack.push(nextTokenValue);
    }
  } else {
    // it is supported extended pseudo-class.
    // Disallow :has() inside the pseudos accepting only compound selectors
    // https://bugs.chromium.org/p/chromium/issues/detail?id=669058#c54 [2]
    if (HAS_PSEUDO_CLASS_MARKERS.includes(nextTokenValue) && context.standardPseudoNamesStack.length > 0) {
      // eslint-disable-next-line max-len
      throw new Error(`Usage of :${nextTokenValue}() pseudo-class is not allowed inside regular pseudo: '${getLast(context.standardPseudoNamesStack)}'`);
    } else {
      // stop RegularSelector value collecting
      upToClosest(context, NODE.SELECTOR);
      // add ExtendedSelector to Selector children
      addAstNodeByType(context, NODE.EXTENDED_SELECTOR);
    }
  }
};

// limit applying of wildcard :is() and :not() pseudo-class only to html children
// e.g. ':is(.page, .main) > .banner' or '*:not(span):not(p)'
const IS_OR_NOT_PSEUDO_SELECTING_ROOT = `html ${ASTERISK}`;

/**
 * Checks if there are any ExtendedSelector node in selector list.
 *
 * @param selectorList Ast SelectorList node.
 *
 * @returns True if `selectorList` has any inner ExtendedSelector node.
 */
const hasExtendedSelector = selectorList => {
  return selectorList.children.some(selectorNode => {
    return selectorNode.children.some(selectorNodeChild => {
      return isExtendedSelectorNode(selectorNodeChild);
    });
  });
};

/**
 * Converts selector list of RegularSelector nodes to string.
 *
 * @param selectorList Ast SelectorList node.
 *
 * @returns String representation for selector list of regular selectors.
 */
const selectorListOfRegularsToString = selectorList => {
  // if there is no ExtendedSelector in relative SelectorList
  // it means that each Selector node has single child — RegularSelector node
  // and their values should be combined to string
  const standardCssSelectors = selectorList.children.map(selectorNode => {
    const selectorOnlyChild = getNodeOnlyChild(selectorNode, 'Ast Selector node should have RegularSelector node');
    return getNodeValue(selectorOnlyChild);
  });
  return standardCssSelectors.join(`${COMMA}${SPACE}`);
};

/**
 * Updates children of `node` replacing them with `newChildren`.
 * Important: modifies input `node` which is passed by reference.
 *
 * @param node Ast node to update.
 * @param newChildren Array of new children for ast node.
 *
 * @returns Updated ast node.
 */
const updateNodeChildren = (node, newChildren) => {
  node.children = newChildren;
  return node;
};

/**
 * Recursively checks whether the ExtendedSelector node should be optimized.
 * It has to be recursive because RelativePseudoClass has inner SelectorList node.
 *
 * @param currExtendedSelectorNode Ast ExtendedSelector node.
 *
 * @returns True is ExtendedSelector should be optimized.
 */
const shouldOptimizeExtendedSelector = currExtendedSelectorNode => {
  if (currExtendedSelectorNode === null) {
    return false;
  }
  const extendedPseudoClassNode = getPseudoClassNode(currExtendedSelectorNode);
  const pseudoName = getNodeName(extendedPseudoClassNode);
  if (isAbsolutePseudoClass(pseudoName)) {
    return false;
  }
  // Standalone pseudo-classes (e.g. :empty-trimmed) do not have selector-list args.
  // They cannot be optimized and should remain as standalone ExtendedSelector nodes.
  if (isStandalonePseudoClass(pseudoName)) {
    return false;
  }
  const relativeSelectorList = getRelativeSelectorListNode(extendedPseudoClassNode);
  const innerSelectorNodes = relativeSelectorList.children;
  // simple checking for standard selectors in arg of :not() or :is() pseudo-class
  // e.g. 'div > *:is(div, a, span)'
  if (isOptimizationPseudoClass(pseudoName)) {
    const areAllSelectorNodeChildrenRegular = innerSelectorNodes.every(selectorNode => {
      try {
        const selectorOnlyChild = getNodeOnlyChild(selectorNode, 'Selector node should have RegularSelector');
        // it means that the only child is RegularSelector and it can be optimized
        return isRegularSelectorNode(selectorOnlyChild);
      } catch (e) {
        return false;
      }
    });
    if (areAllSelectorNodeChildrenRegular) {
      return true;
    }
  }
  // for other extended pseudo-classes than :not() and :is()
  return innerSelectorNodes.some(selectorNode => {
    return selectorNode.children.some(selectorNodeChild => {
      if (!isExtendedSelectorNode(selectorNodeChild)) {
        return false;
      }
      // check inner ExtendedSelector recursively
      // e.g. 'div:has(*:not(.header))'
      return shouldOptimizeExtendedSelector(selectorNodeChild);
    });
  });
};

/**
 * Returns optimized ExtendedSelector node if it can be optimized
 * or null if ExtendedSelector is fully optimized while function execution
 * which means that value of `prevRegularSelectorNode` is updated.
 *
 * @param currExtendedSelectorNode Current ExtendedSelector node to optimize.
 * @param prevRegularSelectorNode Previous RegularSelector node.
 *
 * @returns Ast node or null.
 */
const getOptimizedExtendedSelector = (currExtendedSelectorNode, prevRegularSelectorNode) => {
  if (!currExtendedSelectorNode) {
    return null;
  }
  const extendedPseudoClassNode = getPseudoClassNode(currExtendedSelectorNode);
  const relativeSelectorList = getRelativeSelectorListNode(extendedPseudoClassNode);
  const hasInnerExtendedSelector = hasExtendedSelector(relativeSelectorList);
  if (!hasInnerExtendedSelector) {
    // if there is no extended selectors for :not() or :is()
    // e.g. 'div:not(.content, .main)'
    const relativeSelectorListStr = selectorListOfRegularsToString(relativeSelectorList);
    const pseudoName = getNodeName(extendedPseudoClassNode);
    // eslint-disable-next-line max-len
    const optimizedExtendedStr = `${COLON}${pseudoName}${BRACKET.PARENTHESES.LEFT}${relativeSelectorListStr}${BRACKET.PARENTHESES.RIGHT}`;
    prevRegularSelectorNode.value = `${getNodeValue(prevRegularSelectorNode)}${optimizedExtendedStr}`;
    return null;
  }

  // eslint-disable-next-line @typescript-eslint/no-use-before-define
  const optimizedRelativeSelectorList = optimizeSelectorListNode(relativeSelectorList);
  const optimizedExtendedPseudoClassNode = updateNodeChildren(extendedPseudoClassNode, [optimizedRelativeSelectorList]);
  return updateNodeChildren(currExtendedSelectorNode, [optimizedExtendedPseudoClassNode]);
};

/**
 * Combines values of `previous` and `current` RegularSelector nodes.
 * It may happen during the optimization when ExtendedSelector between RegularSelector node was optimized.
 *
 * @param current Current RegularSelector node.
 * @param previous Previous RegularSelector node.
 */
const optimizeCurrentRegularSelector = (current, previous) => {
  previous.value = `${getNodeValue(previous)}${SPACE}${getNodeValue(current)}`;
};

/**
 * Optimizes ast Selector node.
 *
 * @param selectorNode Ast Selector node.
 *
 * @returns Optimized ast node.
 * @throws An error while collecting optimized nodes.
 */
const optimizeSelectorNode = selectorNode => {
  // non-optimized list of SelectorNode children
  const rawSelectorNodeChildren = selectorNode.children;
  // for collecting optimized children list
  const optimizedChildrenList = [];
  let currentIndex = 0;
  // iterate through all children in non-optimized ast Selector node
  while (currentIndex < rawSelectorNodeChildren.length) {
    const currentChild = getItemByIndex(rawSelectorNodeChildren, currentIndex, 'currentChild should be specified');
    // no need to optimize the very first child which is always RegularSelector node
    if (currentIndex === 0) {
      optimizedChildrenList.push(currentChild);
    } else {
      const prevRegularChild = getLastRegularChild(optimizedChildrenList);
      if (isExtendedSelectorNode(currentChild)) {
        // start checking with point is null
        let optimizedExtendedSelector = null;
        // check whether the optimization is needed
        let isOptimizationNeeded = shouldOptimizeExtendedSelector(currentChild);
        // update optimizedExtendedSelector so it can be optimized recursively
        // i.e. `getOptimizedExtendedSelector(optimizedExtendedSelector)` below
        optimizedExtendedSelector = currentChild;
        while (isOptimizationNeeded) {
          // recursively optimize ExtendedSelector until no optimization needed
          // e.g. div > *:is(.banner:not(.block))
          optimizedExtendedSelector = getOptimizedExtendedSelector(optimizedExtendedSelector, prevRegularChild);
          isOptimizationNeeded = shouldOptimizeExtendedSelector(optimizedExtendedSelector);
        }
        // if it was simple :not() of :is() with standard selector arg
        // e.g. 'div:not([class][id])'
        // or   '.main > *:is([data-loaded], .banner)'
        // after the optimization the ExtendedSelector node become part of RegularSelector
        // so nothing to save eventually
        // otherwise the optimized ExtendedSelector should be saved
        // e.g. 'div:has(:not([class]))'
        if (optimizedExtendedSelector !== null) {
          optimizedChildrenList.push(optimizedExtendedSelector);
          // if optimization is not needed
          const optimizedPseudoClass = getPseudoClassNode(optimizedExtendedSelector);
          const optimizedPseudoName = getNodeName(optimizedPseudoClass);
          // parent element checking is used to apply :is() and :not() pseudo-classes as extended.
          // as there is no parentNode for root element (html)
          // so element selection should be limited to it's children
          // e.g. '*:is(:has(.page))' -> 'html *:is(has(.page))'
          // or   '*:not(:has(span))' -> 'html *:not(:has(span))'
          if (getNodeValue(prevRegularChild) === ASTERISK && isOptimizationPseudoClass(optimizedPseudoName)) {
            prevRegularChild.value = IS_OR_NOT_PSEUDO_SELECTING_ROOT;
          }
        }
      } else if (isRegularSelectorNode(currentChild)) {
        // in non-optimized ast, RegularSelector node may follow ExtendedSelector which should be optimized
        // for example, for 'div:not(.content) > .banner' schematically it looks like
        // non-optimized ast: [
        //   1. RegularSelector: 'div'
        //   2. ExtendedSelector: 'not(.content)'
        //   3. RegularSelector: '> .banner'
        // ]
        // which after the ExtendedSelector looks like
        // partly optimized ast: [
        //   1. RegularSelector: 'div:not(.content)'
        //   2. RegularSelector: '> .banner'
        // ]
        // so second RegularSelector value should be combined with first one
        // optimized ast: [
        //   1. RegularSelector: 'div:not(.content) > .banner'
        // ]
        // here we check **children of selectorNode** after previous optimization if it was
        const lastOptimizedChild = getLast(optimizedChildrenList) || null;
        if (isRegularSelectorNode(lastOptimizedChild)) {
          optimizeCurrentRegularSelector(currentChild, prevRegularChild);
        }
      }
    }
    currentIndex += 1;
  }
  return updateNodeChildren(selectorNode, optimizedChildrenList);
};

/**
 * Optimizes ast SelectorList node.
 *
 * @param selectorListNode SelectorList node.
 *
 * @returns Optimized ast node.
 */
const optimizeSelectorListNode = selectorListNode => {
  return updateNodeChildren(selectorListNode, selectorListNode.children.map(s => optimizeSelectorNode(s)));
};

/**
 * Optimizes ast:
 * If arg of :not() and :is() pseudo-classes does not contain extended selectors,
 * native Document.querySelectorAll() can be used to query elements.
 * It means that ExtendedSelector ast nodes can be removed
 * and value of relevant RegularSelector node should be updated accordingly.
 *
 * @param ast Non-optimized ast.
 *
 * @returns Optimized ast.
 */
const optimizeAst = ast => {
  // ast is basically the selector list of selectors
  return optimizeSelectorListNode(ast);
};

/**
 * State of the selector scanner.
 */

/**
 * Handlers for structural marks found by the selector scanner.
 */

/**
 * Creates initial state of the selector scanner.
 *
 * @returns Initial scanner state.
 */
const createSelectorScannerState = () => {
  return {
    pseudoStack: [],
    quote: undefined,
    inRegexp: false,
    inRegexpCharClass: false,
    prevChar: undefined,
    prevNonWhitespaceChar: undefined,
    pendingPseudo: undefined
  };
};

/**
 * Saves a processed character as the previous one.
 *
 * @param state Scanner state.
 * @param char Processed character.
 */
const setPrevChar = (state, char) => {
  state.prevChar = char;
  if (char && !isWhiteSpaceChar(char)) {
    state.prevNonWhitespaceChar = char;
  }
};

/**
 * Checks whether the scanner is inside an `:xpath()` argument.
 *
 * @param state Scanner state.
 *
 * @returns True if the scanner is inside an `:xpath()` argument.
 */
const isInsideXPathArg = state => {
  return state.pseudoStack.includes(XPATH_PSEUDO_CLASS_MARKER);
};

/**
 * Checks whether the scanner is inside a `:contains()`-like argument.
 *
 * @param state Scanner state.
 *
 * @returns True if the scanner is inside a `:contains()`-like argument.
 */
const isInsideContainsArg$1 = state => {
  return state.pseudoStack.some(name => CONTAINS_PSEUDO_NAMES.includes(name));
};

/**
 * Checks whether a quoted string can start at the current scanner position.
 *
 * A quoted string can start only where a string is allowed:
 * - at the beginning of a pseudo-class argument, e.g. `:remove-attr("title")`;
 * - after `=` or `:`, e.g. `[data-x="1"]` or `:matches-css(content: "a)b")`;
 * - after `=` or `:` (possibly followed by whitespace),
 *   e.g. `[data-x = "1"]` or `:upward(div[title = ":remove-attr(x)"])`.
 *
 * Plain text arguments of `:contains()`-like pseudo-classes
 * (e.g. `:contains(the '90s)`) cannot contain quoted strings.
 *
 * @param prevChar Character preceding a quote.
 * @param prevNonWhitespaceChar Last non-whitespace character preceding a quote.
 * @param inContainsArg True if scanning is inside a `:contains()`-like argument.
 *
 * @returns True if a quoted string can start at the current position.
 */
const canOpenQuote = function (prevChar, prevNonWhitespaceChar) {
  let inContainsArg = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  if (inContainsArg) {
    return false;
  }
  if (prevChar === BRACKET.PARENTHESES.LEFT || prevChar === EQUAL_SIGN || prevChar === COLON) {
    return true;
  }
  return isWhiteSpaceChar(prevChar) && (prevNonWhitespaceChar === EQUAL_SIGN || prevNonWhitespaceChar === COLON);
};

/**
 * Checks whether a regexp literal can start in the current scanner state.
 *
 * A regexp can start only inside an argument of a pseudo-class which accepts it:
 * at the argument beginning for `:contains()`-like pseudo-classes,
 * after certain marks for other pseudo-classes,
 * and never inside `:xpath()`.
 *
 * @param state Scanner state.
 *
 * @returns True if a regexp literal can start.
 */
const canOpenRegexp = state => {
  const pseudoName = state.pseudoStack[state.pseudoStack.length - 1];
  if (!pseudoName) {
    return false;
  }
  if (pseudoName === XPATH_PSEUDO_CLASS_MARKER) {
    return false;
  }
  if (CONTAINS_PSEUDO_NAMES.includes(pseudoName)) {
    return state.prevChar === BRACKET.PARENTHESES.LEFT;
  }
  return POSSIBLE_MARKS_BEFORE_REGEXP.COMMON.includes(state.prevChar) || isWhiteSpaceChar(state.prevChar);
};

/**
 * Reads a pseudo-class name after a colon.
 *
 * @param input Scanned string.
 * @param colonIndex Index of the colon.
 *
 * @returns Pseudo-class name or an empty string.
 */
const readPseudoClassName = (input, colonIndex) => {
  let name = '';
  for (let i = colonIndex + 1; i < input.length; i += 1) {
    const char = input[i];
    if (/[a-zA-Z0-9-]/.test(char)) {
      name += char;
    } else {
      break;
    }
  }
  return name;
};

/**
 * Processes the character at `index` and updates the scanner state.
 *
 * Escaped characters are consumed as a whole (together with the next character),
 * so the returned index can be greater than `index`.
 * Regexp literals and quoted strings are tracked character by character.
 *
 * @param input Scanned string.
 * @param index Index of the character to process.
 * @param state Scanner state.
 *
 * @returns Index of the last consumed character.
 */
const updateSelectorScannerState = (input, index, state) => {
  const char = input[index];
  if (state.inRegexp) {
    if (char === BACKSLASH) {
      setPrevChar(state, char);
      return index + 1;
    }
    if (char === BRACKET.SQUARE.LEFT) {
      state.inRegexpCharClass = true;
    } else if (char === BRACKET.SQUARE.RIGHT) {
      state.inRegexpCharClass = false;
    } else if (char === SLASH && !state.inRegexpCharClass) {
      state.inRegexp = false;
    }
    setPrevChar(state, char);
    return index;
  }
  if (state.quote) {
    if (char === BACKSLASH) {
      setPrevChar(state, char);
      return index + 1;
    }
    if (char === state.quote) {
      state.quote = undefined;
    }
    setPrevChar(state, char);
    return index;
  }
  if (char === BACKSLASH) {
    setPrevChar(state, char);
    return index + 1;
  }
  if (char === SINGLE_QUOTE || char === DOUBLE_QUOTE) {
    // quoted strings can start only where a string is allowed;
    // inside `:xpath()` arguments strings can start anywhere
    if (isInsideXPathArg(state) || canOpenQuote(state.prevChar, state.prevNonWhitespaceChar, isInsideContainsArg$1(state))) {
      state.quote = char;
    }
    setPrevChar(state, char);
    return index;
  }
  if (char === SLASH && canOpenRegexp(state)) {
    state.inRegexp = true;
    setPrevChar(state, char);
    return index;
  }
  if (char === BRACKET.PARENTHESES.LEFT) {
    state.pseudoStack.push(state.pendingPseudo ?? '');
    state.pendingPseudo = undefined;
    setPrevChar(state, char);
    return index;
  }
  if (char === BRACKET.PARENTHESES.RIGHT) {
    state.pseudoStack.pop();
    setPrevChar(state, char);
    return index;
  }
  if (char === COLON) {
    const name = readPseudoClassName(input, index);
    if (name && input[index + 1 + name.length] === BRACKET.PARENTHESES.LEFT) {
      state.pendingPseudo = name.toLowerCase();
    }
    setPrevChar(state, char);
    return index;
  }
  setPrevChar(state, char);
  return index;
};

/**
 * Scans a selector-like string and calls handlers for its structural marks.
 *
 * @param input Scanned string.
 * @param handlers Handlers for found marks.
 */
const scanSelector = (input, handlers) => {
  const state = createSelectorScannerState();
  for (let i = 0; i < input.length; i += 1) {
    i = updateSelectorScannerState(input, i, state);
    if (state.quote !== undefined || state.inRegexp) {
      // the character is a part of a quoted string or regexp literal
      continue;
    }
    if (input[i] === COLON && state.pseudoStack.length === 0 && handlers.onTopLevelColon) {
      const nextIndex = handlers.onTopLevelColon(i);
      if (typeof nextIndex === 'number') {
        // the handler skipped a part of the input, e.g. an action argument
        i = nextIndex;
        state.pendingPseudo = undefined;
        setPrevChar(state, input[i] ?? '');
      }
    } else if (input[i] === BRACKET.CURLY.LEFT && handlers.onStyleBlockStart) {
      handlers.onStyleBlockStart(i);
      if (handlers.stopAfterFirstStyleBlockStart) {
        break;
      }
    }
  }
};

/**
 * Finds the index of the closing parenthesis of an action argument.
 *
 * @param input Scanned string.
 * @param startIndex Index of the first argument character.
 * @param pseudoName Action pseudo-class name.
 *
 * @returns Index of the closing parenthesis or -1 if it is not found.
 */
const findClosingParenthesis = (input, startIndex, pseudoName) => {
  const state = createSelectorScannerState();
  state.pseudoStack = [pseudoName];
  state.prevChar = BRACKET.PARENTHESES.LEFT;
  for (let i = startIndex; i < input.length; i += 1) {
    i = updateSelectorScannerState(input, i, state);
    if (state.pseudoStack.length === 0) {
      return i;
    }
  }

  // the argument is not closed, e.g. an unclosed regexp literal;
  // `parseActionSelector()` rejects such arguments
  return -1;
};

/**
 * Finds the end of an action pseudo-class argument at the given colon.
 *
 * @param input Scanned string.
 * @param colonIndex Index of the action pseudo-class colon.
 *
 * @returns Index of the closing parenthesis or undefined
 * if there is no complete action pseudo-class at the colon.
 */
const findActionArgumentEnd = (input, colonIndex) => {
  for (const marker of ACTION_PSEUDO_MARKERS) {
    const markerText = `${marker}${BRACKET.PARENTHESES.LEFT}`;
    const candidate = input.substring(colonIndex + 1, colonIndex + 1 + markerText.length);
    if (candidate.toLowerCase() !== markerText) {
      continue;
    }
    const argStartIndex = colonIndex + 1 + markerText.length;
    const closingIndex = findClosingParenthesis(input, argStartIndex, marker);
    return closingIndex === -1 ? undefined : closingIndex;
  }
  return undefined;
};

/**
 * Regexp matching characters which can start a quoted string,
 * a regexp literal or an escape sequence.
 */
const REGEXP_SPECIAL_CHARS = /['"\\/]/;

/**
 * Regexp matching an action pseudo-class marker followed by an opening bracket,
 * e.g. `:remove(`, `:remove-attr(` or `:remove-class(`.
 */
const ACTION_MARKER_REGEXP = new RegExp(`:(?:${ACTION_PSEUDO_MARKERS.join('|')})\\(`, 'i');

/**
 * Checks whether a prefix cannot contain an open quoted string,
 * regexp literal or action pseudo-class argument:
 * without quotes, slashes and backslashes no string or regexp literal can start,
 * and action pseudo-classes are detected by their markers case-insensitively.
 *
 * @param input Scanned string.
 * @param endIndex Index before which the input should be checked.
 *
 * @returns True if the prefix contains no special characters.
 */
const isSimplePrefix = (input, endIndex) => {
  const prefix = input.slice(0, endIndex);
  return !REGEXP_SPECIAL_CHARS.test(prefix) && !ACTION_MARKER_REGEXP.test(prefix);
};

/**
 * Finds indexes of `{` marks which may start a style block.
 *
 * Braces inside quoted strings, regexp literals and action pseudo-class
 * arguments are skipped.
 *
 * @param input Scanned string.
 *
 * @returns Array of left curly bracket indexes.
 */
const findStyleBlockStarts = input => {
  const indexes = [];
  if (!input.includes(BRACKET.CURLY.LEFT)) {
    return indexes;
  }
  if (isSimplePrefix(input, input.length)) {
    let index = input.indexOf(BRACKET.CURLY.LEFT);
    while (index !== -1) {
      indexes.push(index);
      index = input.indexOf(BRACKET.CURLY.LEFT, index + 1);
    }
    return indexes;
  }
  scanSelector(input, {
    onTopLevelColon: index => {
      return findActionArgumentEnd(input, index);
    },
    onStyleBlockStart: index => {
      indexes.push(index);
    }
  });
  return indexes;
};

/**
 * Finds the index of the first `{` mark which may start a style block.
 *
 * Unlike `findStyleBlockStarts()`, the scan stops at the first `{` mark,
 * so the call is linear for the scanned prefix.
 *
 * @param input Scanned string.
 *
 * @returns Index of the first left curly bracket or -1 if it is not found.
 */
const findStyleBlockStart = input => {
  const braceIndex = input.indexOf(BRACKET.CURLY.LEFT);
  // a `{` is required to start a style block
  if (braceIndex === -1) {
    return -1;
  }
  // if no quoted string, regexp literal or action argument can be open
  // before the first `{`, it starts a style block;
  // the check is limited by the first `{` to keep parsing linear
  if (isSimplePrefix(input, braceIndex)) {
    return braceIndex;
  }
  let foundIndex = -1;
  scanSelector(input, {
    onTopLevelColon: index => {
      return findActionArgumentEnd(input, index);
    },
    onStyleBlockStart: index => {
      foundIndex = index;
    },
    stopAfterFirstStyleBlockStart: true
  });
  return foundIndex;
};

// limit applying of :xpath() pseudo-class to 'any' element
// https://github.com/AdguardTeam/ExtendedCss/issues/115
const XPATH_PSEUDO_SELECTING_ROOT = 'body';
const NO_WHITESPACE_ERROR_PREFIX = 'No white space is allowed before or after extended pseudo-class name in selector';

/**
 * Checks whether the parser is inside a `:contains()`-like argument.
 *
 * @param context Parser context.
 *
 * @returns True if the parser is inside a `:contains()`-like argument.
 */
const isInsideContainsArg = context => {
  return context.extendedPseudoNamesStack.some(name => CONTAINS_PSEUDO_NAMES.includes(name));
};

/**
 * Normalizes a token value for quote opening checks:
 * `=` is not a separate token, so it can be a part of a word
 * (e.g. `data-x=`), and such a token should be treated as `=`.
 *
 * @param value Token value.
 *
 * @returns Normalized character or the token value as is.
 */
const normalizeQuoteChar = value => {
  if (value !== null && value !== void 0 && value.endsWith(EQUAL_SIGN)) {
    return EQUAL_SIGN;
  }
  return value;
};

/**
 * Checks whether the token is escaped by an odd number of backslashes.
 *
 * @param tokens Selector tokens.
 * @param index Index of the token.
 *
 * @returns True if the token is escaped.
 */
const isEscapedToken = (tokens, index) => {
  let backslashCount = 0;
  for (let i = index - 1; i >= 0 && ((_tokens$i = tokens[i]) === null || _tokens$i === void 0 ? void 0 : _tokens$i.value) === BACKSLASH; i -= 1) {
    var _tokens$i;
    backslashCount += 1;
  }
  return backslashCount % 2 === 1;
};

/**
 * Parses selector into ast for following element selection.
 *
 * @param selector Selector to parse.
 *
 * @returns Parsed ast.
 * @throws An error on invalid selector.
 */
const parse = selector => {
  const tokens = tokenizeSelector(selector);
  const context = {
    ast: null,
    pathToBufferNode: [],
    extendedPseudoNamesStack: [],
    extendedPseudoBracketsStack: [],
    standardPseudoNamesStack: [],
    standardPseudoBracketsStack: [],
    isAttributeBracketsOpen: false,
    attributeBuffer: '',
    isRegexpOpen: false,
    quoteCharacter: undefined,
    shouldOptimize: false
  };

  // the last non-whitespace token value, needed for quote opening checks
  // e.g. '[data-x = ":remove-attr(title)"]'
  let prevNonWhitespaceTokenValue;
  let i = 0;
  while (i < tokens.length) {
    const token = tokens[i];
    if (!token) {
      break;
    }
    // Token to process
    const tokenType = token.type,
      tokenValue = token.value;

    // needed for SPACE and COLON tokens checking
    const nextToken = tokens[i + 1];
    const nextTokenType = nextToken === null || nextToken === void 0 ? void 0 : nextToken.type;
    const nextTokenValue = nextToken === null || nextToken === void 0 ? void 0 : nextToken.value;

    // needed for limitations
    // - :not() and :is() root element
    // - :has() usage
    // - white space before and after pseudo-class name
    const nextToNextToken = tokens[i + 2];
    const nextToNextTokenValue = nextToNextToken === null || nextToNextToken === void 0 ? void 0 : nextToNextToken.value;

    // needed for COLON token checking for none-specified regular selector before extended one
    // e.g. 'p, :hover'
    // or   '.banner, :contains(ads)'
    const previousToken = tokens[i - 1];
    const prevTokenType = previousToken === null || previousToken === void 0 ? void 0 : previousToken.type;
    const prevTokenValue = previousToken === null || previousToken === void 0 ? void 0 : previousToken.value;

    // needed for proper parsing of regexp pattern arg
    // e.g. ':matches-css(background-image: /^url\(https:\/\/example\.org\//)'
    const previousToPreviousToken = tokens[i - 2];
    const prevToPrevTokenValue = previousToPreviousToken === null || previousToPreviousToken === void 0 ? void 0 : previousToPreviousToken.value;

    // track quoted strings to not treat their contents as selector syntax,
    // e.g. ':upward([data-x=":remove-attr(title)"])';
    // quotes in plain text, e.g. ':contains(Don't)', should not open a string
    if ((tokenValue === SINGLE_QUOTE || tokenValue === DOUBLE_QUOTE) && !isEscapedToken(tokens, i) && !context.isRegexpOpen) {
      if (context.quoteCharacter === tokenValue) {
        context.quoteCharacter = undefined;
      } else if (context.quoteCharacter === undefined && canOpenQuote(normalizeQuoteChar(prevTokenValue), normalizeQuoteChar(prevNonWhitespaceTokenValue), isInsideContainsArg(context))) {
        context.quoteCharacter = tokenValue;
      }
    }
    let bufferNode = getBufferNode(context);
    switch (tokenType) {
      case TOKEN_TYPE.WORD:
        if (bufferNode === null) {
          // there is no buffer node only in one case — no ast collecting has been started
          initAst(context, tokenValue);
        } else if (isSelectorListNode(bufferNode)) {
          // add new selector to selector list
          addAstNodeByType(context, NODE.SELECTOR);
          addAstNodeByType(context, NODE.REGULAR_SELECTOR, tokenValue);
        } else if (isRegularSelectorNode(bufferNode)) {
          updateBufferNode(context, tokenValue);
        } else if (isExtendedSelectorNode(bufferNode)) {
          // No white space is allowed between the name of extended pseudo-class
          // and its opening parenthesis
          // https://www.w3.org/TR/selectors-4/#pseudo-classes
          // e.g. 'span:contains (text)'
          if (isWhiteSpaceChar(nextTokenValue) && nextToNextTokenValue === BRACKET.PARENTHESES.LEFT) {
            throw new Error(`${NO_WHITESPACE_ERROR_PREFIX}: '${selector}'`);
          }
          const lowerCaseTokenValue = tokenValue.toLowerCase();
          const isStandalonePseudo = isStandalonePseudoClass(lowerCaseTokenValue);
          // save pseudo-class name for brackets balance checking only for functional pseudo-classes.
          if (!isStandalonePseudo) {
            context.extendedPseudoNamesStack.push(lowerCaseTokenValue);
          }
          // extended pseudo-class name are parsed in lower case
          // as they should be case-insensitive
          // https://www.w3.org/TR/selectors-4/#pseudo-classes
          if (isAbsolutePseudoClass(lowerCaseTokenValue)) {
            addAstNodeByType(context, NODE.ABSOLUTE_PSEUDO_CLASS, lowerCaseTokenValue);
          } else {
            // if it is not absolute pseudo-class, it must be relative one
            // add RelativePseudoClass with tokenValue as pseudo-class name to ExtendedSelector children
            addAstNodeByType(context, NODE.RELATIVE_PSEUDO_CLASS, lowerCaseTokenValue);
            // for :not() and :is() pseudo-classes parsed ast should be optimized later
            if (isOptimizationPseudoClass(lowerCaseTokenValue)) {
              context.shouldOptimize = true;
            }
            // standalone pseudo-class is complete right after its name.
            if (isStandalonePseudo) {
              // standalone pseudo-classes must not have arguments
              // check if next token is opening parenthesis
              if (nextTokenValue === BRACKET.PARENTHESES.LEFT) {
                // eslint-disable-next-line max-len
                throw new Error(`${STANDALONE_ERROR_PREFIX.NO_ARGUMENTS}: ':${lowerCaseTokenValue}'`);
              }
              upToClosest(context, NODE.SELECTOR);
            }
          }
        } else if (isAbsolutePseudoClassNode(bufferNode)) {
          // collect absolute pseudo-class arg
          updateBufferNode(context, tokenValue);
        } else if (isRelativePseudoClassNode(bufferNode)) {
          initRelativeSubtree(context, tokenValue);
        }
        break;
      case TOKEN_TYPE.MARK:
        switch (tokenValue) {
          case COMMA:
            if (!bufferNode || typeof bufferNode !== 'undefined' && !nextTokenValue) {
              // consider the selector is invalid if there is no bufferNode yet (e.g. ', a')
              // or there is nothing after the comma while bufferNode is defined (e.g. 'div, ')
              throw new Error(`'${selector}' is not a valid selector`);
            } else if (isRegularSelectorNode(bufferNode)) {
              if (context.isAttributeBracketsOpen) {
                // the comma might be inside element attribute value
                // e.g. 'div[data-comma="0,1"]'
                updateBufferNode(context, tokenValue);
              } else {
                // new Selector should be collected to upper SelectorList
                upToClosest(context, NODE.SELECTOR_LIST);
              }
            } else if (isAbsolutePseudoClassNode(bufferNode)) {
              // the comma inside arg of absolute extended pseudo
              // e.g. 'div:xpath(//h3[contains(text(),"Share it!")]/..)'
              updateBufferNode(context, tokenValue);
            } else if (isSelectorNode(bufferNode)) {
              // new Selector should be collected to upper SelectorList
              // if parser position is on Selector node
              upToClosest(context, NODE.SELECTOR_LIST);
            }
            break;
          case SPACE:
            // it might be complex selector with extended pseudo-class inside it
            // and the space is between that complex selector and following regular selector
            // parser position is on ` ` before `span` now:
            // e.g. 'div:has(img).banner span'
            // so we need to check whether the new ast node should be added (example above)
            // or previous regular selector node should be updated
            if (isRegularSelectorNode(bufferNode)
            // no need to update the buffer node if attribute value is being parsed
            // e.g. 'div:not([id])[style="position: absolute; z-index: 10000;"]'
            // parser position inside attribute    ↑
            && !context.isAttributeBracketsOpen) {
              bufferNode = getUpdatedBufferNode(context);
            }
            if (isRegularSelectorNode(bufferNode)) {
              // standard selectors with white space between colon and name of pseudo
              // are invalid for native document.querySelectorAll() anyway,
              // so throwing the error here is better
              // than proper parsing of invalid selector and passing it further.
              // first of all do not check attributes
              // e.g. div[style="text-align: center"]
              if (!context.isAttributeBracketsOpen
              // check the space after the colon and before the pseudo
              // e.g. '.block: nth-child(2)
              && (prevTokenValue === COLON && nextTokenType === TOKEN_TYPE.WORD
              // or after the pseudo and before the opening parenthesis
              // e.g. '.block:nth-child (2)
              || prevTokenType === TOKEN_TYPE.WORD && nextTokenValue === BRACKET.PARENTHESES.LEFT)) {
                throw new Error(`'${selector}' is not a valid selector`);
              }
              // collect current tokenValue to value of RegularSelector
              // if it is the last token or standard selector continues after the space.
              // otherwise it will be skipped
              if (!nextTokenValue || doesRegularContinueAfterSpace(nextTokenType, nextTokenValue)
              // we also should collect space inside attribute value
              // e.g. `[onclick^="window.open ('https://example.com/share?url="]`
              // parser position             ↑
              || context.isAttributeBracketsOpen) {
                updateBufferNode(context, tokenValue);
              }
            }
            if (isAbsolutePseudoClassNode(bufferNode)) {
              // space inside extended pseudo-class arg
              // e.g. 'span:contains(some text)'
              updateBufferNode(context, tokenValue);
            }
            if (isRelativePseudoClassNode(bufferNode)) {
              // init with empty value RegularSelector
              // as the space is not needed for selector value
              // e.g. 'p:not( .content )'
              initRelativeSubtree(context);
            }
            if (isSelectorNode(bufferNode)) {
              // do NOT add RegularSelector if parser position on space BEFORE the comma in selector list
              // e.g. '.block:has(> img) , .banner)'
              if (doesRegularContinueAfterSpace(nextTokenType, nextTokenValue)) {
                // regular selector might be after the extended one.
                // extra space before combinator or selector should not be collected
                // e.g. '.banner:upward(2) .block'
                //      '.banner:upward(2) > .block'
                // so no tokenValue passed to addAnySelectorNode()
                addAstNodeByType(context, NODE.REGULAR_SELECTOR);
              }
            }
            break;
          case DESCENDANT_COMBINATOR:
          case CHILD_COMBINATOR:
          case NEXT_SIBLING_COMBINATOR:
          case SUBSEQUENT_SIBLING_COMBINATOR:
          case SEMICOLON:
          case SLASH:
          case BACKSLASH:
          case SINGLE_QUOTE:
          case DOUBLE_QUOTE:
          case CARET:
          case DOLLAR_SIGN:
          case BRACKET.CURLY.LEFT:
          case BRACKET.CURLY.RIGHT:
          case ASTERISK:
          case ID_MARKER:
          case CLASS_MARKER:
          case BRACKET.SQUARE.LEFT:
            // it might be complex selector with extended pseudo-class inside it
            // and the space is between that complex selector and following regular selector
            // e.g. 'div:has(img).banner'   // parser position is on `.` before `banner` now
            //      'div:has(img)[attr]'    // parser position is on `[` before `attr` now
            // so we need to check whether the new ast node should be added (example above)
            // or previous regular selector node should be updated
            if (COMBINATORS.includes(tokenValue)) {
              if (bufferNode === null) {
                // cases where combinator at very beginning of a selector
                // e.g. '> div'
                // or   '~ .banner'
                // or even '+js(overlay-buster)' which not a selector at all
                // but may be validated by FilterCompiler so error message should be appropriate
                throw new Error(`'${selector}' is not a valid selector`);
              }
              bufferNode = getUpdatedBufferNode(context);
            }
            if (bufferNode === null) {
              // no ast collecting has been started
              // e.g. '.banner > p'
              // or   '#top > div.ad'
              // or   '[class][style][attr]'
              // or   '*:not(span)'
              initAst(context, tokenValue);
              if (isAttributeOpening(tokenValue, prevTokenValue)) {
                // e.g. '[class^="banner-"]'
                context.isAttributeBracketsOpen = true;
              }
            } else if (isRegularSelectorNode(bufferNode)) {
              if (tokenValue === BRACKET.CURLY.LEFT && !(context.isAttributeBracketsOpen || context.isRegexpOpen)) {
                // e.g. 'div { content: "'
                throw new Error(`'${selector}' is not a valid selector`);
              }
              // collect the mark to the value of RegularSelector node
              updateBufferNode(context, tokenValue);
              if (isAttributeOpening(tokenValue, prevTokenValue)) {
                // needed for proper handling element attribute value with comma
                // e.g. 'div[data-comma="0,1"]'
                context.isAttributeBracketsOpen = true;
              }
            } else if (isAbsolutePseudoClassNode(bufferNode)) {
              // collect the mark to the arg of AbsolutePseudoClass node
              updateBufferNode(context, tokenValue);
              // 'isRegexpOpen' flag is needed for brackets balancing inside extended pseudo-class arg
              if (tokenValue === SLASH && context.extendedPseudoNamesStack.length > 0) {
                if (prevTokenValue === SLASH && prevToPrevTokenValue === BACKSLASH) {
                  // it may be specific url regexp pattern in arg of pseudo-class
                  // e.g. ':matches-css(background-image: /^url\(https:\/\/example\.org\//)'
                  // parser position is on final slash before `)`                        ↑
                  context.isRegexpOpen = false;
                } else if (prevTokenValue && prevTokenValue !== BACKSLASH) {
                  if (isRegexpOpening(context, prevTokenValue, getNodeValue(bufferNode))) {
                    context.isRegexpOpen = !context.isRegexpOpen;
                  } else {
                    // otherwise force `isRegexpOpen` flag to `false`
                    context.isRegexpOpen = false;
                  }
                }
              }
            } else if (isRelativePseudoClassNode(bufferNode)) {
              // add SelectorList to children of RelativePseudoClass node
              initRelativeSubtree(context, tokenValue);
              if (isAttributeOpening(tokenValue, prevTokenValue)) {
                // besides of creating the relative subtree
                // opening square bracket means start of attribute
                // e.g. 'div:not([class="content"])'
                //      'div:not([href*="window.print()"])'
                context.isAttributeBracketsOpen = true;
              }
            } else if (isSelectorNode(bufferNode)) {
              // after the extended pseudo closing parentheses
              // parser position is on Selector node
              // and regular selector can be after the extended one
              // e.g. '.banner:upward(2)> .block'
              // or   '.inner:nth-ancestor(1)~ .banner'
              if (COMBINATORS.includes(tokenValue)) {
                addAstNodeByType(context, NODE.REGULAR_SELECTOR, tokenValue);
              } else if (!context.isRegexpOpen) {
                // it might be complex selector with extended pseudo-class inside it.
                // parser position is on `.` now:
                // e.g. 'div:has(img).banner'
                // so we need to get last regular selector node and update its value
                bufferNode = getContextLastRegularSelectorNode(context);
                updateBufferNode(context, tokenValue);
                if (isAttributeOpening(tokenValue, prevTokenValue)) {
                  // handle attribute in compound selector after extended pseudo-class
                  // e.g. 'div:not(.top)[style="z-index: 10000;"]'
                  // parser position    ↑
                  context.isAttributeBracketsOpen = true;
                }
              }
            } else if (isSelectorListNode(bufferNode)) {
              // add Selector to SelectorList
              addAstNodeByType(context, NODE.SELECTOR);
              // and RegularSelector as it is always the first child of Selector
              addAstNodeByType(context, NODE.REGULAR_SELECTOR, tokenValue);
              if (isAttributeOpening(tokenValue, prevTokenValue)) {
                // handle simple attribute selector in selector list
                // e.g. '.banner, [class^="ad-"]'
                context.isAttributeBracketsOpen = true;
              }
            }
            break;
          case BRACKET.SQUARE.RIGHT:
            if (isRegularSelectorNode(bufferNode)) {
              // unescaped `]` in regular selector allowed only inside attribute value
              if (!context.isAttributeBracketsOpen && prevTokenValue !== BACKSLASH) {
                // e.g. 'div]'
                // eslint-disable-next-line max-len
                throw new Error(`'${selector}' is not a valid selector due to '${tokenValue}' after '${getNodeValue(bufferNode)}'`);
              }
              // needed for proper parsing regular selectors after the attributes with comma
              // e.g. 'div[data-comma="0,1"] > img'
              if (isAttributeClosing(context)) {
                context.isAttributeBracketsOpen = false;
                // reset attribute buffer on closing `]`
                context.attributeBuffer = '';
              }
              // collect the bracket to the value of RegularSelector node
              updateBufferNode(context, tokenValue);
            }
            if (isAbsolutePseudoClassNode(bufferNode)) {
              // :xpath() expended pseudo-class arg might contain square bracket
              // so it should be collected
              // e.g. 'div:xpath(//h3[contains(text(),"Share it!")]/..)'
              updateBufferNode(context, tokenValue);
            }
            break;
          case COLON:
            // No white space is allowed between the colon and the following name of the pseudo-class
            // https://www.w3.org/TR/selectors-4/#pseudo-classes
            // e.g. 'span: contains(text)'
            if (isWhiteSpaceChar(nextTokenValue) && nextToNextTokenValue && SUPPORTED_PSEUDO_CLASSES.includes(nextToNextTokenValue)) {
              throw new Error(`${NO_WHITESPACE_ERROR_PREFIX}: '${selector}'`);
            }
            if (bufferNode === null) {
              // no ast collecting has been started
              if (nextTokenValue === XPATH_PSEUDO_CLASS_MARKER) {
                // limit applying of "naked" :xpath pseudo-class
                // https://github.com/AdguardTeam/ExtendedCss/issues/115
                initAst(context, XPATH_PSEUDO_SELECTING_ROOT);
              } else if (nextTokenValue === UPWARD_PSEUDO_CLASS_MARKER || nextTokenValue === NTH_ANCESTOR_PSEUDO_CLASS_MARKER) {
                // selector should be specified before :nth-ancestor() or :upward()
                // e.g. ':nth-ancestor(3)'
                // or   ':upward(span)'
                throw new Error(`${NO_SELECTOR_ERROR_PREFIX} before :${nextTokenValue}() pseudo-class`);
              } else {
                // make it more obvious if selector starts with pseudo with no tag specified
                // e.g. ':has(a)' -> '*:has(a)'
                // or   ':empty'  -> '*:empty'
                initAst(context, ASTERISK);
              }

              // bufferNode should be updated for following checking
              bufferNode = getBufferNode(context);
            }
            if (isSelectorListNode(bufferNode)) {
              // bufferNode is SelectorList after comma has been parsed.
              // parser position is on colon now:
              // e.g. 'img,:not(.content)'
              addAstNodeByType(context, NODE.SELECTOR);
              // add empty value RegularSelector anyway as any selector should start with it
              // and check previous token on the next step
              addAstNodeByType(context, NODE.REGULAR_SELECTOR);
              // bufferNode should be updated for following checking
              bufferNode = getBufferNode(context);
            }
            if (isRegularSelectorNode(bufferNode)) {
              // it can be extended or standard pseudo
              // e.g. '#share, :contains(share it)'
              // or   'div,:hover'
              // of   'div:has(+:contains(text))'  // position is after '+'
              if (prevTokenValue && COMBINATORS.includes(prevTokenValue) || prevTokenValue === COMMA) {
                // case with colon at the start of string - e.g. ':contains(text)'
                // is covered by 'bufferNode === null' above at start of COLON checking
                updateBufferNode(context, ASTERISK);
              }
              handleNextTokenOnColon(context, selector, tokenValue, nextTokenValue, nextToNextTokenValue);
            }
            if (isSelectorNode(bufferNode)) {
              // e.g. 'div:contains(text):'
              if (!nextTokenValue) {
                throw new Error(`Invalid colon ':' at the end of selector: '${selector}'`);
              }
              // after the extended pseudo closing parentheses
              // parser position is on Selector node
              // and there is might be another extended selector.
              // parser position is on colon before 'upward':
              // e.g. 'p:contains(PR):upward(2)'
              if (isSupportedPseudoClass(nextTokenValue.toLowerCase())) {
                // if supported extended pseudo-class is next to colon
                // add ExtendedSelector to Selector children
                addAstNodeByType(context, NODE.EXTENDED_SELECTOR);
              } else {
                const actionMarker = nextTokenValue.toLowerCase();
                if (!context.quoteCharacter && isActionPseudoMarker(actionMarker)) {
                  // Action pseudo-classes should be handled before
                  // as they are not about element selecting but actions with elements
                  // e.g. '#banner:upward(2):remove()'
                  throwActionError(actionMarker, 'INVALID_ACTION', selector);
                }
                // otherwise it is standard pseudo after extended pseudo-class in complex selector
                // and colon should be collected to value of previous RegularSelector
                // e.g. 'body *:not(input)::selection'
                //      'input:matches-css(padding: 10):checked'
                bufferNode = getContextLastRegularSelectorNode(context);
                handleNextTokenOnColon(context, selector, tokenValue, nextTokenType, nextToNextTokenValue);
              }
            }
            if (isAbsolutePseudoClassNode(bufferNode)) {
              // :xpath() pseudo-class should be the last of extended pseudo-classes
              if (getNodeName(bufferNode) === XPATH_PSEUDO_CLASS_MARKER && nextTokenValue && SUPPORTED_PSEUDO_CLASSES.includes(nextTokenValue) && nextToNextTokenValue === BRACKET.PARENTHESES.LEFT) {
                throw new Error(`:xpath() pseudo-class should be the last in selector: '${selector}'`);
              }
              // Action pseudo-classes are not allowed inside :upward() arg
              // as it accepts only standard selectors
              // e.g. 'div:upward(:remove-attr(href))'
              const actionMarker = nextTokenValue === null || nextTokenValue === void 0 ? void 0 : nextTokenValue.toLowerCase();
              if (!context.quoteCharacter && getNodeName(bufferNode) === UPWARD_PSEUDO_CLASS_MARKER && actionMarker && isActionPseudoMarker(actionMarker)) {
                throwActionError(actionMarker, 'INVALID_ACTION', selector);
              }
              // collecting arg for absolute pseudo-class
              // e.g. 'div:matches-css(width:400px)'
              updateBufferNode(context, tokenValue);
            }
            if (isRelativePseudoClassNode(bufferNode)) {
              if (!nextTokenValue) {
                // e.g. 'div:has(:'
                throw new Error(`Invalid pseudo-class arg at the end of selector: '${selector}'`);
              }
              // make it more obvious if selector starts with pseudo with no tag specified
              // parser position is on colon inside :has() arg
              // e.g. 'div:has(:contains(text))'
              // or   'div:not(:empty)'
              initRelativeSubtree(context, ASTERISK);
              if (!isSupportedPseudoClass(nextTokenValue.toLowerCase())) {
                const actionMarker = nextTokenValue.toLowerCase();
                if (!context.quoteCharacter && isActionPseudoMarker(actionMarker)) {
                  // Action pseudo-classes are not allowed inside relative pseudo-classes
                  // as they are not about element selecting but actions with elements
                  // e.g. 'div:has(:remove-attr(href))'
                  throwActionError(actionMarker, 'INVALID_ACTION', selector);
                }
                // collect the colon to value of RegularSelector
                // e.g. 'div:not(:empty)'
                updateBufferNode(context, tokenValue);
                // parentheses should be balanced only for functional pseudo-classes
                // e.g. '.yellow:not(:nth-child(3))'
                if (nextToNextTokenValue === BRACKET.PARENTHESES.LEFT) {
                  context.standardPseudoNamesStack.push(nextTokenValue);
                }
              } else {
                // add ExtendedSelector to Selector children
                // e.g. 'div:has(:contains(text))'
                upToClosest(context, NODE.SELECTOR);
                addAstNodeByType(context, NODE.EXTENDED_SELECTOR);
              }
            }
            break;
          case BRACKET.PARENTHESES.LEFT:
            // start of pseudo-class arg
            if (isAbsolutePseudoClassNode(bufferNode)) {
              // no brackets balancing needed inside
              // 1. :xpath() extended pseudo-class arg
              // 2. regexp arg for other extended pseudo-classes
              if (getNodeName(bufferNode) !== XPATH_PSEUDO_CLASS_MARKER && context.isRegexpOpen) {
                // if the parentheses is escaped it should be part of regexp
                // collect it to arg of AbsolutePseudoClass
                // e.g. 'div:matches-css(background-image: /^url\\("data:image\\/gif;base64.+/)'
                updateBufferNode(context, tokenValue);
              } else {
                // otherwise brackets should be balanced
                // e.g. 'div:xpath(//h3[contains(text(),"Share it!")]/..)'
                context.extendedPseudoBracketsStack.push(tokenValue);
                // eslint-disable-next-line max-len
                if (context.extendedPseudoBracketsStack.length > context.extendedPseudoNamesStack.length) {
                  updateBufferNode(context, tokenValue);
                }
              }
            }
            if (isRegularSelectorNode(bufferNode)) {
              // continue RegularSelector value collecting for standard pseudo-classes
              // e.g. '.banner:where(div)'
              if (context.standardPseudoNamesStack.length > 0) {
                updateBufferNode(context, tokenValue);
                context.standardPseudoBracketsStack.push(tokenValue);
              }
              // parentheses inside attribute value should be part of RegularSelector value
              // e.g. 'div:not([href*="window.print()"])'   <-- parser position
              // is on the `(` after `print`       ↑
              if (context.isAttributeBracketsOpen) {
                updateBufferNode(context, tokenValue);
              }
            }
            if (isRelativePseudoClassNode(bufferNode)) {
              // save opening bracket for balancing
              // e.g. 'div:not()'  // position is on `(`
              context.extendedPseudoBracketsStack.push(tokenValue);
            }
            break;
          case BRACKET.PARENTHESES.RIGHT:
            if (isAbsolutePseudoClassNode(bufferNode)) {
              // no brackets balancing needed inside
              // 1. :xpath() extended pseudo-class arg
              // 2. regexp arg for other extended pseudo-classes
              if (getNodeName(bufferNode) !== XPATH_PSEUDO_CLASS_MARKER && context.isRegexpOpen) {
                // if closing bracket is part of regexp
                // simply save it to pseudo-class arg
                updateBufferNode(context, tokenValue);
              } else {
                // remove stacked open parentheses for brackets balance
                // e.g. 'h3:contains((Ads))'
                // or   'div:xpath(//h3[contains(text(),"Share it!")]/..)'
                context.extendedPseudoBracketsStack.pop();
                if (getNodeName(bufferNode) !== XPATH_PSEUDO_CLASS_MARKER) {
                  // for all other absolute pseudo-classes except :xpath()
                  // remove stacked name of extended pseudo-class
                  context.extendedPseudoNamesStack.pop();
                  // eslint-disable-next-line max-len
                  if (context.extendedPseudoBracketsStack.length > context.extendedPseudoNamesStack.length) {
                    // if brackets stack is not empty yet,
                    // save tokenValue to arg of AbsolutePseudoClass
                    // parser position on first closing bracket after 'Ads':
                    // e.g. 'h3:contains((Ads))'
                    updateBufferNode(context, tokenValue);
                  } else if (context.extendedPseudoBracketsStack.length >= 0 && context.extendedPseudoNamesStack.length >= 0) {
                    // assume it is combined extended pseudo-classes
                    // parser position on first closing bracket after 'advert':
                    // e.g. 'div:has(.banner, :contains(advert))'
                    upToClosest(context, NODE.SELECTOR);
                  }
                } else {
                  // for :xpath()
                  // eslint-disable-next-line max-len
                  if (context.extendedPseudoBracketsStack.length < context.extendedPseudoNamesStack.length) {
                    // remove stacked name of extended pseudo-class
                    // if there are less brackets than pseudo-class names
                    // with means last removes bracket was closing for pseudo-class
                    context.extendedPseudoNamesStack.pop();
                  } else {
                    // otherwise the bracket is part of arg
                    updateBufferNode(context, tokenValue);
                  }
                }
              }
            }
            if (isRegularSelectorNode(bufferNode)) {
              if (context.isAttributeBracketsOpen) {
                // parentheses inside attribute value should be part of RegularSelector value
                // e.g. 'div:not([href*="window.print()"])'   <-- parser position
                // is on the `)` after `print(`       ↑
                updateBufferNode(context, tokenValue);
              } else if (context.standardPseudoNamesStack.length > 0 && context.standardPseudoBracketsStack.length > 0) {
                // standard pseudo-class was processing.
                // collect the closing bracket to value of RegularSelector
                // parser position is on bracket after 'class' now:
                // e.g. 'div:where(.class)'
                updateBufferNode(context, tokenValue);
                // remove bracket and pseudo name from stacks
                context.standardPseudoBracketsStack.pop();
                const lastStandardPseudo = context.standardPseudoNamesStack.pop();
                if (!lastStandardPseudo) {
                  // standard pseudo should be in standardPseudoNamesStack
                  // as related to standardPseudoBracketsStack
                  throw new Error(`Parsing error. Invalid selector: ${selector}`);
                }
                // Disallow :has() after regular pseudo-elements
                // https://bugs.chromium.org/p/chromium/issues/detail?id=669058#c54 [3]
                if (Object.values(REGULAR_PSEUDO_ELEMENTS).includes(lastStandardPseudo)
                // check token which is next to closing parentheses and token after it
                // parser position is on bracket after 'foo' now:
                // e.g. '::part(foo):has(.a)'
                && nextTokenValue === COLON && nextToNextTokenValue && HAS_PSEUDO_CLASS_MARKERS.includes(nextToNextTokenValue)) {
                  // eslint-disable-next-line max-len
                  throw new Error(`Usage of :${nextToNextTokenValue}() pseudo-class is not allowed after any regular pseudo-element: '${lastStandardPseudo}'`);
                }
              } else {
                // extended pseudo-class was processing.
                // e.g. 'div:has(h3)'
                // remove bracket and pseudo name from stacks
                context.extendedPseudoBracketsStack.pop();
                context.extendedPseudoNamesStack.pop();
                upToClosest(context, NODE.EXTENDED_SELECTOR);
                // go to upper selector for possible selector continuation after extended pseudo-class
                // e.g. 'div:has(h3) > img'
                upToClosest(context, NODE.SELECTOR);
              }
            }
            if (isSelectorNode(bufferNode)) {
              // after inner extended pseudo-class bufferNode is Selector.
              // parser position is on last bracket now:
              // e.g. 'div:has(.banner, :contains(ads))'
              context.extendedPseudoBracketsStack.pop();
              context.extendedPseudoNamesStack.pop();
              upToClosest(context, NODE.EXTENDED_SELECTOR);
              upToClosest(context, NODE.SELECTOR);
            }
            if (isRelativePseudoClassNode(bufferNode)) {
              // save opening bracket for balancing
              // e.g. 'div:not()'  // position is on `)`
              // context.extendedPseudoBracketsStack.push(tokenValue);
              if (context.extendedPseudoNamesStack.length > 0 && context.extendedPseudoBracketsStack.length > 0) {
                context.extendedPseudoBracketsStack.pop();
                context.extendedPseudoNamesStack.pop();
              }
            }
            break;
          case LINE_FEED:
          case FORM_FEED:
          case CARRIAGE_RETURN:
            // such characters at start and end of selector should be trimmed
            // so is there is one them among tokens, it is not valid selector
            throw new Error(`'${selector}' is not a valid selector`);
          case TAB:
            // allow tab only inside attribute value
            // as there are such valid rules in filter lists
            // e.g. 'div[style^="margin-right: auto;	text-align: left;',
            // parser position                      ↑
            if (isRegularSelectorNode(bufferNode) && context.isAttributeBracketsOpen) {
              updateBufferNode(context, tokenValue);
            } else {
              // otherwise not valid
              throw new Error(`'${selector}' is not a valid selector`);
            }
        }
        break;
      // no default statement for Marks as they are limited to SUPPORTED_SELECTOR_MARKS
      // and all other symbol combinations are tokenized as Word
      // so error for invalid Word will be thrown later while element selecting by parsed ast
      default:
        throw new Error(`Unknown type of token: '${tokenValue}'`);
    }
    if (!isWhiteSpaceChar(tokenValue)) {
      prevNonWhitespaceTokenValue = tokenValue;
    }
    i += 1;
  }
  if (context.ast === null) {
    throw new Error(`'${selector}' is not a valid selector`);
  }
  if (context.extendedPseudoNamesStack.length > 0 || context.extendedPseudoBracketsStack.length > 0) {
    // eslint-disable-next-line max-len
    throw new Error(`Unbalanced brackets for extended pseudo-class: '${getLast(context.extendedPseudoNamesStack)}'`);
  }
  if (context.isAttributeBracketsOpen) {
    throw new Error(`Unbalanced attribute brackets in selector: '${selector}'`);
  }
  return context.shouldOptimize ? optimizeAst(context.ast) : context.ast;
};

const natives = {
  MutationObserver: window.MutationObserver || window.WebKitMutationObserver
};

/**
 * Class NativeTextContent is needed to intercept and save the native Node textContent getter
 * for proper work of :contains() pseudo-class as it may be mocked.
 *
 * @see {@link https://github.com/AdguardTeam/ExtendedCss/issues/127}
 */
class NativeTextContent {
  /**
   * Native Node.
   */

  /**
   * Native Node textContent getter.
   */

  /**
   * Stores native node.
   */
  constructor() {
    this.nativeNode = window.Node || Node;
  }

  /**
   * Sets native Node textContext getter to `getter` class field.
   */
  setGetter() {
    var _Object$getOwnPropert;
    this.getter = (_Object$getOwnPropert = Object.getOwnPropertyDescriptor(this.nativeNode.prototype, 'textContent')) === null || _Object$getOwnPropert === void 0 ? void 0 : _Object$getOwnPropert.get;
  }
}
const nativeTextContent = new NativeTextContent();

/**
 * Returns textContent of passed domElement.
 *
 * @param domElement DOM element.
 *
 * @returns DOM element textContent.
 */
const getNodeTextContent = domElement => {
  if (nativeTextContent.getter) {
    return nativeTextContent.getter.apply(domElement);
  }
  // if ExtendedCss.init() has not been executed and there is no nodeTextContentGetter,
  // use simple approach, especially when init() is not really needed, e.g. local tests
  return domElement.textContent || '';
};

/**
 * Returns element selector text based on it's tagName and attributes.
 *
 * @param element DOM element.
 *
 * @returns String representation of `element`.
 */
const getElementSelectorDesc = element => {
  let selectorText = element.tagName.toLowerCase();
  selectorText += Array.from(element.attributes).map(attr => {
    return `[${attr.name}="${element.getAttribute(attr.name)}"]`;
  }).join('');
  return selectorText;
};

/**
 * Returns path to a DOM element as a selector string.
 *
 * @param inputEl Input element.
 *
 * @returns String path to a DOM element.
 * @throws An error if `inputEl` in not instance of `Element`.
 */
const getElementSelectorPath = inputEl => {
  if (!(inputEl instanceof Element)) {
    throw new Error('Function received argument with wrong type');
  }
  let el;
  el = inputEl;
  const path = [];
  // we need to check '!!el' first because it is possible
  // that some ancestor of the inputEl was removed before it
  while (!!el && el.nodeType === Node.ELEMENT_NODE) {
    let selector = el.nodeName.toLowerCase();
    if (el.id && typeof el.id === 'string') {
      selector += `#${el.id}`;
      path.unshift(selector);
      break;
    }
    let sibling = el;
    let nth = 1;
    while (sibling.previousElementSibling) {
      sibling = sibling.previousElementSibling;
      if (sibling.nodeType === Node.ELEMENT_NODE && sibling.nodeName.toLowerCase() === selector) {
        nth += 1;
      }
    }
    if (nth !== 1) {
      selector += `:nth-of-type(${nth})`;
    }
    path.unshift(selector);
    el = el.parentElement;
  }
  return path.join(' > ');
};

/**
 * Checks whether the element is instance of HTMLElement.
 *
 * @param element Element to check.
 *
 * @returns True if `element` is HTMLElement.
 */
const isHtmlElement = element => {
  return element instanceof HTMLElement;
};

/**
 * Takes `element` and returns its parent element.
 *
 * @param element Element.
 * @param errorMessage Optional error message to throw.
 *
 * @returns Parent of `element`.
 * @throws An error if element has no parent element.
 */
const getParent = (element, errorMessage) => {
  const parentElement = element.parentElement;
  if (!parentElement) {
    throw new Error(errorMessage || 'Element does no have parent element');
  }
  return parentElement;
};

/**
 * Checks whether the `error` has `message` property which type is string.
 *
 * @param error Error object.
 *
 * @returns True if `error` has message.
 */
const extended_css_esm_isErrorWithMessage = error => {
  return typeof error === 'object' && error !== null && 'message' in error && typeof error.message === 'string';
};

/**
 * Converts `maybeError` to error object with message.
 *
 * @param maybeError Possible error.
 *
 * @returns Error object with defined `message` property.
 */
const extended_css_esm_toErrorWithMessage = maybeError => {
  if (extended_css_esm_isErrorWithMessage(maybeError)) {
    return maybeError;
  }
  try {
    return new Error(JSON.stringify(maybeError));
  } catch {
    // fallback in case if there is an error happened during the maybeError stringifying
    // like with circular references for example
    return new Error(String(maybeError));
  }
};

/**
 * Returns error message from `error`.
 * May be helpful to handle caught errors.
 *
 * @param error Error object.
 *
 * @returns Message of `error`.
 */
const extended_css_esm_getErrorMessage = error => {
  return extended_css_esm_toErrorWithMessage(error).message;
};

const extended_css_esm_logger = {
  /**
   * Safe console.error version.
   */
  error: typeof console !== 'undefined' && console.error && console.error.bind ? console.error.bind(window.console) : console.error,
  /**
   * Safe console.info version.
   */
  info: typeof console !== 'undefined' && console.info && console.info.bind ? console.info.bind(window.console) : console.info
};

const SAFARI_USER_AGENT_REGEXP = /\sVersion\/(\d{2}\.\d)(.+\s|\s)(Safari)\//;
const isSafariBrowser = SAFARI_USER_AGENT_REGEXP.test(navigator.userAgent);

/**
 * Checks whether the browser userAgent is supported.
 *
 * @param userAgent User agent of browser.
 *
 * @returns False only for Internet Explorer.
 */
const isUserAgentSupported = userAgent => {
  // do not support Internet Explorer
  if (userAgent.includes('MSIE') || userAgent.includes('Trident/')) {
    return false;
  }
  return true;
};

/**
 * Checks whether the current browser is supported.
 *
 * @returns False for Internet Explorer, otherwise true.
 */
const isBrowserSupported = () => {
  return isUserAgentSupported(navigator.userAgent);
};

/**
 * CSS_PROPERTY is needed for style values normalization.
 *
 * IMPORTANT: it is used as 'const' instead of 'enum' to avoid side effects
 * during ExtendedCss import into other libraries.
 */
const CSS_PROPERTY = {
  BACKGROUND: 'background',
  BACKGROUND_IMAGE: 'background-image',
  CONTENT: 'content',
  OPACITY: 'opacity'
};
const REGEXP_ANY_SYMBOL = '.*';
const REGEXP_WITH_FLAGS_REGEXP = /^\s*\/.*\/[gmisuy]*\s*$/;
/**
 * Removes quotes for specified content value.
 *
 * For example, content style declaration with `::before` can be set as '-' (e.g. unordered list)
 * which displayed as simple dash `-` with no quotes.
 * But CSSStyleDeclaration.getPropertyValue('content') will return value
 * wrapped into quotes, e.g. '"-"', which should be removed
 * because filters maintainers does not use any quotes in real rules.
 *
 * @param str Input string.
 *
 * @returns String with no quotes for content value.
 */
const removeContentQuotes = str => {
  return str.replace(/^(["'])([\s\S]*)\1$/, '$2');
};

/**
 * Adds quotes for specified background url value.
 *
 * If background-image is specified **without** quotes:
 * e.g. 'background: url(data:image/gif;base64,R0lGODlhAQA7)'.
 *
 * CSSStyleDeclaration.getPropertyValue('background-image') may return value **with** quotes:
 * e.g. 'background: url("data:image/gif;base64,R0lGODlhAQA7")'.
 *
 * So we add quotes for compatibility since filters maintainers might use quotes in real rules.
 *
 * @param str Input string.
 *
 * @returns String with unified quotes for background url value.
 */
const addUrlPropertyQuotes = str => {
  if (!str.includes('url("')) {
    const re = /url\((.*?)\)/g;
    return str.replace(re, 'url("$1")');
  }
  return str;
};

/**
 * Adds quotes to url arg for consistent property value matching.
 */
const addUrlQuotesTo = {
  regexpArg: str => {
    // e.g. /^url\\([a-z]{4}:[a-z]{5}/
    // or /^url\\(data\\:\\image\\/gif;base64.+/
    const re = /(\^)?url(\\)?\\\((\w|\[\w)/g;
    return str.replace(re, '$1url$2\\(\\"?$3');
  },
  noneRegexpArg: addUrlPropertyQuotes
};

/**
 * Escapes regular expression string.
 *
 * @see {@link https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/regexp}
 *
 * @param str Input string.
 *
 * @returns Escaped regular expression string.
 */
const escapeRegExp = str => {
  // should be escaped . * + ? ^ $ { } ( ) | [ ] / \
  // except of * | ^
  const specials = ['.', '+', '?', '$', '{', '}', '(', ')', '[', ']', '\\', '/'];
  const specialsRegex = new RegExp(`[${specials.join('\\')}]`, 'g');
  return str.replace(specialsRegex, '\\$&');
};

/**
 * Converts :matches-css() arg property value match to regexp.
 *
 * @param rawValue Style match value pattern.
 *
 * @returns Arg of :matches-css() converted to regular expression.
 */
const convertStyleMatchValueToRegexp = rawValue => {
  let value;
  if (rawValue.startsWith(SLASH) && rawValue.endsWith(SLASH)) {
    // For regex patterns double quotes `"` and backslashes `\` should be escaped
    value = addUrlQuotesTo.regexpArg(rawValue);
    value = value.slice(1, -1);
  } else {
    // For non-regex patterns parentheses `(` `)` and square brackets `[` `]`
    // should be unescaped, because their escaping in filter rules is required
    value = addUrlQuotesTo.noneRegexpArg(rawValue);
    value = value.replace(/\\([\\()[\]"])/g, '$1');
    value = escapeRegExp(value);
    // e.g. div:matches-css(background-image: url(data:*))
    value = replaceAll(value, ASTERISK, REGEXP_ANY_SYMBOL);
  }
  return new RegExp(value, 'i');
};

/**
 * Makes some properties values compatible.
 *
 * @param propertyName Name of style property.
 * @param propertyValue Value of style property.
 *
 * @returns Normalized values for some CSS properties.
 */
const normalizePropertyValue = (propertyName, propertyValue) => {
  let normalized = '';
  switch (propertyName) {
    case CSS_PROPERTY.BACKGROUND:
    case CSS_PROPERTY.BACKGROUND_IMAGE:
      // sometimes url property does not have quotes
      // so we add them for consistent matching
      normalized = addUrlPropertyQuotes(propertyValue);
      break;
    case CSS_PROPERTY.CONTENT:
      normalized = removeContentQuotes(propertyValue);
      break;
    case CSS_PROPERTY.OPACITY:
      // https://bugs.webkit.org/show_bug.cgi?id=93445
      normalized = isSafariBrowser ? (Math.round(parseFloat(propertyValue) * 100) / 100).toString() : propertyValue;
      break;
    default:
      normalized = propertyValue;
  }
  return normalized;
};

/**
 * Returns domElement style property value
 * by css property name and standard pseudo-element.
 *
 * @param domElement DOM element.
 * @param propertyName CSS property name.
 * @param regularPseudoElement Standard pseudo-element — '::before', '::after' etc.
 *
 * @returns String containing the value of a specified CSS property.
 */
const getComputedStylePropertyValue = (domElement, propertyName, regularPseudoElement) => {
  const style = window.getComputedStyle(domElement, regularPseudoElement);
  const propertyValue = style.getPropertyValue(propertyName);
  return normalizePropertyValue(propertyName, propertyValue);
};
/**
 * Parses arg of absolute pseudo-class into 'name' and 'value' if set.
 *
 * Used for :matches-css() - with COLON as separator,
 * for :matches-attr() and :matches-property() - with EQUAL_SIGN as separator.
 *
 * @param pseudoArg Arg of pseudo-class.
 * @param separator Divider symbol.
 *
 * @returns Parsed 'matches' pseudo-class arg data.
 */
const getPseudoArgData = (pseudoArg, separator) => {
  const index = pseudoArg.indexOf(separator);
  let name;
  let value;
  if (index > -1) {
    name = pseudoArg.substring(0, index).trim();
    value = pseudoArg.substring(index + 1).trim();
  } else {
    name = pseudoArg;
  }
  return {
    name,
    value
  };
};
/**
 * Parses :matches-css() pseudo-class arg
 * where regular pseudo-element can be a part of arg
 * e.g. 'div:matches-css(before, color: rgb(255, 255, 255))'    <-- obsolete `:matches-css-before()`.
 *
 * @param pseudoName Pseudo-class name.
 * @param rawArg Pseudo-class arg.
 *
 * @returns Parsed :matches-css() pseudo-class arg data.
 * @throws An error on invalid `rawArg`.
 */
const parseStyleMatchArg = (pseudoName, rawArg) => {
  const _getPseudoArgData = getPseudoArgData(rawArg, COMMA),
    name = _getPseudoArgData.name,
    value = _getPseudoArgData.value;
  let regularPseudoElement = name;
  let styleMatchArg = value;

  // check whether the string part before the separator is valid regular pseudo-element,
  // otherwise `regularPseudoElement` is null, and `styleMatchArg` is rawArg
  if (!Object.values(REGULAR_PSEUDO_ELEMENTS).includes(name)) {
    regularPseudoElement = null;
    styleMatchArg = rawArg;
  }
  if (!styleMatchArg) {
    throw new Error(`Required style property argument part is missing in :${pseudoName}() arg: '${rawArg}'`);
  }

  // if regularPseudoElement is not `null`
  if (regularPseudoElement) {
    // pseudo-element should have two colon marks for Window.getComputedStyle() due to the syntax:
    // https://www.w3.org/TR/selectors-4/#pseudo-element-syntax
    // ':matches-css(before, content: ads)' ->> '::before'
    regularPseudoElement = `${COLON}${COLON}${regularPseudoElement}`;
  }
  return {
    regularPseudoElement,
    styleMatchArg
  };
};

/**
 * Checks whether the domElement is matched by :matches-css() arg.
 *
 * @param argsData Pseudo-class name, arg, and dom element to check.
 *
 @returns True if DOM element is matched.
 * @throws An error on invalid pseudo-class arg.
 */
const isStyleMatched = argsData => {
  const pseudoName = argsData.pseudoName,
    pseudoArg = argsData.pseudoArg,
    domElement = argsData.domElement;
  const _parseStyleMatchArg = parseStyleMatchArg(pseudoName, pseudoArg),
    regularPseudoElement = _parseStyleMatchArg.regularPseudoElement,
    styleMatchArg = _parseStyleMatchArg.styleMatchArg;
  const _getPseudoArgData2 = getPseudoArgData(styleMatchArg, COLON),
    matchName = _getPseudoArgData2.name,
    matchValue = _getPseudoArgData2.value;
  if (!matchName || !matchValue) {
    throw new Error(`Required property name or value is missing in :${pseudoName}() arg: '${styleMatchArg}'`);
  }
  let valueRegexp;
  try {
    valueRegexp = convertStyleMatchValueToRegexp(matchValue);
  } catch (e) {
    extended_css_esm_logger.error(extended_css_esm_getErrorMessage(e));
    throw new Error(`Invalid argument of :${pseudoName}() pseudo-class: '${styleMatchArg}'`);
  }
  const value = getComputedStylePropertyValue(domElement, matchName, regularPseudoElement);
  return valueRegexp && valueRegexp.test(value);
};

/**
 * Validates string arg for :matches-attr() and :matches-property().
 *
 * @param arg Pseudo-class arg.
 *
 * @returns True if 'matches' pseudo-class string arg is valid.
 */
const validateStrMatcherArg = arg => {
  if (arg.includes(SLASH)) {
    return false;
  }
  if (!/^[\w-]+$/.test(arg)) {
    return false;
  }
  return true;
};

/**
 * Returns valid arg for :matches-attr() and :matcher-property().
 *
 * @param rawArg Arg pattern.
 * @param isWildcardAllowed Flag for wildcard (`*`) using as pseudo-class arg (defaults to false).
 *
 * @returns Valid arg for :matches-attr() and :matcher-property().
 * @throws An error on invalid `rawArg`.
 */
const getValidMatcherArg = function (rawArg) {
  let isWildcardAllowed = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  // if rawArg is missing for pseudo-class
  // e.g. :matches-attr()
  // error will be thrown before getValidMatcherArg() is called:
  // name or arg is missing in AbsolutePseudoClass

  let arg;
  if (rawArg.length > 1 && rawArg.startsWith(DOUBLE_QUOTE) && rawArg.endsWith(DOUBLE_QUOTE)) {
    rawArg = rawArg.slice(1, -1);
  }
  if (rawArg === '') {
    // e.g. :matches-property("")
    throw new Error('Argument should be specified. Empty arg is invalid.');
  }
  if (rawArg.startsWith(SLASH) && rawArg.endsWith(SLASH)) {
    // e.g. :matches-property("//")
    if (rawArg.length > 2) {
      arg = toRegExp(rawArg);
    } else {
      throw new Error(`Invalid regexp: '${rawArg}'`);
    }
  } else if (rawArg.includes(ASTERISK)) {
    if (rawArg === ASTERISK && !isWildcardAllowed) {
      // e.g. :matches-attr(*)
      throw new Error(`Argument should be more specific than ${rawArg}`);
    }
    arg = replaceAll(rawArg, ASTERISK, REGEXP_ANY_SYMBOL);
    arg = new RegExp(arg);
  } else {
    if (!validateStrMatcherArg(rawArg)) {
      throw new Error(`Invalid argument: '${rawArg}'`);
    }
    arg = rawArg;
  }
  return arg;
};
/**
 * Parses pseudo-class argument and returns parsed data.
 *
 * @param pseudoName Extended pseudo-class name.
 * @param pseudoArg Extended pseudo-class argument.
 *
 * @returns Parsed pseudo-class argument data.
 * @throws An error if attribute name is missing in pseudo-class arg.
 */
const getRawMatchingData = (pseudoName, pseudoArg) => {
  const _getPseudoArgData3 = getPseudoArgData(pseudoArg, EQUAL_SIGN),
    rawName = _getPseudoArgData3.name,
    rawValue = _getPseudoArgData3.value;
  if (!rawName) {
    throw new Error(`Required attribute name is missing in :${pseudoName} arg: ${pseudoArg}`);
  }
  return {
    rawName,
    rawValue
  };
};

/**
 * Checks whether the domElement is matched by :matches-attr() arg.
 *
 * @param argsData Pseudo-class name, arg, and dom element to check.
 *
 @returns True if DOM element is matched.
 * @throws An error on invalid arg of pseudo-class.
 */
const isAttributeMatched = argsData => {
  const pseudoName = argsData.pseudoName,
    pseudoArg = argsData.pseudoArg,
    domElement = argsData.domElement;
  const elementAttributes = domElement.attributes;
  // no match if dom element has no attributes
  if (elementAttributes.length === 0) {
    return false;
  }
  const _getRawMatchingData = getRawMatchingData(pseudoName, pseudoArg),
    rawAttrName = _getRawMatchingData.rawName,
    rawAttrValue = _getRawMatchingData.rawValue;
  let attrNameMatch;
  try {
    attrNameMatch = getValidMatcherArg(rawAttrName);
  } catch (e) {
    const errorMessage = extended_css_esm_getErrorMessage(e);
    extended_css_esm_logger.error(errorMessage);
    throw new SyntaxError(errorMessage);
  }
  let isMatched = false;
  let i = 0;
  while (i < elementAttributes.length && !isMatched) {
    const attr = elementAttributes[i];
    if (!attr) {
      break;
    }
    const isNameMatched = attrNameMatch instanceof RegExp ? attrNameMatch.test(attr.name) : attrNameMatch === attr.name;
    if (!rawAttrValue) {
      // for rules with no attribute value specified
      // e.g. :matches-attr("/regex/") or :matches-attr("attr-name")
      isMatched = isNameMatched;
    } else {
      let attrValueMatch;
      try {
        attrValueMatch = getValidMatcherArg(rawAttrValue);
      } catch (e) {
        const errorMessage = extended_css_esm_getErrorMessage(e);
        extended_css_esm_logger.error(errorMessage);
        throw new SyntaxError(errorMessage);
      }
      const isValueMatched = attrValueMatch instanceof RegExp ? attrValueMatch.test(attr.value) : attrValueMatch === attr.value;
      isMatched = isNameMatched && isValueMatched;
    }
    i += 1;
  }
  return isMatched;
};

/**
 * Parses raw :matches-property() arg which may be chain of properties.
 *
 * @param input Argument of :matches-property().
 *
 * @returns Arg of :matches-property() as array of strings or regular expressions.
 * @throws An error on invalid chain.
 */
const parseRawPropChain = input => {
  if (input.length > 1 && input.startsWith(DOUBLE_QUOTE) && input.endsWith(DOUBLE_QUOTE)) {
    input = input.slice(1, -1);
  }
  const chainChunks = input.split(DOT);
  const chainPatterns = [];
  let patternBuffer = '';
  let isRegexpPattern = false;
  let i = 0;
  while (i < chainChunks.length) {
    const chunk = getItemByIndex(chainChunks, i, `Invalid pseudo-class arg: '${input}'`);
    if (chunk.startsWith(SLASH) && chunk.endsWith(SLASH) && chunk.length > 2) {
      // regexp pattern with no dot in it, e.g. /propName/
      chainPatterns.push(chunk);
    } else if (chunk.startsWith(SLASH)) {
      // if chunk is a start of regexp pattern
      isRegexpPattern = true;
      patternBuffer += chunk;
    } else if (chunk.endsWith(SLASH)) {
      isRegexpPattern = false;
      // restore dot removed while splitting
      // e.g. testProp./.{1,5}/
      patternBuffer += `.${chunk}`;
      chainPatterns.push(patternBuffer);
      patternBuffer = '';
    } else {
      // if there are few dots in regexp pattern
      // so chunk might be in the middle of it
      if (isRegexpPattern) {
        patternBuffer += chunk;
      } else {
        // otherwise it is string pattern
        chainPatterns.push(chunk);
      }
    }
    i += 1;
  }
  if (patternBuffer.length > 0) {
    throw new Error(`Invalid regexp property pattern '${input}'`);
  }
  const chainMatchPatterns = chainPatterns.map(pattern => {
    if (pattern.length === 0) {
      // e.g. '.prop.id' or 'nested..test'
      throw new Error(`Empty pattern '${pattern}' is invalid in chain '${input}'`);
    }
    let validPattern;
    try {
      validPattern = getValidMatcherArg(pattern, true);
    } catch (e) {
      extended_css_esm_logger.error(extended_css_esm_getErrorMessage(e));
      throw new Error(`Invalid property pattern '${pattern}' in property chain '${input}'`);
    }
    return validPattern;
  });
  return chainMatchPatterns;
};
/**
 * Checks if the property exists in the base object (recursively).
 *
 * @param base Element to check.
 * @param chain Array of objects - parsed string property chain.
 * @param output Result accumulator (defaults to []).
 *
 * @returns Array of parsed data — representation of `base`-related `chain`.
 */
const filterRootsByRegexpChain = function (base, chain) {
  let output = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
  const tempProp = getFirst(chain);
  if (chain.length === 1) {
    let key;
    for (key in base) {
      if (tempProp instanceof RegExp) {
        if (tempProp.test(key)) {
          output.push({
            base,
            prop: key,
            value: base[key]
          });
        }
      } else if (tempProp === key) {
        output.push({
          base,
          prop: tempProp,
          value: base[key]
        });
      }
    }
    return output;
  }

  // if there is a regexp prop in input chain
  // e.g. 'unit./^ad.+/.src' for 'unit.ad-1gf2.src unit.ad-fgd34.src'),
  // every base keys should be tested by regexp and it can be more that one results
  if (tempProp instanceof RegExp) {
    const nextProp = chain.slice(1);
    const baseKeys = [];
    for (const key in base) {
      if (tempProp.test(key)) {
        baseKeys.push(key);
      }
    }
    baseKeys.forEach(key => {
      var _Object$getOwnPropert;
      const item = (_Object$getOwnPropert = Object.getOwnPropertyDescriptor(base, key)) === null || _Object$getOwnPropert === void 0 ? void 0 : _Object$getOwnPropert.value;
      filterRootsByRegexpChain(item, nextProp, output);
    });
  }
  if (base && typeof tempProp === 'string') {
    var _Object$getOwnPropert2;
    const nextBase = (_Object$getOwnPropert2 = Object.getOwnPropertyDescriptor(base, tempProp)) === null || _Object$getOwnPropert2 === void 0 ? void 0 : _Object$getOwnPropert2.value;
    chain = chain.slice(1);
    if (nextBase !== undefined) {
      filterRootsByRegexpChain(nextBase, chain, output);
    }
  }
  return output;
};

/**
 * Checks whether the domElement is matched by :matches-property() arg.
 *
 * @param argsData Pseudo-class name, arg, and dom element to check.
 *
 @returns True if DOM element is matched.
 * @throws An error on invalid prop in chain.
 */
const isPropertyMatched = argsData => {
  const pseudoName = argsData.pseudoName,
    pseudoArg = argsData.pseudoArg,
    domElement = argsData.domElement;
  const _getRawMatchingData2 = getRawMatchingData(pseudoName, pseudoArg),
    rawPropertyName = _getRawMatchingData2.rawName,
    rawPropertyValue = _getRawMatchingData2.rawValue;

  // chained property name cannot include '/' or '.'
  // so regex prop names with such escaped characters are invalid
  if (rawPropertyName.includes('\\/') || rawPropertyName.includes('\\.')) {
    throw new Error(`Invalid :${pseudoName} name pattern: ${rawPropertyName}`);
  }
  let propChainMatches;
  try {
    propChainMatches = parseRawPropChain(rawPropertyName);
  } catch (e) {
    const errorMessage = extended_css_esm_getErrorMessage(e);
    extended_css_esm_logger.error(errorMessage);
    throw new SyntaxError(errorMessage);
  }
  const ownerObjArr = filterRootsByRegexpChain(domElement, propChainMatches);
  if (ownerObjArr.length === 0) {
    return false;
  }
  let isMatched = true;
  if (rawPropertyValue) {
    let propValueMatch;
    try {
      propValueMatch = getValidMatcherArg(rawPropertyValue);
    } catch (e) {
      const errorMessage = extended_css_esm_getErrorMessage(e);
      extended_css_esm_logger.error(errorMessage);
      throw new SyntaxError(errorMessage);
    }
    if (propValueMatch) {
      for (let i = 0; i < ownerObjArr.length; i += 1) {
        var _ownerObjArr$i;
        const realValue = (_ownerObjArr$i = ownerObjArr[i]) === null || _ownerObjArr$i === void 0 ? void 0 : _ownerObjArr$i.value;
        if (propValueMatch instanceof RegExp) {
          isMatched = propValueMatch.test(convertTypeIntoString(realValue));
        } else {
          // handle 'null' and 'undefined' property values set as string
          if (realValue === 'null' || realValue === 'undefined') {
            isMatched = propValueMatch === realValue;
            break;
          }
          isMatched = convertTypeFromString(propValueMatch) === realValue;
        }
        if (isMatched) {
          break;
        }
      }
    }
  }
  return isMatched;
};

/**
 * Checks whether the textContent is matched by :contains arg.
 *
 * @param argsData Pseudo-class name, arg, and dom element to check.
 *
 @returns True if DOM element is matched.
 * @throws An error on invalid arg of pseudo-class.
 */
const isTextMatched = argsData => {
  const pseudoName = argsData.pseudoName,
    pseudoArg = argsData.pseudoArg,
    domElement = argsData.domElement;
  const textContent = getNodeTextContent(domElement);
  let isTextContentMatched;
  let pseudoArgToMatch = pseudoArg;
  if (pseudoArgToMatch.startsWith(SLASH) && REGEXP_WITH_FLAGS_REGEXP.test(pseudoArgToMatch)) {
    // regexp arg
    const flagsIndex = pseudoArgToMatch.lastIndexOf('/');
    const flagsStr = pseudoArgToMatch.substring(flagsIndex + 1);
    pseudoArgToMatch = pseudoArgToMatch.substring(0, flagsIndex + 1).slice(1, -1).replace(/\\([\\"])/g, '$1');
    let regex;
    try {
      regex = new RegExp(pseudoArgToMatch, flagsStr);
    } catch (e) {
      throw new Error(`Invalid argument of :${pseudoName}() pseudo-class: ${pseudoArg}`);
    }
    isTextContentMatched = regex.test(textContent);
  } else {
    // none-regexp arg
    pseudoArgToMatch = pseudoArgToMatch.replace(/\\([\\()[\]"])/g, '$1');
    isTextContentMatched = textContent.includes(pseudoArgToMatch);
  }
  return isTextContentMatched;
};

/**
 * Validates number arg for :nth-ancestor() and :upward() pseudo-classes.
 *
 * @param rawArg Raw arg of pseudo-class.
 * @param pseudoName Pseudo-class name.
 *
 * @returns Valid number arg for :nth-ancestor() and :upward().
 * @throws An error on invalid `rawArg`.
 */
const getValidNumberAncestorArg = (rawArg, pseudoName) => {
  const deep = Number(rawArg);
  if (Number.isNaN(deep) || deep < 1 || deep >= 256) {
    throw new Error(`Invalid argument of :${pseudoName} pseudo-class: '${rawArg}'`);
  }
  return deep;
};

/**
 * Returns nth ancestor by 'deep' number arg OR undefined if ancestor range limit exceeded.
 *
 * @param domElement DOM element to find ancestor for.
 * @param nth Depth up to needed ancestor.
 * @param pseudoName Pseudo-class name.
 *
 * @returns Ancestor element found in DOM, or null if not found.
 * @throws An error on invalid `nth` arg.
 */
const getNthAncestor = (domElement, nth, pseudoName) => {
  let ancestor = null;
  let i = 0;
  while (i < nth) {
    ancestor = domElement.parentElement;
    if (!ancestor) {
      throw new Error(`Out of DOM: Argument of :${pseudoName}() pseudo-class is too big — '${nth}'.`);
    }
    domElement = ancestor;
    i += 1;
  }
  return ancestor;
};

/**
 * Validates standard CSS selector.
 *
 * @param selector Standard selector.
 *
 * @returns True if standard CSS selector is valid.
 */
const validateStandardSelector = selector => {
  let isValid;
  try {
    document.querySelectorAll(selector);
    isValid = true;
  } catch (e) {
    isValid = false;
  }
  return isValid;
};

/**
 * Wrapper to run matcher `callback` with `args`
 * and throw error with `errorMessage` if `callback` run fails.
 *
 * @param callback Matcher callback.
 * @param argsData Args needed for matcher callback.
 * @param errorMessage Error message.
 *
 * @returns True if `callback` returns true.
 * @throws An error if `callback` fails.
 */
const matcherWrapper = (callback, argsData, errorMessage) => {
  let isMatched;
  try {
    isMatched = callback(argsData);
  } catch (e) {
    extended_css_esm_logger.error(extended_css_esm_getErrorMessage(e));
    throw new Error(errorMessage);
  }
  return isMatched;
};

/**
 * Generates common error message to throw while matching element `propDesc`.
 *
 * @param propDesc Text to describe what element 'prop' pseudo-class is trying to match.
 * @param pseudoName Pseudo-class name.
 * @param pseudoArg Pseudo-class arg.
 *
 * @returns Generated error message string.
 */
const getAbsolutePseudoError = (propDesc, pseudoName, pseudoArg) => {
  // eslint-disable-next-line max-len
  return `${MATCHING_ELEMENT_ERROR_PREFIX} ${propDesc}, may be invalid :${pseudoName}() pseudo-class arg: '${pseudoArg}'`;
};

/**
 * Checks whether the domElement is matched by absolute extended pseudo-class argument.
 *
 * @param domElement Page element.
 * @param pseudoName Pseudo-class name.
 * @param pseudoArg Pseudo-class arg.
 *
 * @returns True if `domElement` is matched by absolute pseudo-class.
 * @throws An error on unknown absolute pseudo-class.
 */
const isMatchedByAbsolutePseudo = (domElement, pseudoName, pseudoArg) => {
  let argsData;
  let errorMessage;
  let callback;
  switch (pseudoName) {
    case CONTAINS_PSEUDO:
    case HAS_TEXT_PSEUDO:
    case ABP_CONTAINS_PSEUDO:
      callback = isTextMatched;
      argsData = {
        pseudoName,
        pseudoArg,
        domElement
      };
      errorMessage = getAbsolutePseudoError('text content', pseudoName, pseudoArg);
      break;
    case MATCHES_CSS_PSEUDO:
    case MATCHES_CSS_AFTER_PSEUDO:
    case MATCHES_CSS_BEFORE_PSEUDO:
      callback = isStyleMatched;
      argsData = {
        pseudoName,
        pseudoArg,
        domElement
      };
      errorMessage = getAbsolutePseudoError('style', pseudoName, pseudoArg);
      break;
    case MATCHES_ATTR_PSEUDO_CLASS_MARKER:
      callback = isAttributeMatched;
      argsData = {
        domElement,
        pseudoName,
        pseudoArg
      };
      errorMessage = getAbsolutePseudoError('attributes', pseudoName, pseudoArg);
      break;
    case MATCHES_PROPERTY_PSEUDO_CLASS_MARKER:
      callback = isPropertyMatched;
      argsData = {
        domElement,
        pseudoName,
        pseudoArg
      };
      errorMessage = getAbsolutePseudoError('properties', pseudoName, pseudoArg);
      break;
    default:
      throw new Error(`Unknown absolute pseudo-class :${pseudoName}()`);
  }
  return matcherWrapper(callback, argsData, errorMessage);
};
const findByAbsolutePseudoPseudo = {
  /**
   * Returns list of nth ancestors relative to every dom node from domElements list.
   *
   * @param domElements DOM elements.
   * @param rawPseudoArg Number arg of :nth-ancestor() or :upward() pseudo-class.
   * @param pseudoName Pseudo-class name.
   *
   * @returns Array of ancestor DOM elements.
   */
  nthAncestor: (domElements, rawPseudoArg, pseudoName) => {
    const deep = getValidNumberAncestorArg(rawPseudoArg, pseudoName);
    const ancestors = domElements.map(domElement => {
      let ancestor = null;
      try {
        ancestor = getNthAncestor(domElement, deep, pseudoName);
      } catch (e) {
        extended_css_esm_logger.error(extended_css_esm_getErrorMessage(e));
      }
      return ancestor;
    }).filter(isHtmlElement);
    return ancestors;
  },
  /**
   * Returns list of elements by xpath expression, evaluated on every dom node from domElements list.
   *
   * @param domElements DOM elements.
   * @param rawPseudoArg Arg of :xpath() pseudo-class.
   *
   * @returns Array of DOM elements matched by xpath expression.
   */
  xpath: (domElements, rawPseudoArg) => {
    const foundElements = domElements.map(domElement => {
      const result = [];
      let xpathResult;
      try {
        xpathResult = document.evaluate(rawPseudoArg, domElement, null, window.XPathResult.UNORDERED_NODE_ITERATOR_TYPE, null);
      } catch (e) {
        extended_css_esm_logger.error(extended_css_esm_getErrorMessage(e));
        throw new Error(`Invalid argument of :xpath() pseudo-class: '${rawPseudoArg}'`);
      }
      let node = xpathResult.iterateNext();
      while (node) {
        if (isHtmlElement(node)) {
          result.push(node);
        }
        node = xpathResult.iterateNext();
      }
      return result;
    });
    return flatten(foundElements);
  },
  /**
   * Returns list of closest ancestors relative to every dom node from domElements list.
   *
   * @param domElements DOM elements.
   * @param rawPseudoArg Standard selector arg of :upward() pseudo-class.
   *
   * @returns Array of closest ancestor DOM elements.
   * @throws An error if `rawPseudoArg` is not a valid standard selector.
   */
  upward: (domElements, rawPseudoArg) => {
    if (!validateStandardSelector(rawPseudoArg)) {
      throw new Error(`Invalid argument of :upward pseudo-class: '${rawPseudoArg}'`);
    }
    const closestAncestors = domElements.map(domElement => {
      // closest to parent element should be found
      // otherwise `.base:upward(.base)` will return itself too, not only ancestor
      const parent = domElement.parentElement;
      if (!parent) {
        return null;
      }
      return parent.closest(rawPseudoArg);
    }).filter(isHtmlElement);
    return closestAncestors;
  }
};

/**
 * Calculated selector text which is needed to :has(), :is() and :not() pseudo-classes.
 * Contains calculated part (depends on the processed element)
 * and value of RegularSelector which is next to selector by.
 *
 * Native Document.querySelectorAll() does not select exact descendant elements
 * but match all page elements satisfying the selector,
 * so extra specification is needed for proper descendants selection
 * e.g. 'div:has(> img)'.
 *
 * Its calculation depends on extended selector.
 */

/**
 * Combined `:scope` pseudo-class and **child** combinator — `:scope>`.
 */
const scopeDirectChildren = `${SCOPE_CSS_PSEUDO_CLASS}${CHILD_COMBINATOR}`;

/**
 * Combined `:scope` pseudo-class and **descendant** combinator — `:scope `.
 */
const scopeAnyChildren = `${SCOPE_CSS_PSEUDO_CLASS}${DESCENDANT_COMBINATOR}`;

/**
 * Type for relative pseudo-class helpers args.
 */

/**
 * Returns the first of RegularSelector child node for `selectorNode`.
 *
 * @param selectorNode Ast Selector node.
 * @param pseudoName Name of relative pseudo-class.
 *
 * @returns Ast RegularSelector node.
 */
const getFirstInnerRegularChild = (selectorNode, pseudoName) => {
  return getFirstRegularChild(selectorNode.children, `RegularSelector is missing for :${pseudoName}() pseudo-class`);
};

// TODO: fix for <forgiving-relative-selector-list>
// https://github.com/AdguardTeam/ExtendedCss/issues/154
/**
 * Checks whether the element has all relative elements specified by pseudo-class arg.
 * Used for :has() pseudo-class.
 *
 * @param argsData Relative pseudo-class helpers args data.
 *
 * @returns True if **all selectors** from argsData.relativeSelectorList is **matched** for argsData.element.
 */
const hasRelativesBySelectorList = argsData => {
  const element = argsData.element,
    relativeSelectorList = argsData.relativeSelectorList,
    pseudoName = argsData.pseudoName;
  return relativeSelectorList.children
  // Array.every() is used here as each Selector node from SelectorList should exist on page
  .every(selectorNode => {
    // selectorList.children always starts with regular selector as any selector generally
    const relativeRegularSelector = getFirstInnerRegularChild(selectorNode, pseudoName);
    let specifiedSelector = '';
    let rootElement = null;
    const regularSelector = getNodeValue(relativeRegularSelector);
    if (regularSelector.startsWith(NEXT_SIBLING_COMBINATOR) || regularSelector.startsWith(SUBSEQUENT_SIBLING_COMBINATOR)) {
      /**
       * For matching the element by "element:has(+ next-sibling)" and "element:has(~ sibling)"
       * we check whether the element's parentElement has specific direct child combination,
       * e.g. 'h1:has(+ .share)' -> `h1Node.parentElement.querySelectorAll(':scope > h1 + .share')`.
       *
       * @see {@link https://www.w3.org/TR/selectors-4/#relational}
       */
      rootElement = element.parentElement;
      const elementSelectorText = getElementSelectorDesc(element);
      specifiedSelector = `${scopeDirectChildren}${elementSelectorText}${regularSelector}`;
    } else if (regularSelector === ASTERISK) {
      /**
       * :scope specification is needed for proper descendants selection
       * as native element.querySelectorAll() does not select exact element descendants
       * e.g. 'a:has(> img)' -> `aNode.querySelectorAll(':scope > img')`.
       *
       * For 'any selector' as arg of relative simplicity should be set for all inner elements
       * e.g. 'div:has(*)' -> `divNode.querySelectorAll(':scope *')`
       * which means empty div with no child element.
       */
      rootElement = element;
      specifiedSelector = `${scopeAnyChildren}${ASTERISK}`;
    } else {
      /**
       * As it described above, inner elements should be found using `:scope` pseudo-class
       * e.g. 'a:has(> img)' -> `aNode.querySelectorAll(':scope > img')`
       * OR '.block(div > span)' -> `blockClassNode.querySelectorAll(':scope div > span')`.
       */
      specifiedSelector = `${scopeAnyChildren}${regularSelector}`;
      rootElement = element;
    }
    if (!rootElement) {
      throw new Error(`Selection by :${pseudoName}() pseudo-class is not possible`);
    }
    let relativeElements;
    try {
      // eslint-disable-next-line @typescript-eslint/no-use-before-define
      relativeElements = getElementsForSelectorNode(selectorNode, rootElement, specifiedSelector);
    } catch (e) {
      extended_css_esm_logger.error(extended_css_esm_getErrorMessage(e));
      // fail for invalid selector
      throw new Error(`Invalid selector for :${pseudoName}() pseudo-class: '${regularSelector}'`);
    }
    return relativeElements.length > 0;
  });
};

/**
 * Checks whether the element is an any element specified by pseudo-class arg.
 * Used for :is() pseudo-class.
 *
 * @param argsData Relative pseudo-class helpers args data.
 *
 * @returns True if **any selector** from argsData.relativeSelectorList is **matched** for argsData.element.
 */
const isAnyElementBySelectorList = argsData => {
  const element = argsData.element,
    relativeSelectorList = argsData.relativeSelectorList,
    pseudoName = argsData.pseudoName;
  return relativeSelectorList.children
  // Array.some() is used here as any selector from selector list should exist on page
  .some(selectorNode => {
    // selectorList.children always starts with regular selector
    const relativeRegularSelector = getFirstInnerRegularChild(selectorNode, pseudoName);

    /**
     * For checking the element by 'div:is(.banner)'
     * we check whether the element's parentElement has any specific direct child.
     */
    const rootElement = getParent(element, `Selection by :${pseudoName}() pseudo-class is not possible`);

    /**
     * So we calculate the element "description" by it's tagname and attributes for targeting
     * and use it to specify the selection
     * e.g. `div:is(.banner)` --> `divNode.parentElement.querySelectorAll(':scope > .banner')`.
     */
    const specifiedSelector = `${scopeDirectChildren}${getNodeValue(relativeRegularSelector)}`;
    let anyElements;
    try {
      // eslint-disable-next-line @typescript-eslint/no-use-before-define
      anyElements = getElementsForSelectorNode(selectorNode, rootElement, specifiedSelector);
    } catch (e) {
      // do not fail on invalid selectors for :is()
      return false;
    }

    // TODO: figure out how to handle complex selectors with extended pseudo-classes
    // (check readme - extended-css-is-limitations)
    // because `element` and `anyElements` may be from different DOM levels
    return anyElements.includes(element);
  });
};

/**
 * Checks whether the element is not an element specified by pseudo-class arg.
 * Used for :not() pseudo-class.
 *
 * @param argsData Relative pseudo-class helpers args data.
 *
 * @returns True if **any selector** from argsData.relativeSelectorList is **not matched** for argsData.element.
 */
const notElementBySelectorList = argsData => {
  const element = argsData.element,
    relativeSelectorList = argsData.relativeSelectorList,
    pseudoName = argsData.pseudoName;
  return relativeSelectorList.children
  // Array.every() is used here as element should not be selected by any selector from selector list
  .every(selectorNode => {
    // selectorList.children always starts with regular selector
    const relativeRegularSelector = getFirstInnerRegularChild(selectorNode, pseudoName);

    /**
     * For checking the element by 'div:not([data="content"])
     * we check whether the element's parentElement has any specific direct child.
     */
    const rootElement = getParent(element, `Selection by :${pseudoName}() pseudo-class is not possible`);

    /**
     * So we calculate the element "description" by it's tagname and attributes for targeting
     * and use it to specify the selection
     * e.g. `div:not(.banner)` --> `divNode.parentElement.querySelectorAll(':scope > .banner')`.
     */
    const specifiedSelector = `${scopeDirectChildren}${getNodeValue(relativeRegularSelector)}`;
    let anyElements;
    try {
      // eslint-disable-next-line @typescript-eslint/no-use-before-define
      anyElements = getElementsForSelectorNode(selectorNode, rootElement, specifiedSelector);
    } catch (e) {
      // fail on invalid selectors for :not()
      extended_css_esm_logger.error(extended_css_esm_getErrorMessage(e));
      // eslint-disable-next-line max-len
      throw new Error(`Invalid selector for :${pseudoName}() pseudo-class: '${getNodeValue(relativeRegularSelector)}'`);
    }

    // TODO: figure out how to handle up-looking pseudo-classes inside :not()
    // (check readme - extended-css-not-limitations)
    // because `element` and `anyElements` may be from different DOM levels
    return !anyElements.includes(element);
  });
};

/**
 * Selects dom elements by value of RegularSelector.
 *
 * @param regularSelectorNode RegularSelector node.
 * @param root Root DOM element.
 * @param specifiedSelector {@link SpecifiedSelector}.
 *
 * @returns Array of DOM elements.
 * @throws An error if RegularSelector node value is an invalid selector.
 */
const getByRegularSelector = (regularSelectorNode, root, specifiedSelector) => {
  const selectorText = specifiedSelector ? specifiedSelector : getNodeValue(regularSelectorNode);
  let selectedElements = [];
  try {
    selectedElements = Array.from(root.querySelectorAll(selectorText));
  } catch (e) {
    throw new Error(`Error: unable to select by '${selectorText}' — ${extended_css_esm_getErrorMessage(e)}`);
  }
  return selectedElements;
};

/**
 * Returns list of dom elements filtered or selected by ExtendedSelector node.
 *
 * @param domElements Array of DOM elements.
 * @param extendedSelectorNode ExtendedSelector node.
 *
 * @returns Array of DOM elements.
 * @throws An error on unknown pseudo-class,
 * absent or invalid arg of extended pseudo-class, etc.
 */
const getByExtendedSelector = (domElements, extendedSelectorNode) => {
  let foundElements = [];
  const extendedPseudoClassNode = getPseudoClassNode(extendedSelectorNode);
  const pseudoName = getNodeName(extendedPseudoClassNode);
  if (isAbsolutePseudoClass(pseudoName)) {
    // absolute extended pseudo-classes should have an argument
    const absolutePseudoArg = getNodeValue(extendedPseudoClassNode, `Missing arg for :${pseudoName}() pseudo-class`);
    if (pseudoName === NTH_ANCESTOR_PSEUDO_CLASS_MARKER) {
      // :nth-ancestor()
      foundElements = findByAbsolutePseudoPseudo.nthAncestor(domElements, absolutePseudoArg, pseudoName);
    } else if (pseudoName === XPATH_PSEUDO_CLASS_MARKER) {
      // :xpath()
      try {
        document.createExpression(absolutePseudoArg, null);
      } catch (e) {
        throw new Error(`Invalid argument of :${pseudoName}() pseudo-class: '${absolutePseudoArg}'`);
      }
      foundElements = findByAbsolutePseudoPseudo.xpath(domElements, absolutePseudoArg);
    } else if (pseudoName === UPWARD_PSEUDO_CLASS_MARKER) {
      // :upward()
      if (Number.isNaN(Number(absolutePseudoArg))) {
        // so arg is selector, not a number
        foundElements = findByAbsolutePseudoPseudo.upward(domElements, absolutePseudoArg);
      } else {
        foundElements = findByAbsolutePseudoPseudo.nthAncestor(domElements, absolutePseudoArg, pseudoName);
      }
    } else {
      // all other absolute extended pseudo-classes
      // e.g. contains, matches-attr, etc.
      foundElements = domElements.filter(element => {
        return isMatchedByAbsolutePseudo(element, pseudoName, absolutePseudoArg);
      });
    }
  } else if (isRelativePseudoClass(pseudoName)) {
    const relativeSelectorList = getRelativeSelectorListNode(extendedPseudoClassNode);
    let relativePredicate;
    switch (pseudoName) {
      case HAS_PSEUDO_CLASS_MARKER:
      case ABP_HAS_PSEUDO_CLASS_MARKER:
        relativePredicate = element => hasRelativesBySelectorList({
          element,
          relativeSelectorList,
          pseudoName
        });
        break;
      case IS_PSEUDO_CLASS_MARKER:
        relativePredicate = element => isAnyElementBySelectorList({
          element,
          relativeSelectorList,
          pseudoName
        });
        break;
      case NOT_PSEUDO_CLASS_MARKER:
        relativePredicate = element => notElementBySelectorList({
          element,
          relativeSelectorList,
          pseudoName
        });
        break;
      default:
        throw new Error(`Unknown relative pseudo-class: '${pseudoName}'`);
    }
    foundElements = domElements.filter(relativePredicate);
  } else if (isStandalonePseudoClass(pseudoName)) {
    let standalonePredicate;
    switch (pseudoName) {
      case EMPTY_TRIMMED_PSEUDO_CLASS_MARKER:
        standalonePredicate = element => {
          const textContent = element.textContent ?? '';
          // String.prototype.trim() removes all Unicode whitespace per the ECMAScript spec,
          // including \u00A0 (non-breaking space / &nbsp;).
          // See https://tc39.es/ecma262/#sec-string.prototype.trim
          return textContent.trim().length === 0;
        };
        break;
      default:
        throw new Error(`Unknown standalone pseudo-class: '${pseudoName}'`);
    }
    foundElements = domElements.filter(standalonePredicate);
  } else {
    // extra check is parser missed something
    throw new Error(`Unknown extended pseudo-class: '${pseudoName}'`);
  }
  return foundElements;
};

/**
 * Returns list of dom elements which is selected by RegularSelector value.
 *
 * @param domElements Array of DOM elements.
 * @param regularSelectorNode RegularSelector node.
 *
 * @returns Array of DOM elements.
 * @throws An error if RegularSelector has not value.
 */
const getByFollowingRegularSelector = (domElements, regularSelectorNode) => {
  // array of arrays because of Array.map() later
  let foundElements = [];
  const value = getNodeValue(regularSelectorNode);
  if (value.startsWith(CHILD_COMBINATOR)) {
    // e.g. div:has(> img) > .banner
    foundElements = domElements.map(root => {
      const specifiedSelector = `${SCOPE_CSS_PSEUDO_CLASS}${value}`;
      return getByRegularSelector(regularSelectorNode, root, specifiedSelector);
    });
  } else if (value.startsWith(NEXT_SIBLING_COMBINATOR) || value.startsWith(SUBSEQUENT_SIBLING_COMBINATOR)) {
    // e.g. div:has(> img) + .banner
    // or   div:has(> img) ~ .banner
    foundElements = domElements.map(element => {
      const rootElement = element.parentElement;
      if (!rootElement) {
        // do not throw error if there in no parent for element
        // e.g. '*:contains(text)' selects `html` which has no parentElement
        return [];
      }
      const elementSelectorText = getElementSelectorDesc(element);
      const specifiedSelector = `${scopeDirectChildren}${elementSelectorText}${value}`;
      const selected = getByRegularSelector(regularSelectorNode, rootElement, specifiedSelector);
      return selected;
    });
  } else {
    // space-separated regular selector after extended one
    // e.g. div:has(> img) .banner
    foundElements = domElements.map(root => {
      const specifiedSelector = `${scopeAnyChildren}${getNodeValue(regularSelectorNode)}`;
      return getByRegularSelector(regularSelectorNode, root, specifiedSelector);
    });
  }
  // foundElements should be flattened
  // as getByRegularSelector() returns elements array, and Array.map() collects them to array
  return flatten(foundElements);
};

/**
 * Returns elements nodes for Selector node.
 * As far as any selector always starts with regular part,
 * it selects by RegularSelector first and checks found elements later.
 *
 * Relative pseudo-classes has it's own subtree so getElementsForSelectorNode is called recursively.
 *
 * 'specifiedSelector' is needed for :has(), :is(), and :not() pseudo-classes
 * as native querySelectorAll() does not select exact element descendants even if it is called on 'div'
 * e.g. ':scope' specification is needed for proper descendants selection for 'div:has(> img)'.
 * So we check `divNode.querySelectorAll(':scope > img').length > 0`.
 *
 * @param selectorNode Selector node.
 * @param root Root DOM element.
 * @param specifiedSelector Needed element specification.
 *
 * @returns Array of DOM elements.
 * @throws An error if there is no selectorNodeChild.
 */
const getElementsForSelectorNode = (selectorNode, root, specifiedSelector) => {
  let selectedElements = [];
  let i = 0;
  while (i < selectorNode.children.length) {
    const selectorNodeChild = getItemByIndex(selectorNode.children, i, 'selectorNodeChild should be specified');
    if (i === 0) {
      // any selector always starts with regular selector
      selectedElements = getByRegularSelector(selectorNodeChild, root, specifiedSelector);
    } else if (isExtendedSelectorNode(selectorNodeChild)) {
      // filter previously selected elements by next selector nodes
      selectedElements = getByExtendedSelector(selectedElements, selectorNodeChild);
    } else if (isRegularSelectorNode(selectorNodeChild)) {
      selectedElements = getByFollowingRegularSelector(selectedElements, selectorNodeChild);
    }
    i += 1;
  }
  return selectedElements;
};

/**
 * Selects elements by ast.
 *
 * @param ast Ast of parsed selector.
 * @param doc Document.
 *
 * @returns Array of DOM elements.
 */
const selectElementsByAst = function (ast) {
  let doc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  const selectedElements = [];
  // ast root is SelectorList node;
  // it has Selector nodes as children which should be processed separately
  ast.children.forEach(selectorNode => {
    selectedElements.push(...getElementsForSelectorNode(selectorNode, doc));
  });
  // selectedElements should be flattened as it is array of arrays with elements
  const uniqueElements = [...new Set(flatten(selectedElements))];
  return uniqueElements;
};

/**
 * Class of ExtCssDocument is needed for caching.
 * For making cache related to each new instance of class, not global.
 */
class ExtCssDocument {
  /**
   * Cache with selectors and their AST parsing results.
   */

  /**
   * Creates new ExtCssDocument and inits new `astCache`.
   */
  constructor() {
    this.astCache = new Map();
  }

  /**
   * Saves selector and it's ast to cache.
   *
   * @param selector Standard or extended selector.
   * @param ast Selector ast.
   */
  saveAstToCache(selector, ast) {
    this.astCache.set(selector, ast);
  }

  /**
   * Returns ast from cache for given selector.
   *
   * @param selector Standard or extended selector.
   *
   * @returns Previously parsed ast found in cache, or null if not found.
   */
  getAstFromCache(selector) {
    const cachedAst = this.astCache.get(selector) || null;
    return cachedAst;
  }

  /**
   * Returns selector ast:
   * - if cached ast exists — returns it;
   * - if no cached ast — saves newly parsed ast to cache and returns it.
   *
   * @param selector Standard or extended selector.
   *
   * @returns Ast for `selector`.
   */
  getSelectorAst(selector) {
    let ast = this.getAstFromCache(selector);
    if (!ast) {
      ast = parse(selector);
    }
    this.saveAstToCache(selector, ast);
    return ast;
  }

  /**
   * Selects elements by selector.
   *
   * @param selector Standard or extended selector.
   *
   * @returns Array of DOM elements.
   */
  querySelectorAll(selector) {
    const ast = this.getSelectorAst(selector);
    return selectElementsByAst(ast);
  }
}
const extCssDocument = new ExtCssDocument();

function _arrayWithHoles(r) {
  if (Array.isArray(r)) return r;
}

function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e,
      n,
      i,
      u,
      a = [],
      f = !0,
      o = !1;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = !1;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
    } catch (r) {
      o = !0, n = r;
    } finally {
      try {
        if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}

function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}

function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _slicedToArray(r, e) {
  return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}

/**
 * Converts array of `entries` to object.
 * Object.fromEntries() polyfill because it is not supported by old browsers, e.g. Chrome 55.
 * Only first two elements of `entries` array matter, other will be skipped silently.
 *
 * @see {@link https://caniuse.com/?search=Object.fromEntries}
 *
 * @param entries Array of pairs.
 *
 * @returns Object converted from `entries`.
 */
const getObjectFromEntries = entries => {
  const object = {};
  entries.forEach(el => {
    const _el = _slicedToArray(el, 2),
      key = _el[0],
      value = _el[1];
    object[key] = value;
  });
  return object;
};

const DEBUG_PSEUDO_PROPERTY_KEY = 'debug';

/**
 * Info about an action pseudo-class found in a selector.
 */

/**
 * Finds top-level action pseudo-classes in the raw selector.
 *
 * Action pseudo-classes nested in other pseudo-classes are ignored here
 * and rejected later by the selector parser.
 *
 * @param rawSelector Raw selector text.
 *
 * @returns Found action pseudo-classes in the order of appearance.
 */
const findActionSelectors = rawSelector => {
  const found = [];
  scanSelector(rawSelector, {
    onTopLevelColon: index => {
      const marker = ACTION_PSEUDO_MARKERS.find(name => {
        const markerText = `${name}${BRACKET.PARENTHESES.LEFT}`;
        const candidate = rawSelector.substring(index + 1, index + 1 + markerText.length);
        return candidate.toLowerCase() === markerText;
      });
      if (!marker) {
        return;
      }
      const argStartIndex = index + marker.length + 2;
      const closingIndex = findClosingParenthesis(rawSelector, argStartIndex, marker);
      found.push({
        marker,
        startIndex: index,
        arg: closingIndex === -1 ? rawSelector.substring(argStartIndex) : rawSelector.substring(argStartIndex, closingIndex),
        endIndex: closingIndex === -1 ? -1 : closingIndex + 1
      });
      if (closingIndex !== -1) {
        return closingIndex;
      }
    }
  });
  return found;
};

/**
 * Checks the presence of action pseudo-classes and validates them
 * while parsing the selector part of a CSS rule.
 *
 * Action pseudo-classes are not about element selecting but about actions
 * with elements, so they are stripped from the selector and returned
 * as synthetic style declarations.
 *
 * @param rawSelector Selector which may contain an action pseudo-class.
 *
 * @returns Parsed selector data with selector and styles.
 * @throws An error on invalid action pseudo-class usage.
 */
const parseActionSelector = rawSelector => {
  const actions = findActionSelectors(rawSelector);
  if (actions.length === 0) {
    return {
      selector: rawSelector,
      stylesOfSelector: []
    };
  }
  const action = actions[0];
  if (actions.length > 1) {
    throwActionError(action.marker, 'MULTIPLE_USAGE', rawSelector);
  }
  if (action.endIndex === -1) {
    // an unclosed regexp literal is an argument error,
    // while any other unclosed argument is an action error
    const messageKey = action.arg.trim().startsWith(SLASH) ? 'INVALID_ARG' : 'INVALID_ACTION';
    throwActionError(action.marker, messageKey, rawSelector);
  }
  if (action.startIndex === 0) {
    throwActionError(action.marker, 'NO_TARGET_SELECTOR', rawSelector);
  }
  if (action.endIndex < rawSelector.length) {
    throwActionError(action.marker, 'INVALID_POSITION', rawSelector);
  }
  const selector = rawSelector.substring(0, action.startIndex);
  if (action.marker === REMOVE_PSEUDO_MARKER) {
    if (action.arg !== '') {
      throwActionError(action.marker, 'INVALID_ARG', rawSelector);
    }
    return {
      selector,
      stylesOfSelector: [{
        property: REMOVE_PSEUDO_MARKER,
        value: PSEUDO_PROPERTY_POSITIVE_VALUE
      }]
    };
  }
  const arg = normalizeActionArg(action.arg);
  if (!arg) {
    throwActionError(action.marker, 'INVALID_ARG', rawSelector);
  }
  return {
    selector,
    stylesOfSelector: [{
      property: action.marker,
      value: arg
    }]
  };
};

/**
 * Parses cropped selector part found before `{`.
 *
 * @param selectorBuffer Buffered selector to parse.
 * @param extCssDoc Needed for caching of selector ast.
 *
 * @returns Parsed validation data for cropped part of stylesheet which may be a selector.
 * @throws An error on unsupported CSS features, e.g. at-rules.
 */
const parseSelectorRulePart = (selectorBuffer, extCssDoc) => {
  let selector = selectorBuffer.trim();
  if (selector.startsWith(AT_RULE_MARKER)) {
    throw new Error(`${NO_AT_RULE_ERROR_PREFIX}: '${selector}'.`);
  }
  let actionSelectorData;
  try {
    actionSelectorData = parseActionSelector(selector);
  } catch (e) {
    extended_css_esm_logger.error(extended_css_esm_getErrorMessage(e));
    throw e;
  }
  let stylesOfSelector = [];
  let success = false;
  let ast;
  try {
    selector = actionSelectorData.selector;
    stylesOfSelector = actionSelectorData.stylesOfSelector;
    // validate found selector by parsing it to ast
    // so if it is invalid error will be thrown
    ast = extCssDoc.getSelectorAst(selector);
    success = true;
  } catch (e) {
    success = false;
  }
  return {
    success,
    selector,
    ast,
    stylesOfSelector
  };
};

/**
 * Creates a map for storing raw results of css rules parsing.
 * Used for merging styles for same selector.
 *
 * @returns Map where **key** is `selector`
 * and **value** is object with `ast` and `styles`.
 */
const createRawResultsMap = () => {
  return new Map();
};

/**
 * Saves rules data for unique selectors.
 *
 * @param rawResults Previously collected results of parsing.
 * @param rawRuleData Parsed rule data.
 *
 * @throws An error if there is no rawRuleData.styles or rawRuleData.ast.
 */
const saveToRawResults = (rawResults, rawRuleData) => {
  const selector = rawRuleData.selector,
    ast = rawRuleData.ast,
    rawStyles = rawRuleData.rawStyles,
    hasActionPseudoClass = rawRuleData.hasActionPseudoClass;
  if (!rawStyles) {
    throw new Error(`No style declaration for selector: '${selector}'`);
  }
  if (!ast) {
    throw new Error(`No ast parsed for selector: '${selector}'`);
  }
  const styleGroup = {
    styles: rawStyles,
    hasActionPseudoClass: !!hasActionPseudoClass
  };
  const storedRuleData = rawResults.get(selector);
  if (!storedRuleData) {
    rawResults.set(selector, {
      ast,
      styleGroups: [styleGroup]
    });
  } else {
    storedRuleData.styleGroups.push(styleGroup);
  }
};

/**
 * Checks whether the 'remove' property positively set in styles
 * with only one positive value - 'true'.
 *
 * @param styles Array of styles.
 *
 * @returns True if there is 'remove' property with 'true' value in `styles`.
 */
const isRemoveSetInStyles = styles => {
  return styles.some(s => {
    return s.property === REMOVE_PSEUDO_MARKER && s.value === PSEUDO_PROPERTY_POSITIVE_VALUE;
  });
};

/**
 * Checks whether styles contain action pseudo-class declarations.
 *
 * @param styles Array of styles.
 *
 * @returns True if styles contain action pseudo-class declarations.
 */
const hasActionPseudoStyles = styles => {
  return styles.some(s => isActionPseudoMarker(s.property));
};

/**
 * Filters styles declared together with an action pseudo-class:
 * such styles are ignored except `content` and `debug` needed for internal usage.
 *
 * @param styles Array of styles.
 *
 * @returns Styles which should be kept.
 */
const filterActionRuleStyles = styles => {
  return styles.filter(s => {
    return s.property === CONTENT_CSS_PROPERTY || s.property === DEBUG_PSEUDO_PROPERTY_KEY;
  });
};

/**
 * Removes action pseudo-class declarations from style block styles:
 * `remove-attr` and `remove-class` are supported only as pseudo-classes.
 *
 * @param styles Array of styles.
 *
 * @returns Styles without action pseudo-class declarations.
 */
const filterStyleBlockActionDeclarations = styles => {
  return styles.filter(s => !isActionStyleMarker(s.property));
};

/**
 * Filters style-block declarations of a rule according to its selector:
 * if the selector contains an action pseudo-class, styles declared in the block
 * are ignored except `content` and `debug`;
 * otherwise action declarations (`remove-attr` and `remove-class`)
 * are removed as they are supported only as pseudo-classes.
 *
 * @param styles Parsed style-block declarations.
 * @param hasActionStyles True if the selector contains an action pseudo-class.
 *
 * @returns Styles which should be kept for the rule.
 */
const filterStyleBlockDeclarations = (styles, hasActionStyles) => {
  return hasActionStyles ? filterActionRuleStyles(styles) : filterStyleBlockActionDeclarations(styles);
};

/**
 * Returns 'debug' property value which is set in styles.
 *
 * @param styles Array of styles.
 *
 * @returns Value of 'debug' property if it is set in `styles`,
 * or `undefined` if the property is not found.
 */
const getDebugStyleValue = styles => {
  const debugStyle = styles.find(s => {
    return s.property === DEBUG_PSEUDO_PROPERTY_KEY;
  });
  return debugStyle === null || debugStyle === void 0 ? void 0 : debugStyle.value;
};

/**
 * Data of rules with the same selector needed to prepare the final rule data.
 */

/**
 * Prepares final RuleData.
 * Handles `debug` and action pseudo-classes in raw rule data styles:
 * action declarations are moved to `actionStyles`,
 * regular styles of rules with the same selector are kept in `style`,
 * and `content` of action rules is kept in `style` only for `beforeStyleApplied`.
 *
 * @param rawRuleData Raw data of selector css rule parsing.
 *
 * @returns Parsed ExtendedCss rule data.
 * @throws An error if rawRuleData.ast or rawRuleData.styleGroups not defined.
 */
const prepareRuleData = rawRuleData => {
  const selector = rawRuleData.selector,
    ast = rawRuleData.ast,
    styleGroups = rawRuleData.styleGroups;
  if (!ast) {
    throw new Error(`AST should be parsed for selector: '${selector}'`);
  }
  if (!styleGroups) {
    throw new Error(`Styles should be parsed for selector: '${selector}'`);
  }
  const ruleData = {
    selector,
    ast
  };

  // split styles by their source:
  // action pseudo-class declarations, styles of rules without action pseudo-classes,
  // and internal styles of action rules (`content` and `debug` only)
  const actionStyles = [];
  const regularStyles = [];
  const actionRuleStyles = [];
  const allRawStyles = [];
  styleGroups.forEach(group => {
    allRawStyles.push(...group.styles);
    group.styles.forEach(style => {
      if (style.property === DEBUG_PSEUDO_PROPERTY_KEY) {
        // `debug` is handled as a separate property
        return;
      }
      if (group.hasActionPseudoClass) {
        if (isActionStyleMarker(style.property)) {
          actionStyles.push(style);
        } else if (!isActionPseudoMarker(style.property)) {
          actionRuleStyles.push(style);
        }
        // the 'remove' pseudo-class declaration is handled via `shouldRemove`
      } else {
        regularStyles.push(style);
      }
    });
  });
  const debugValue = getDebugStyleValue(allRawStyles);
  // set `debug` as separate property only if its value is valid
  // which is 'true' or 'global'
  if (debugValue === PSEUDO_PROPERTY_POSITIVE_VALUE || debugValue === DEBUG_PSEUDO_PROPERTY_GLOBAL_VALUE) {
    ruleData.debug = debugValue;
  }
  const shouldRemove = isRemoveSetInStyles(allRawStyles);
  if (shouldRemove || actionStyles.length > 0) {
    const actionStyleMap = {};
    if (shouldRemove) {
      // the element is removed, so only 'content' is needed for internal usage
      const contentStyle = [...regularStyles, ...actionRuleStyles].find(s => s.property === CONTENT_CSS_PROPERTY);
      if (contentStyle) {
        actionStyleMap[CONTENT_CSS_PROPERTY] = contentStyle.value;
        ruleData.hasInternalContent = true;
      }
      actionStyleMap[REMOVE_PSEUDO_MARKER] = PSEUDO_PROPERTY_POSITIVE_VALUE;
    } else {
      // keep styles of other rules with the same target selector
      regularStyles.forEach(style => {
        actionStyleMap[style.property] = style.value;
      });
      // keep 'content' of action rules only for `beforeStyleApplied` (e.g. CssHitsCounter);
      // regular 'content' has priority and should be applied to the element
      if (!(CONTENT_CSS_PROPERTY in actionStyleMap)) {
        const contentStyle = actionRuleStyles.find(s => s.property === CONTENT_CSS_PROPERTY);
        if (contentStyle) {
          actionStyleMap[CONTENT_CSS_PROPERTY] = contentStyle.value;
          ruleData.hasInternalContent = true;
        }
      }
    }

    // action pseudo-classes are not stored in `style`:
    // `actionStyles` is the only source of action arguments
    if (actionStyles.length > 0) {
      ruleData.actionStyles = actionStyles;
    }
    ruleData.style = actionStyleMap;
  } else {
    // otherwise all styles should be applied.
    // every style property will be unique because of their converting into object
    if (regularStyles.length > 0) {
      const stylesAsEntries = regularStyles.map(style => {
        const property = style.property,
          value = style.value;
        return [property, value];
      });
      const preparedStyleData = getObjectFromEntries(stylesAsEntries);
      ruleData.style = preparedStyleData;
    }
  }
  return ruleData;
};

/**
 * Combines previously parsed css rules data objects
 * into rules which are ready to apply.
 *
 * @param rawResults Previously parsed css rules data objects.
 *
 * @returns Parsed ExtendedCss rule data.
 */
const combineRulesData = rawResults => {
  const results = [];
  rawResults.forEach((value, key) => {
    const selector = key;
    const ast = value.ast,
      styleGroups = value.styleGroups;
    results.push(prepareRuleData({
      selector,
      ast,
      styleGroups
    }));
  });
  return results;
};

/**
 * Trims `rawStyle` and splits it into tokens.
 *
 * @param rawStyle Style declaration block content inside curly bracket — `{` and `}` —
 * can be a single style declaration or a list of declarations.
 *
 * @returns Array of tokens supported for style declaration block.
 */
const tokenizeStyleBlock = rawStyle => {
  const styleDeclaration = rawStyle.trim();
  return tokenize(styleDeclaration, SUPPORTED_STYLE_DECLARATION_MARKS);
};

/**
 * Describes possible style declaration parts.
 *
 * IMPORTANT: it is used as 'const' instead of 'enum' to avoid side effects
 * during ExtendedCss import into other libraries.
 */
const DECLARATION_PART = {
  PROPERTY: 'property',
  VALUE: 'value'
};

/**
 * Interface for style declaration parser context.
 */

/**
 * Checks whether the quotes has been opened for style value.
 *
 * @param context Style block parser context.
 *
 * @returns True if style value has already opened quotes.
 */
const isValueQuotesOpen = context => {
  return context.bufferValue !== '' && context.valueQuoteMark !== null;
};

/**
 * Saves parsed property and value to collection of parsed styles.
 * Prunes context buffers for property and value.
 *
 * @param context Style block parser context.
 */
const collectStyle = context => {
  context.styles.push({
    property: context.bufferProperty.trim(),
    value: context.bufferValue.trim()
  });
  // reset buffers
  context.bufferProperty = '';
  context.bufferValue = '';
};

/**
 * Handles token which is supposed to be a part of style **property**.
 *
 * @param context Style block parser context.
 * @param styleBlock Whole style block which is being parsed.
 * @param token Current token.
 *
 * @throws An error on invalid token.
 */
const processPropertyToken = (context, styleBlock, token) => {
  const tokenValue = token.value;
  switch (token.type) {
    case TOKEN_TYPE.WORD:
      if (context.bufferProperty.length > 0) {
        // e.g. 'padding top: 0;' - current tokenValue is 'top' which is not valid
        throw new Error(`Invalid style property in style block: '${styleBlock}'`);
      }
      context.bufferProperty += tokenValue;
      break;
    case TOKEN_TYPE.MARK:
      // only colon and whitespaces are allowed while style property parsing
      if (tokenValue === COLON) {
        if (context.bufferProperty.trim().length === 0) {
          // e.g. such style block: '{ : none; }'
          throw new Error(`Missing style property before ':' in style block: '${styleBlock}'`);
        }
        // the property successfully collected
        context.bufferProperty = context.bufferProperty.trim();
        // prepare for value collecting
        context.processing = DECLARATION_PART.VALUE;
        // the property buffer shall be reset after the value is successfully collected
      } else if (WHITE_SPACE_CHARACTERS.includes(tokenValue)) ; else {
        // if after the property there is anything other than ':' except whitespace, this is a parse error
        // https://www.w3.org/TR/css-syntax-3/#consume-declaration
        throw new Error(`Invalid style declaration in style block: '${styleBlock}'`);
      }
      break;
    default:
      throw new Error(`Unsupported style property character: '${tokenValue}' in style block: '${styleBlock}'`);
  }
};

/**
 * Handles token which is supposed to be a part of style **value**.
 *
 * @param context Style block parser context.
 * @param styleBlock Whole style block which is being parsed.
 * @param token Current token.
 *
 * @throws An error on invalid token.
 */
const processValueToken = (context, styleBlock, token) => {
  const tokenValue = token.value;
  if (token.type === TOKEN_TYPE.WORD) {
    // simply collect to buffer
    context.bufferValue += tokenValue;
  } else {
    // otherwise check the mark
    switch (tokenValue) {
      case COLON:
        // the ':' character inside of the value should be inside of quotes
        // otherwise the value is not valid
        // e.g. 'content: display: none'
        // parser is here        ↑
        if (!isValueQuotesOpen(context)) {
          // eslint-disable-next-line max-len
          throw new Error(`Invalid style value for property '${context.bufferProperty}' in style block: '${styleBlock}'`);
        }
        // collect the colon inside quotes
        // e.g. 'content: "test:123"'
        // parser is here      ↑
        context.bufferValue += tokenValue;
        break;
      case SEMICOLON:
        if (isValueQuotesOpen(context)) {
          // ';' inside quotes is part of style value
          // e.g. 'content: "test;"'
          context.bufferValue += tokenValue;
        } else {
          // otherwise the value is successfully collected
          // save parsed style
          collectStyle(context);
          // prepare for value collecting
          context.processing = DECLARATION_PART.PROPERTY;
        }
        break;
      case SINGLE_QUOTE:
      case DOUBLE_QUOTE:
        // if quotes are not open
        if (context.valueQuoteMark === null) {
          // save the opening quote mark for later comparison
          context.valueQuoteMark = tokenValue;
        } else if (!context.bufferValue.endsWith(BACKSLASH)
        // otherwise a quote appeared in the value earlier,
        // and non-escaped quote should be checked whether it is a closing quote
        && context.valueQuoteMark === tokenValue) {
          context.valueQuoteMark = null;
        }
        // always save the quote to the buffer
        // but after the context.bufferValue is checked for BACKSLASH above
        // e.g. 'content: "test:123"'
        //      'content: "\""'
        context.bufferValue += tokenValue;
        break;
      case BACKSLASH:
        if (!isValueQuotesOpen(context)) {
          // eslint-disable-next-line max-len
          throw new Error(`Invalid style value for property '${context.bufferProperty}' in style block: '${styleBlock}'`);
        }
        // collect the backslash inside quotes
        // e.g. ' content: "\"" '
        // parser is here   ↑
        context.bufferValue += tokenValue;
        break;
      case SPACE:
      case TAB:
      case CARRIAGE_RETURN:
      case LINE_FEED:
      case FORM_FEED:
        // whitespace should be collected only if the value collecting started
        // which means inside of the value
        // e.g. 'width: 100% !important'
        // parser is here   ↑
        if (context.bufferValue.length > 0) {
          context.bufferValue += tokenValue;
        }
        // otherwise it can be omitted
        // e.g. 'width:  100% !important'
        // here        ↑
        break;
      default:
        throw new Error(`Unknown style declaration token: '${tokenValue}'`);
    }
  }
};

/**
 * Parses css rule style block.
 *
 * @param rawStyleBlock Style block to parse.
 *
 * @returns Array of style declarations.
 * @throws An error on invalid style block.
 */
const parseStyleBlock = rawStyleBlock => {
  const styleBlock = rawStyleBlock.trim();
  const tokens = tokenizeStyleBlock(styleBlock);
  const context = {
    // style declaration parsing always starts with 'property'
    processing: DECLARATION_PART.PROPERTY,
    styles: [],
    bufferProperty: '',
    bufferValue: '',
    valueQuoteMark: null
  };
  let i = 0;
  while (i < tokens.length) {
    const token = tokens[i];
    if (!token) {
      break;
    }
    if (context.processing === DECLARATION_PART.PROPERTY) {
      processPropertyToken(context, styleBlock, token);
    } else if (context.processing === DECLARATION_PART.VALUE) {
      processValueToken(context, styleBlock, token);
    } else {
      throw new Error('Style declaration parsing failed');
    }
    i += 1;
  }

  // unbalanced value quotes
  // e.g. 'content: "test} '
  if (isValueQuotesOpen(context)) {
    throw new Error(`Unbalanced style declaration quotes in style block: '${styleBlock}'`);
  }

  // collected property and value have not been saved to styles;
  // it is possible for style block with no semicolon at the end
  // e.g. such style block: '{ display: none }'
  if (context.bufferProperty.length > 0) {
    if (context.bufferValue.length === 0) {
      // e.g. such style blocks:
      //   '{ display:  }'
      //   '{ remove }'
      // eslint-disable-next-line max-len
      throw new Error(`Missing style value for property '${context.bufferProperty}' in style block '${styleBlock}'`);
    }
    collectStyle(context);
  }

  // rule with empty style block
  // e.g. 'div { }'
  if (context.styles.length === 0) {
    throw new Error(STYLE_ERROR_PREFIX.NO_STYLE);
  }
  return context.styles;
};

// TODO: use `extCssDoc` for caching of style block parser results
/**
 * Parses CSS rule into rules data object:
 * 1. Find the last `{` mark in the rule
 *    which supposed to be a divider between selector and style block.
 * 2. Validates found string part before the `{` via selector parser; and if:
 *  - parsing failed – get the previous `{` in the rule,
 *    and validates a new rule part again [2];
 *  - parsing successful — saves a found rule part as selector and parses the style block.
 *
 * @param rawCssRule Single CSS rule to parse.
 * @param extCssDoc ExtCssDocument which is used for selector ast caching.
 *
 * @returns Array of rules data which contains:
 *   - selector as string;
 *   - ast to query elements by;
 *   - map of styles to apply.
 * @throws An error on invalid css rule syntax:
 *   - unsupported CSS features – comments and at-rules
 *   - invalid selector or style block.
 */
const parseRule = (rawCssRule, extCssDoc) => {
  var _rawRuleData$selector;
  const cssRule = rawCssRule.trim();
  if (cssRule.includes(`${SLASH}${ASTERISK}`) && cssRule.includes(`${ASTERISK}${SLASH}`)) {
    throw new Error(STYLE_ERROR_PREFIX.NO_COMMENT);
  }

  // braces inside quoted strings, regexp literals and action arguments are skipped
  const leftCurlyBracketIndexes = findStyleBlockStarts(cssRule);

  // rule with style block but no selector
  // e.g. '{ display: none; }'
  if (getFirst(leftCurlyBracketIndexes) === 0) {
    throw new Error(NO_SELECTOR_ERROR_PREFIX);
  }
  let selectorData;

  // if rule has `{` but there is no `}`
  if (leftCurlyBracketIndexes.length > 0 && !cssRule.includes(BRACKET.CURLY.RIGHT)) {
    throw new Error(`${STYLE_ERROR_PREFIX.NO_STYLE} OR ${STYLE_ERROR_PREFIX.UNCLOSED_STYLE}`);
  }
  if (
  // if rule has no `{`
  leftCurlyBracketIndexes.length === 0
  // or `}`
  || !cssRule.includes(BRACKET.CURLY.RIGHT)) {
    try {
      // the whole css rule considered as "selector part"
      // which may contain an action pseudo-class
      selectorData = parseSelectorRulePart(cssRule, extCssDoc);
      if (selectorData.success) {
        var _selectorData$stylesO;
        // rule with no style block has a valid action pseudo-class
        // which is parsed into "styles"
        // e.g. 'div:remove()'
        // but also it can be just selector with no styles
        // e.g. 'div'
        // which should not be considered as valid css rule
        if (((_selectorData$stylesO = selectorData.stylesOfSelector) === null || _selectorData$stylesO === void 0 ? void 0 : _selectorData$stylesO.length) === 0) {
          throw new Error(STYLE_ERROR_PREFIX.NO_STYLE_OR_ACTION);
        }
        return {
          selector: selectorData.selector.trim(),
          ast: selectorData.ast,
          rawStyles: selectorData.stylesOfSelector,
          hasActionPseudoClass: true
        };
      } else {
        // not valid selector
        throw new Error('Invalid selector');
      }
    } catch (e) {
      throw new Error(extended_css_esm_getErrorMessage(e));
    }
  }
  let selectorBuffer;
  let styleBlockBuffer;
  const rawRuleData = {
    selector: ''
  };

  // css rule should be parsed from its end
  for (let i = leftCurlyBracketIndexes.length - 1; i > -1; i -= 1) {
    const index = leftCurlyBracketIndexes[i];
    if (!index) {
      throw new Error(`Impossible to continue, no '{' to process for rule: '${cssRule}'`);
    }
    // selector is before `{`, style block is after it
    selectorBuffer = cssRule.slice(0, index);
    // skip curly brackets
    styleBlockBuffer = cssRule.slice(index + 1, cssRule.length - 1);
    selectorData = parseSelectorRulePart(selectorBuffer, extCssDoc);
    if (selectorData.success) {
      var _rawRuleData$rawStyle;
      // selector successfully parsed
      rawRuleData.selector = selectorData.selector.trim();
      rawRuleData.ast = selectorData.ast;
      rawRuleData.rawStyles = selectorData.stylesOfSelector;
      // style block should be parsed
      // TODO: add cache for style block parsing
      const parsedStyles = parseStyleBlock(styleBlockBuffer);
      const hasActionStyles = hasActionPseudoStyles(rawRuleData.rawStyles ?? []);
      rawRuleData.hasActionPseudoClass = hasActionStyles;
      const stylesToPush = filterStyleBlockDeclarations(parsedStyles, hasActionStyles);
      if (stylesToPush.length === 0 && !hasActionStyles) {
        // rule with only ignored action declarations has nothing to apply
        throw new Error(`${STYLE_ERROR_PREFIX.NO_STYLE}: '${cssRule}'`);
      }
      (_rawRuleData$rawStyle = rawRuleData.rawStyles) === null || _rawRuleData$rawStyle === void 0 || _rawRuleData$rawStyle.push(...stylesToPush);
      // stop rule parsing
      break;
    } else {
      // if selector was not parsed successfully
      // continue with next index of `{`
      continue;
    }
  }
  if (((_rawRuleData$selector = rawRuleData.selector) === null || _rawRuleData$selector === void 0 ? void 0 : _rawRuleData$selector.length) === 0) {
    // skip the rule as selector
    throw new Error('Selector in not valid');
  }
  return rawRuleData;
};

/**
 * Parses array of CSS rules into array of rules data objects.
 * Invalid rules are skipped and not applied,
 * and the errors are logged.
 *
 * @param rawCssRules Array of rules to parse.
 * @param extCssDoc Needed for selector ast caching.
 *
 * @returns Array of parsed valid rules data.
 */
const parseRules = (rawCssRules, extCssDoc) => {
  const rawResults = createRawResultsMap();
  const warnings = [];
  // trim all rules and find unique ones
  const uniqueRules = [...new Set(rawCssRules.map(r => r.trim()))];
  uniqueRules.forEach(rule => {
    try {
      saveToRawResults(rawResults, parseRule(rule, extCssDoc));
    } catch (e) {
      // skip the invalid rule
      const errorMessage = extended_css_esm_getErrorMessage(e);
      warnings.push(`'${rule}' - error: '${errorMessage}'`);
    }
  });

  // log info about skipped invalid rules
  if (warnings.length > 0) {
    extended_css_esm_logger.info(`Invalid rules:\n  ${warnings.join('\n  ')}`);
  }
  return combineRulesData(rawResults);
};

const REGEXP_DECLARATION_END = /[;}]/g;
const REGEXP_DECLARATION_DIVIDER = /[;:}]/g;
const REGEXP_NON_WHITESPACE = /\S/g;

/**
 * Interface for stylesheet parser context.
 */

/**
 * Resets rule data buffer to init value after rule successfully collected.
 *
 * @param context Stylesheet parser context.
 */
const restoreRuleAcc = context => {
  context.rawRuleData = {
    selector: ''
  };
};

/**
 * Parses cropped selector part found before `{` previously.
 *
 * @param context Stylesheet parser context.
 * @param extCssDoc Needed for caching of selector ast.
 *
 * @returns Parsed validation data for cropped part of stylesheet which may be a selector.
 * @throws An error on unsupported CSS features, e.g. at-rules.
 */
const parseSelectorPart = (context, extCssDoc) => {
  let selector = context.selectorBuffer.trim();
  if (selector.startsWith(AT_RULE_MARKER)) {
    throw new Error(`${NO_AT_RULE_ERROR_PREFIX}: '${selector}'.`);
  }
  let actionSelectorData;
  try {
    actionSelectorData = parseActionSelector(selector);
  } catch (e) {
    extended_css_esm_logger.error(extended_css_esm_getErrorMessage(e));
    throw e;
  }
  if (context.nextIndex === -1) {
    if (selector === actionSelectorData.selector) {
      // rule should have style or action pseudo-class
      throw new Error(`${STYLE_ERROR_PREFIX.NO_STYLE_OR_ACTION}: '${context.cssToParse}'`);
    }
    // stop parsing as there is no style declaration and selector parsed fine
    context.cssToParse = '';
  }
  let stylesOfSelector = [];
  let success = false;
  let ast;
  try {
    selector = actionSelectorData.selector;
    stylesOfSelector = actionSelectorData.stylesOfSelector;
    // validate found selector by parsing it to ast
    // so if it is invalid error will be thrown
    ast = extCssDoc.getSelectorAst(selector);
    success = true;
  } catch (e) {
    success = false;
  }
  if (context.nextIndex > 0) {
    // slice found valid selector part off
    // and parse rest of stylesheet later
    context.cssToParse = context.cssToParse.slice(context.nextIndex);
  }
  return {
    success,
    selector,
    ast,
    stylesOfSelector
  };
};

/**
 * Recursively parses style declaration string into `Style`s.
 *
 * @param context Stylesheet parser context.
 * @param styles Array of styles.
 *
 * @throws An error on invalid style declaration.
 * @returns A number index of the next `}` in `this.cssToParse`.
 */
const parseUntilClosingBracket = (context, styles) => {
  // Expects ":", ";", and "}".
  REGEXP_DECLARATION_DIVIDER.lastIndex = context.nextIndex;
  let match = REGEXP_DECLARATION_DIVIDER.exec(context.cssToParse);
  if (match === null) {
    throw new Error(`${STYLE_ERROR_PREFIX.INVALID_STYLE}: '${context.cssToParse}'`);
  }
  let matchPos = match.index;
  let matched = match[0];
  if (matched === BRACKET.CURLY.RIGHT) {
    const declarationChunk = context.cssToParse.slice(context.nextIndex, matchPos);
    if (declarationChunk.trim().length === 0) {
      // empty style declaration
      // e.g. 'div { }'
      if (styles.length === 0) {
        throw new Error(`${STYLE_ERROR_PREFIX.NO_STYLE}: '${context.cssToParse}'`);
      }
      // else valid style parsed before it
      // e.g. '{ display: none; }' -- position is after ';'
    } else {
      // closing curly bracket '}' is matched before colon ':'
      // trimmed declarationChunk is not a space, between ';' and '}',
      // e.g. 'visible }' in style '{ display: none; visible }' after part before ';' is parsed
      throw new Error(`${STYLE_ERROR_PREFIX.INVALID_STYLE}: '${context.cssToParse}'`);
    }
    return matchPos;
  }
  if (matched === COLON) {
    const colonIndex = matchPos;
    // Expects ";" and "}".
    REGEXP_DECLARATION_END.lastIndex = colonIndex;
    match = REGEXP_DECLARATION_END.exec(context.cssToParse);
    if (match === null) {
      throw new Error(`${STYLE_ERROR_PREFIX.UNCLOSED_STYLE}: '${context.cssToParse}'`);
    }
    matchPos = match.index;
    matched = match[0];
    // Populates the `styleMap` key-value map.
    const property = context.cssToParse.slice(context.nextIndex, colonIndex).trim();
    if (property.length === 0) {
      throw new Error(`${STYLE_ERROR_PREFIX.NO_PROPERTY}: '${context.cssToParse}'`);
    }
    const value = context.cssToParse.slice(colonIndex + 1, matchPos).trim();
    if (value.length === 0) {
      throw new Error(`${STYLE_ERROR_PREFIX.NO_VALUE}: '${context.cssToParse}'`);
    }
    styles.push({
      property,
      value
    });
    // finish style parsing if '}' is found
    // e.g. '{ display: none }' -- no ';' at the end of declaration
    if (matched === BRACKET.CURLY.RIGHT) {
      return matchPos;
    }
  }
  // matchPos is the position of the next ';'
  // crop 'cssToParse' and re-run the loop
  context.cssToParse = context.cssToParse.slice(matchPos + 1);
  context.nextIndex = 0;
  return parseUntilClosingBracket(context, styles); // Should be a subject of tail-call optimization.
};

/**
 * Parses next style declaration part in stylesheet.
 *
 * @param context Stylesheet parser context.
 *
 * @returns Array of style data objects.
 */
const parseNextStyle = context => {
  const styles = [];
  const styleEndPos = parseUntilClosingBracket(context, styles);

  // find next rule after the style declaration
  REGEXP_NON_WHITESPACE.lastIndex = styleEndPos + 1;
  const match = REGEXP_NON_WHITESPACE.exec(context.cssToParse);
  if (match === null) {
    context.cssToParse = '';
    return styles;
  }
  const matchPos = match.index;

  // cut out matched style declaration for previous selector
  context.cssToParse = context.cssToParse.slice(matchPos);
  return styles;
};

/**
 * Parses stylesheet of rules into rules data objects (non-recursively):
 * 1. Iterates through stylesheet string.
 * 2. Finds first `{` which can be style declaration start or part of selector.
 * 3. Validates found string part via selector parser; and if:
 *  - it throws error — saves string part to buffer as part of selector,
 *    slice next stylesheet part to `{` [2] and validates again [3];
 *  - no error — saves found string part as selector and starts to parse styles (recursively).
 *
 * @param rawStylesheet Raw stylesheet as string.
 * @param extCssDoc ExtCssDocument which uses cache while selectors parsing.
 * @throws An error on unsupported CSS features, e.g. comments or invalid stylesheet syntax.
 * @returns Array of rules data which contains:
 * - selector as string;
 * - ast to query elements by;
 * - map of styles to apply.
 */
const parseStylesheet = (rawStylesheet, extCssDoc) => {
  const stylesheet = rawStylesheet.trim();
  if (stylesheet.includes(`${SLASH}${ASTERISK}`) && stylesheet.includes(`${ASTERISK}${SLASH}`)) {
    throw new Error(`${STYLE_ERROR_PREFIX.NO_COMMENT} in stylesheet: '${stylesheet}'`);
  }
  const context = {
    // any stylesheet should start with selector
    isSelector: true,
    // init value of parser position
    nextIndex: 0,
    // init value of cssToParse
    cssToParse: stylesheet,
    // buffer for collecting selector part
    selectorBuffer: '',
    // accumulator for rules
    rawRuleData: {
      selector: ''
    }
  };
  const rawResults = createRawResultsMap();
  let selectorData;

  // context.cssToParse is going to be cropped while its parsing
  while (context.cssToParse) {
    if (context.isSelector) {
      // find index of first opening curly bracket
      // which may mean start of style part and end of selector one;
      // the scan stops at the first bracket to keep parsing linear
      context.nextIndex = findStyleBlockStart(context.cssToParse);
      // rule should not start with style, selector is required
      // e.g. '{ display: none; }'
      if (context.selectorBuffer.length === 0 && context.nextIndex === 0) {
        throw new Error(`${STYLE_ERROR_PREFIX.NO_SELECTOR}: '${context.cssToParse}'`);
      }
      if (context.nextIndex === -1) {
        // no style declaration in rule
        // but rule still may contain action pseudo-class
        context.selectorBuffer = context.cssToParse;
      } else {
        // collect string parts before opening curly bracket
        // until valid selector collected
        context.selectorBuffer += context.cssToParse.slice(0, context.nextIndex);
      }
      selectorData = parseSelectorPart(context, extCssDoc);
      if (selectorData.success) {
        // selector successfully parsed
        context.rawRuleData.selector = selectorData.selector.trim();
        context.rawRuleData.ast = selectorData.ast;
        context.rawRuleData.rawStyles = selectorData.stylesOfSelector;
        context.rawRuleData.hasActionPseudoClass = hasActionPseudoStyles(selectorData.stylesOfSelector ?? []);
        context.isSelector = false;
        // save rule data if there is no style declaration
        if (context.nextIndex === -1) {
          saveToRawResults(rawResults, context.rawRuleData);
          // clean up ruleContext
          restoreRuleAcc(context);
        } else {
          // skip the opening curly bracket at the start of style declaration part
          context.nextIndex = 1;
          context.selectorBuffer = '';
        }
      } else {
        // if selector was not successfully parsed parseSelectorPart(), continue stylesheet parsing:
        // save the found bracket to buffer and proceed to next loop iteration
        context.selectorBuffer += BRACKET.CURLY.LEFT;
        // delete `{` from cssToParse
        context.cssToParse = context.cssToParse.slice(1);
      }
    } else {
      // style declaration should be parsed
      const parsedStyles = parseNextStyle(context);

      // styles can be parsed from selector part if it has an action pseudo-class
      // e.g. '.banner:remove() { debug: true; }'
      const hasActionStyles = !!context.rawRuleData.hasActionPseudoClass;
      const stylesToPush = filterStyleBlockDeclarations(parsedStyles, hasActionStyles);

      // rule with only ignored action declarations has nothing to apply
      if (stylesToPush.length > 0 || hasActionStyles) {
        var _context$rawRuleData$;
        (_context$rawRuleData$ = context.rawRuleData.rawStyles) === null || _context$rawRuleData$ === void 0 || _context$rawRuleData$.push(...stylesToPush);
        // save rule data to results
        saveToRawResults(rawResults, context.rawRuleData);
      }
      context.nextIndex = 0;

      // clean up ruleContext
      restoreRuleAcc(context);

      // parse next rule selector after style successfully parsed
      context.isSelector = true;
    }
  }
  return combineRulesData(rawResults);
};

/**
 * Checks whether passed `arg` is number type.
 *
 * @param arg Value to check.
 *
 * @returns True if `arg` is number and not NaN.
 */
const isNumber = arg => {
  return typeof arg === 'number' && !Number.isNaN(arg);
};

/**
 * The purpose of ThrottleWrapper is to throttle calls of the function
 * that applies ExtendedCss rules. The reasoning here is that the function calls
 * are triggered by MutationObserver and there may be many mutations in a short period of time.
 * We do not want to apply rules on every mutation so we use this helper to make sure
 * that there is only one call in the given amount of time.
 */
class ThrottleWrapper {
  /**
   * Creates new ThrottleWrapper.
   * The {@link callback} should be executed not more often than {@link ThrottleWrapper.THROTTLE_DELAY_MS}.
   *
   * @param callback The callback.
   */
  constructor(callback) {
    this.callback = callback;
    this.executeCallback = this.executeCallback.bind(this);
  }

  /**
   * Calls the `this.callback` function and update bounded throttle wrapper properties.
   */
  executeCallback() {
    this.lastRunTime = performance.now();
    if (isNumber(this.timerId)) {
      clearTimeout(this.timerId);
      delete this.timerId;
    }
    this.callback();
  }

  /**
   * Schedules the {@link executeCallback} function execution via setTimeout.
   * It may triggered by MutationObserver job which may occur too ofter, so we limit the function execution:
   *
   * 1. If {@link timerId} is set, ignore the call, because the function is already scheduled to be executed;
   *
   * 2. If {@link lastRunTime} is set, we need to check the time elapsed time since the last call. If it is
   * less than {@link ThrottleWrapper.THROTTLE_DELAY_MS}, we schedule the function execution after the remaining time.
   *
   * Otherwise, we execute the function asynchronously to ensure that it is executed
   * in the correct order with respect to DOM events, by deferring its execution until after
   * those tasks have completed.
   */
  run() {
    if (isNumber(this.timerId)) {
      // there is a pending execution scheduled
      return;
    }
    if (isNumber(this.lastRunTime)) {
      const elapsedTime = performance.now() - this.lastRunTime;
      if (elapsedTime < ThrottleWrapper.THROTTLE_DELAY_MS) {
        this.timerId = window.setTimeout(this.executeCallback, ThrottleWrapper.THROTTLE_DELAY_MS - elapsedTime);
        return;
      }
    }

    /**
     * We use `setTimeout` instead `requestAnimationFrame`
     * here because requestAnimationFrame can be delayed for a long time
     * when the browser saves battery or the engine is heavily loaded.
     */
    this.timerId = window.setTimeout(this.executeCallback);
  }
}
_defineProperty(ThrottleWrapper, "THROTTLE_DELAY_MS", 150);

const LAST_EVENT_TIMEOUT_MS = 10;
const IGNORED_EVENTS = ['mouseover', 'mouseleave', 'mouseenter', 'mouseout'];
const SUPPORTED_EVENTS = [
// keyboard events
'keydown', 'keypress', 'keyup',
// mouse events
'auxclick', 'click', 'contextmenu', 'dblclick', 'mousedown', 'mouseenter', 'mouseleave', 'mousemove', 'mouseover', 'mouseout', 'mouseup', 'pointerlockchange', 'pointerlockerror', 'select', 'wheel'];

// 'wheel' event makes scrolling in Safari twitchy
// https://github.com/AdguardTeam/ExtendedCss/issues/120
const SAFARI_PROBLEMATIC_EVENTS = ['wheel'];

/**
 * We use EventTracker to track the event that is likely to cause the mutation.
 * The problem is that we cannot use `window.event` directly from the mutation observer call
 * as we're not in the event handler context anymore.
 */
class EventTracker {
  /**
   * Creates new EventTracker.
   */
  constructor() {
    _defineProperty(this, "getLastEventType", () => this.lastEventType);
    _defineProperty(this, "getTimeSinceLastEvent", () => {
      if (!this.lastEventTime) {
        return null;
      }
      return Date.now() - this.lastEventTime;
    });
    this.trackedEvents = isSafariBrowser ? SUPPORTED_EVENTS.filter(event => !SAFARI_PROBLEMATIC_EVENTS.includes(event)) : SUPPORTED_EVENTS;
    this.trackedEvents.forEach(eventName => {
      document.documentElement.addEventListener(eventName, this.trackEvent, true);
    });
  }

  /**
   * Callback for event listener for events tracking.
   *
   * @param event Any event.
   */
  trackEvent(event) {
    this.lastEventType = event.type;
    this.lastEventTime = Date.now();
  }
  /**
   * Checks whether the last caught event should be ignored.
   *
   * @returns True if event should be ignored.
   */
  isIgnoredEventType() {
    const lastEventType = this.getLastEventType();
    const sinceLastEventTime = this.getTimeSinceLastEvent();
    return !!lastEventType && IGNORED_EVENTS.includes(lastEventType) && !!sinceLastEventTime && sinceLastEventTime < LAST_EVENT_TIMEOUT_MS;
  }

  /**
   * Stops event tracking by removing event listener.
   */
  stopTracking() {
    this.trackedEvents.forEach(eventName => {
      document.documentElement.removeEventListener(eventName, this.trackEvent, true);
    });
  }
}

/**
 * Matches a CSS attribute selector and captures the attribute name.
 */
const ATTRIBUTE_SELECTOR_REGEXP = /\[\s*([a-zA-Z_][\w-]*)/g;

/**
 * Matches an attribute reference inside an `:xpath()` argument, e.g. `@data-on`.
 */
const XPATH_ATTRIBUTE_REGEXP = /@([\w-]+)/g;

/**
 * Matches a `:matches-attr()` pseudo-class and captures its argument:
 * a regexp literal (which can contain parentheses) or a plain name pattern.
 */
const MATCHES_ATTR_REGEXP = new RegExp(`:${MATCHES_ATTR_PSEUDO_CLASS_MARKER}\\(\\s*(\\/(?:\\\\.|[^/\\\\])*\\/[a-z]*|[^)]+)\\)`, 'gi');

/**
 * Data needed to observe DOM mutations which can affect applied rules.
 */

/**
 * Collects captured values of a regexp into the names array.
 *
 * @param input Scanned string.
 * @param regexp Regexp with a capturing group.
 * @param names Array to push captured values to.
 */
const collectMatches = (input, regexp, names) => {
  regexp.lastIndex = 0;
  let match = regexp.exec(input);
  while (match !== null) {
    if (match[1]) {
      names.push(match[1]);
    }
    match = regexp.exec(input);
  }
};

/**
 * Removes surrounding quotes from a value if they are present.
 *
 * @param value Value to process.
 *
 * @returns Value without surrounding quotes.
 */
const stripQuotes = value => {
  if (value.length > 1 && (value.startsWith(DOUBLE_QUOTE) && value.endsWith(DOUBLE_QUOTE) || value.startsWith(SINGLE_QUOTE) && value.endsWith(SINGLE_QUOTE))) {
    return value.slice(1, -1);
  }
  return value;
};

/**
 * Collects attribute names used in a selector, e.g. 'data-x' from '[data-x="1"]'.
 *
 * The extraction is textual and covers plain attribute names:
 * namespaced (e.g. `[xml|lang]`) or escaped names may be missed,
 * and attribute-like text inside quoted values may be collected as a name.
 * False positives only widen the observation, so they are harmless.
 *
 * Both the original and the lower-cased spelling are returned:
 * HTML attribute names are lower-cased in mutation records,
 * while SVG ones preserve their case.
 *
 * @param selector Selector text.
 *
 * @returns Attribute names found in the selector.
 */
const getSelectorAttributeNames = selector => {
  const names = [];
  // CSS attribute selectors
  collectMatches(selector, ATTRIBUTE_SELECTOR_REGEXP, names);
  // attribute references inside :xpath() arguments, e.g. '@data-on'
  collectMatches(selector, XPATH_ATTRIBUTE_REGEXP, names);
  const result = [];
  names.forEach(name => {
    result.push(name);
    const lowerCasedName = name.toLowerCase();
    if (lowerCasedName !== name) {
      result.push(lowerCasedName);
    }
  });
  return result;
};

/**
 * Collects `:matches-attr()` name arguments from a selector.
 *
 * @param selector Selector text.
 *
 * @returns Name arguments of `:matches-attr()` pseudo-classes.
 */
const getMatchesAttrNames = selector => {
  const args = [];
  collectMatches(selector, MATCHES_ATTR_REGEXP, args);
  return args.map(arg => stripQuotes((arg.split(EQUAL_SIGN)[0] ?? '').trim()));
};

/**
 * Adds a `:remove-attr()` argument to the observation data.
 *
 * Plain arguments are observed natively by name, while a regexp argument
 * can match any attribute, so the observer watches all attributes
 * and checks them with a matcher.
 *
 * Both the original and the lower-cased spelling of a plain argument
 * are observed: HTML attribute names are lower-cased in mutation records,
 * while SVG ones preserve their case.
 *
 * @param data Mutation observation data.
 * @param arg `:remove-attr()` argument.
 */
const addActionArg = (data, arg) => {
  if (!arg || data.mergedArgs.has(arg)) {
    return;
  }
  data.mergedArgs.add(arg);
  if (REGEXP_ACTION_ARG.test(arg)) {
    // any attribute can match a regexp argument
    data.observeAllAttributes = true;
    data.attributeMatchers.push(createActionArgMatcher(arg));
    return;
  }
  data.attributeNames.add(arg);
  data.selectorAttributeNames.add(arg);
  const lowerCasedArg = arg.toLowerCase();
  if (lowerCasedArg !== arg) {
    data.attributeNames.add(lowerCasedArg);
    data.selectorAttributeNames.add(lowerCasedArg);
  }
};

/**
 * Adds a `:matches-attr()` name argument to the observation data.
 *
 * The argument is converted with the same helper as in the selector engine,
 * so the mutation relevance check matches the runtime behavior:
 * plain names are observed natively by name, while regexp and wildcard
 * patterns make the observer watch all attributes.
 *
 * @param data Mutation observation data.
 * @param arg `:matches-attr()` name argument.
 */
const addSelectorNameArg = (data, arg) => {
  if (!arg || data.mergedArgs.has(arg)) {
    return;
  }
  data.mergedArgs.add(arg);
  let nameMatch;
  try {
    nameMatch = getValidMatcherArg(arg);
  } catch (e) {
    // invalid arguments are rejected by the selector engine at query time
    return;
  }
  if (typeof nameMatch === 'string') {
    // both spellings are observed: HTML attribute names are lower-cased
    // in mutation records, while SVG ones preserve their case
    data.attributeNames.add(nameMatch);
    data.selectorAttributeNames.add(nameMatch);
    const lowerCasedName = nameMatch.toLowerCase();
    if (lowerCasedName !== nameMatch) {
      data.attributeNames.add(lowerCasedName);
      data.selectorAttributeNames.add(lowerCasedName);
    }
    return;
  }

  // a regexp or wildcard name can match any attribute
  data.observeAllAttributes = true;
  data.attributeMatchers.push(name => nameMatch.test(name));
};

/**
 * Collects data needed to observe mutations which can affect applied rules.
 *
 * `id` and `class` attributes are always observed as they are used by selectors.
 * Attributes used by action rule selectors and plain `:remove-attr()` arguments
 * are observed natively; a regexp `:remove-attr()` argument or a regexp or
 * wildcard `:matches-attr()` name makes the observer watch all attributes.
 *
 * @param context ExtendedCss context.
 *
 * @returns Data for mutation observation.
 */
const createMutationObservationData = context => {
  const data = {
    attributeNames: new Set([ID_ATTRIBUTE, CLASS_ATTRIBUTE]),
    attributeMatchers: [],
    mergedArgs: new Set(),
    selectorAttributeNames: new Set(),
    observeAllAttributes: false
  };
  context.parsedRules.forEach(rule => {
    var _rule$actionStyles;
    // only action rules need to react to changes of attributes
    // used by their selectors: actions are re-applied on mutations,
    // while regular rules react only to `id`/`class` changes as before
    if (!((_rule$actionStyles = rule.actionStyles) !== null && _rule$actionStyles !== void 0 && _rule$actionStyles.length)) {
      return;
    }
    getSelectorAttributeNames(rule.selector).forEach(name => {
      data.selectorAttributeNames.add(name);
      data.attributeNames.add(name);
    });
    getMatchesAttrNames(rule.selector).forEach(name => {
      addSelectorNameArg(data, name);
    });
    rule.actionStyles.forEach(actionStyle => {
      if (actionStyle.property !== REMOVE_ATTR_PSEUDO_MARKER) {
        return;
      }
      addActionArg(data, actionStyle.value);
    });
  });
  return data;
};

/**
 * Cache of mutation observation data per context:
 * parsed rules are set only in the constructor, so the data is built once.
 */
const mutationObservationDataCache = new WeakMap();

/**
 * Returns data needed to observe mutations which can affect applied rules,
 * building it once per context.
 *
 * @param context ExtendedCss context.
 *
 * @returns Data for mutation observation.
 */
const getMutationObservationData = context => {
  let data = mutationObservationDataCache.get(context);
  if (!data) {
    data = createMutationObservationData(context);
    mutationObservationDataCache.set(context, data);
  }
  return data;
};

/**
 * Adds attributes used by action styles of the given rules
 * to the mutation observation data.
 *
 * Needed because the data is built from parsed rules, while the
 * `beforeStyleApplied` callback can edit or add action arguments:
 * without the merge, mutations of attributes from edited arguments
 * would not be observed and actions would not be re-applied.
 *
 * @param context ExtendedCss context.
 * @param rules Rules data to merge.
 */
const addRulesToMutationObservation = (context, rules) => {
  const data = getMutationObservationData(context);
  rules.forEach(rule => {
    var _rule$actionStyles2;
    (_rule$actionStyles2 = rule.actionStyles) === null || _rule$actionStyles2 === void 0 || _rule$actionStyles2.forEach(actionStyle => {
      if (actionStyle.property !== REMOVE_ATTR_PSEUDO_MARKER) {
        return;
      }
      addActionArg(data, actionStyle.value);
    });
  });
};

/**
 * Creates a checker which decides whether a DOM mutation can affect the applied rules.
 *
 * `id` and `class` attributes are always checked as they are used by selectors,
 * attributes used by action rule selectors are checked,
 * and `remove-attr()` arguments and regexp or wildcard `:matches-attr()` names
 * are checked with the corresponding matchers.
 *
 * @param data Mutation observation data.
 *
 * @returns Mutation relevance checker.
 */
const createMutationRelevanceChecker = data => mutation => {
  if (mutation.type !== 'attributes') {
    return true;
  }
  const attributeName = mutation.attributeName;
  if (!attributeName) {
    return true;
  }
  if (attributeName === ID_ATTRIBUTE || attributeName === CLASS_ATTRIBUTE) {
    return true;
  }
  if (data.selectorAttributeNames.has(attributeName)) {
    return true;
  }
  return data.attributeMatchers.some(isMatch => isMatch(attributeName));
};

/**
 * We are trying to limit the number of callback calls by not calling it on all kind of "hover" events.
 * The rationale behind this is that "hover" events often cause attributes modification,
 * but re-applying extCSS rules will be useless as these attribute changes are usually transient.
 *
 * @param mutations DOM elements mutation records.
 * @returns True if all mutations are about attributes changes, otherwise false.
 */
function shouldIgnoreMutations(mutations) {
  // ignore if all mutations are about attributes changes
  return !mutations.some(m => m.type !== 'attributes');
}

/**
 * Adds new `context.domMutationObserver` instance and connect it to document.
 * 
 * @param context ExtendedCss context.
 */
function observeDocument(context) {
  if (context.isDomObserved) {
    return;
  }

  // enable dynamically added elements handling
  context.isDomObserved = true;
  const observationData = getMutationObservationData(context);
  const isRelevantMutation = createMutationRelevanceChecker(observationData);
  context.domMutationObserver = new natives.MutationObserver(mutations => {
    if (!mutations || mutations.length === 0) {
      return;
    }
    // ignore mutations which cannot affect the applied rules
    if (!mutations.some(isRelevantMutation)) {
      return;
    }
    const eventTracker = new EventTracker();
    if (eventTracker.isIgnoredEventType() && shouldIgnoreMutations(mutations)) {
      return;
    }
    // save instance of EventTracker to context
    // for removing its event listeners on disconnectDocument() while mainDisconnect()
    context.eventTracker = eventTracker;
    context.scheduler.run();
  });
  context.domMutationObserver.observe(document, {
    childList: true,
    subtree: true,
    attributes: true,
    // if a regexp or wildcard argument can match any attribute,
    // all attributes should be observed
    ...(observationData.observeAllAttributes ? {} : {
      attributeFilter: [...observationData.attributeNames]
    })
  });
}

/**
 * Disconnect from `context.domMutationObserver`.
 * 
 * @param context ExtendedCss context.
 */
function disconnectDocument(context) {
  if (!context.isDomObserved) {
    return;
  }

  // disable dynamically added elements handling
  context.isDomObserved = false;
  if (context.domMutationObserver) {
    context.domMutationObserver.disconnect();
  }

  // clean up event listeners
  if (context.eventTracker) {
    context.eventTracker.stopTracking();
  }
}

// added by tsurlfilter's CssHitsCounter
const CONTENT_ATTR_PREFIX_REGEXP = /^("|')adguard.+?/;

/**
 * Checks whether the rule contains regular styles to apply:
 * action pseudo-classes and the internal 'content' of action rules
 * are needed for internal usage and should not be counted as regular styles.
 *
 * @param rule Rule data.
 *
 * @returns True if the rule contains regular styles.
 */
const hasRegularStyles = rule => {
  const style = rule.style;
  if (!style) {
    return false;
  }
  return Object.keys(style).some(prop => {
    // `remove` is an action marker and is not a CSS property
    if (isActionPseudoMarker(prop)) {
      return false;
    }
    // 'content' of action rules is kept only for `beforeStyleApplied`
    if (prop === CONTENT_CSS_PROPERTY && rule.hasInternalContent) {
      return false;
    }
    return true;
  });
};

/**
 * Removes attributes matching the `:remove-attr()` argument from the node.
 *
 * @param node DOM node.
 * @param arg Normalized `:remove-attr()` argument.
 * @param skipStyleAttribute True if the `style` attribute should not be removed.
 *
 * @returns Number of removed attributes.
 */
const removeAttributes = function (node, arg) {
  let skipStyleAttribute = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  if (!(node instanceof Element)) {
    return 0;
  }
  let removedCount = 0;
  const isMatch = createActionArgMatcher(arg);
  node.getAttributeNames().forEach(name => {
    if (skipStyleAttribute && name === STYLE_ATTRIBUTE) {
      return;
    }
    if (isMatch(name)) {
      node.removeAttribute(name);
      removedCount += 1;
    }
  });
  return removedCount;
};

/**
 * Removes classes matching the `:remove-class()` argument from the node.
 *
 * @param node DOM node.
 * @param arg Normalized `:remove-class()` argument.
 *
 * @returns Number of removed classes.
 */
const removeClasses = (node, arg) => {
  if (!(node instanceof Element)) {
    return 0;
  }
  let removedCount = 0;
  const isMatch = createActionArgMatcher(arg);
  // snapshot classes as the live collection is mutated while removing
  [...node.classList].forEach(name => {
    if (isMatch(name)) {
      node.classList.remove(name);
      removedCount += 1;
    }
  });
  return removedCount;
};

/**
 * Removes the specified DOM node.
 *
 * @param context ExtendedCss context.
 * @param affectedElement Affected element.
 * @param node Node to remove: the matched node or the one selected by the callback.
 *
 * @returns True if the node was removed from DOM.
 */
const removeElement = (context, affectedElement, node) => {
  affectedElement.removed = true;
  const elementSelector = getElementSelectorPath(node);

  // check if the element has been already removed earlier
  const elementRemovalsCounter = context.removalsStatistic[elementSelector] || 0;

  // if removals attempts happened more than specified we do not try to remove node again
  if (elementRemovalsCounter > MAX_STYLE_PROTECTION_COUNT) {
    extended_css_esm_logger.error(`ExtendedCss: infinite loop protection for selector: '${elementSelector}'`);
    return false;
  }
  if (node.parentElement) {
    node.parentElement.removeChild(node);
    context.removalsStatistic[elementSelector] = elementRemovalsCounter + 1;
    return true;
  }
  return false;
};

/**
 * Sets style to the specified DOM node.
 *
 * @param node DOM element.
 * @param style Style to set.
 * @param skipContent True if the `content` property should not be applied:
 * such `content` is kept only for `beforeStyleApplied` (e.g. CssHitsCounter).
 */
const setStyleToElement = function (node, style) {
  let skipContent = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  if (!(node instanceof HTMLElement)) {
    return;
  }
  Object.keys(style).forEach(prop => {
    // action pseudo-classes are handled by applyStyle() and are not CSS properties
    if (isActionStyleMarker(prop)) {
      return;
    }
    // do not apply internal 'content' of action rules
    // (e.g. via the style protection observer)
    if (skipContent && prop === CONTENT_CSS_PROPERTY) {
      return;
    }
    // Apply this style only to existing properties
    // We cannot use hasOwnProperty here (does not work in FF)
    if (typeof node.style.getPropertyValue(prop.toString()) !== 'undefined') {
      let value = style[prop];
      if (!value) {
        return;
      }
      // do not apply 'content' style given by tsurlfilter
      // which is needed only for BeforeStyleAppliedCallback
      if (prop === CONTENT_CSS_PROPERTY && value.match(CONTENT_ATTR_PREFIX_REGEXP)) {
        return;
      }
      // First we should remove !important attribute (or it won't be applied')
      value = removeSuffix(value.trim(), '!important').trim();
      node.style.setProperty(prop, value, 'important');
    }
  });
};

/**
 * Checks the required properties of `affectedElement`
 * **before** `beforeStyleApplied()` execution.
 *
 * @param affectedElement Affected element.
 *
 * @returns False if there is no `node` or `rules`
 * or `rules` is not an array.
 */
const isIAffectedElement = affectedElement => {
  return 'node' in affectedElement && 'rules' in affectedElement && affectedElement.rules instanceof Array;
};

/**
 * Checks the required properties of `affectedElement`
 * **after** `beforeStyleApplied()` execution.
 * These properties are needed for proper internal usage.
 *
 * @param affectedElement Affected element.
 *
 * @returns False if there is no `node` or `rules`
 * or `rules` is not an array.
 */
const isAffectedElement = affectedElement => {
  return 'node' in affectedElement && 'originalStyle' in affectedElement && 'rules' in affectedElement && affectedElement.rules instanceof Array;
};

/**
 * Applies action pseudo-class styles of the rule to the specified DOM node.
 *
 * @param context ExtendedCss context.
 * @param node DOM node.
 * @param rule Rule data.
 * @param skipStyleAttribute True if the `style` attribute should not be removed.
 *
 * @returns True if an attribute or a class was removed from DOM.
 */
const applyRuleAction = (context, node, rule, skipStyleAttribute) => {
  var _rule$actionStyles;
  let hasRemovals = false;
  (_rule$actionStyles = rule.actionStyles) === null || _rule$actionStyles === void 0 || _rule$actionStyles.forEach(actionStyle => {
    const statisticKey = `${actionStyle.property}:${actionStyle.value}`;
    // the statistic is stored in the context keyed by the node,
    // so it survives affected element re-creation
    // for self-unmatching rules like '.ad:remove-class(ad)'
    let removalsStatistic = context.actionRemovalsStatistic.get(node);
    if (!removalsStatistic) {
      removalsStatistic = {};
      context.actionRemovalsStatistic.set(node, removalsStatistic);
    }
    const removalsCount = removalsStatistic[statisticKey] ?? 0;
    // limit removals to avoid an endless loop
    // if the page keeps re-adding the attribute or class
    if (removalsCount >= MAX_ACTION_REMOVALS_COUNT) {
      return;
    }
    let removedCount = 0;
    if (actionStyle.property === REMOVE_ATTR_PSEUDO_MARKER) {
      removedCount = removeAttributes(node, actionStyle.value, skipStyleAttribute);
    } else if (actionStyle.property === REMOVE_CLASS_PSEUDO_MARKER) {
      removedCount = removeClasses(node, actionStyle.value);
    }
    if (removedCount > 0) {
      hasRemovals = true;
      removalsStatistic[statisticKey] = removalsCount + 1;
      if (removalsCount + 1 === MAX_ACTION_REMOVALS_COUNT) {
        extended_css_esm_logger.error(`ExtendedCss: infinite loop protection for action '${statisticKey}' of rule '${rule.selector}'`);
      }
    }
  });
  return hasRemovals;
};

/**
 * Applies regular styles of the affected element's rules.
 *
 * Called for each matched rule while rules are being collected,
 * so selectors which depend on styles applied by other rules
 * can match during the same pass.
 *
 * @param context ExtendedCss context.
 * @param affectedElement Affected element.
 * @throws An error if affectedElement has no style to apply.
 */
const applyRuleStyles = (context, affectedElement) => {
  const appliedRules = affectedElement.appliedRules ?? new WeakSet();
  affectedElement.appliedRules = appliedRules;
  const hasUnappliedStyles = affectedElement.rules.some(rule => {
    return hasRegularStyles(rule) && !appliedRules.has(rule);
  });
  // actions are re-applied on DOM mutations,
  // so the callback is called again to let it edit or cancel them
  const hasActions = !!affectedElement.hasActionStyles || affectedElement.rules.some(rule => {
    var _rule$actionStyles2;
    return !!((_rule$actionStyles2 = rule.actionStyles) !== null && _rule$actionStyles2 !== void 0 && _rule$actionStyles2.length);
  });
  // `:remove()` rules should also reach the callback,
  // so it can filter or cancel the removal
  const hasRemovals = affectedElement.rules.some(rule => {
    var _rule$style;
    return ((_rule$style = rule.style) === null || _rule$style === void 0 ? void 0 : _rule$style[REMOVE_PSEUDO_MARKER]) === PSEUDO_PROPERTY_POSITIVE_VALUE;
  });
  // nothing to do for elements with applied regular styles,
  // without actions, removals and new regular styles
  if (affectedElement.isStyleApplied && !hasActions && !hasRemovals && !hasUnappliedStyles) {
    return;
  }
  const beforeStyleApplied = context.beforeStyleApplied;
  let element = affectedElement;
  if (beforeStyleApplied) {
    if (!isIAffectedElement(affectedElement)) {
      throw new Error("Returned IAffectedElement should have 'node' and 'rules' properties");
    }
    const callbackResult = beforeStyleApplied(affectedElement);
    if (!callbackResult) {
      throw new Error("Callback 'beforeStyleApplied' should return IAffectedElement");
    }
    element = callbackResult;
  }
  if (!isAffectedElement(element)) {
    throw new Error("Returned IAffectedElement should have 'node' and 'rules' properties");
  }
  if (beforeStyleApplied) {
    // keep the mutation observer in sync with action arguments
    // which can be edited by the callback
    addRulesToMutationObservation(context, element.rules);
  }
  if (element !== affectedElement) {
    // use rules returned by the callback for the current pass:
    // they are needed for applying actions and for style protection
    affectedElement.rules = element.rules;
  }
  // keep the node selected by the callback:
  // actions and removals are applied to it instead of the matched node
  affectedElement.callbackNode = element.node;
  const _element = element,
    node = _element.node,
    rules = _element.rules;
  for (const rule of rules) {
    const selector = rule.selector,
      style = rule.style,
      debug = rule.debug;
    // rule may not have style to apply
    // e.g. 'div:has(> a) { debug: true }' -> means no style to apply, and enable debug mode
    if (!style) {
      if (!debug) {
        // but rule should not have both style and debug properties
        throw new Error(`No style declaration in rule for selector: '${selector}'`);
      }
      continue;
    }
    // `:remove()` and action pseudo-classes are applied
    // after all rules are queried (see `applyStyle`)
    if (style[REMOVE_PSEUDO_MARKER] === PSEUDO_PROPERTY_POSITIVE_VALUE) {
      continue;
    }
    if (hasRegularStyles(rule) && !appliedRules.has(rule)) {
      // action markers and internal 'content' are skipped by setStyleToElement,
      // so regular styles of other rules with the same selector are applied
      setStyleToElement(node, style, !!rule.hasInternalContent);
      appliedRules.add(rule);
    }
  }

  // flags are set from the rules which are actually applied,
  // including rules returned by the callback:
  // regular styles should be protected and reverted,
  // and actions require the callback to be called before re-application
  const hasAppliedRegularStyles = rules.some(rule => hasRegularStyles(rule));
  affectedElement.hasRegularStyles = !!affectedElement.hasRegularStyles || hasAppliedRegularStyles;
  affectedElement.hasActionStyles = !!affectedElement.hasActionStyles || rules.some(rule => {
    var _rule$actionStyles3;
    return !!((_rule$actionStyles3 = rule.actionStyles) !== null && _rule$actionStyles3 !== void 0 && _rule$actionStyles3.length);
  });
  affectedElement.isStyleApplied = !!affectedElement.isStyleApplied || hasAppliedRegularStyles;
};

/**
 * Applies `:remove()` pseudo-class and actions of the affected element's rules.
 *
 * Regular styles are applied earlier, while rules are being collected
 * (see `applyRuleStyles`), so selectors which depend on applied styles
 * can match during the same pass.
 *
 * @param context ExtendedCss context.
 * @param rawAffectedElement Object containing DOM node and rules to be applied.
 *
 * @returns True if the DOM was changed by a removal.
 */
const applyStyle = (context, rawAffectedElement) => {
  const rules = rawAffectedElement.rules;
  // actions and removals are applied to the node selected by the callback
  // (it is the matched node if the callback did not replace it)
  const node = rawAffectedElement.callbackNode ?? rawAffectedElement.node;
  // only actions and `:remove()` rules require processing
  // after regular styles are applied
  const hasActions = rules.some(rule => {
    var _rule$actionStyles4, _rule$style2;
    return !!((_rule$actionStyles4 = rule.actionStyles) !== null && _rule$actionStyles4 !== void 0 && _rule$actionStyles4.length) || ((_rule$style2 = rule.style) === null || _rule$style2 === void 0 ? void 0 : _rule$style2[REMOVE_PSEUDO_MARKER]) === PSEUDO_PROPERTY_POSITIVE_VALUE;
  });
  if (!hasActions) {
    return false;
  }

  // the `style` attribute should not be removed from elements
  // with protected regular styles, including the first pass;
  // the flag is set by `applyRuleStyles()` for every affected element
  // before actions are applied, and there is at most one affected element per node
  const skipStyleAttribute = !!rawAffectedElement.hasRegularStyles;
  let hasRemovals = false;
  for (const rule of rules) {
    const style = rule.style;
    if (!style) {
      continue;
    }
    if (style[REMOVE_PSEUDO_MARKER] === PSEUDO_PROPERTY_POSITIVE_VALUE) {
      return removeElement(context, rawAffectedElement, node);
    }
    hasRemovals = applyRuleAction(context, node, rule, skipStyleAttribute) || hasRemovals;
  }
  return hasRemovals;
};

/**
 * Reverts style for the affected object.
 *
 * @param affectedElement Affected element.
 */
const revertStyle = affectedElement => {
  if (affectedElement.protectionObserver) {
    affectedElement.protectionObserver.disconnect();
  }
  affectedElement.node.style.cssText = affectedElement.originalStyle;
};

/**
 * ExtMutationObserver is a wrapper over regular MutationObserver with one additional function:
 * it keeps track of the number of times we called the "ProtectionCallback".
 *
 * We use an instance of this to monitor styles added by ExtendedCss
 * and to make sure these styles are recovered if the page script attempts to modify them.
 *
 * However, we want to avoid endless loops of modification if the page script repeatedly modifies the styles.
 * So we keep track of the number of calls and observe() makes a decision
 * whether to continue recovering the styles or not.
 */
class ExtMutationObserver {
  /**
   * Extra property for keeping 'style fix counts'.
   */

  /**
   * Creates new ExtMutationObserver.
   *
   * @param protectionCallback Callback which execution should be counted.
   */
  constructor(protectionCallback) {
    this.styleProtectionCount = 0;
    this.observer = new natives.MutationObserver(mutations => {
      if (!mutations.length) {
        return;
      }
      this.styleProtectionCount += 1;
      protectionCallback(mutations, this);
    });
  }

  /**
   * Starts to observe target element,
   * prevents infinite loop of observing due to the limited number of times of callback runs.
   *
   * @param target Target to observe.
   * @param options Mutation observer options.
   */
  observe(target, options) {
    if (this.styleProtectionCount < MAX_STYLE_PROTECTION_COUNT) {
      this.observer.observe(target, options);
    } else {
      extended_css_esm_logger.error('ExtendedCss: infinite loop protection for style');
    }
  }

  /**
   * Stops ExtMutationObserver from observing any mutations.
   * Until the `observe()` is used again, `protectionCallback` will not be invoked.
   */
  disconnect() {
    this.observer.disconnect();
  }
}

const PROTECTION_OBSERVER_OPTIONS = {
  attributes: true,
  attributeOldValue: true,
  attributeFilter: [STYLE_ATTRIBUTE]
};

/**
 * Style map with a flag indicating whether its `content` should be applied.
 */

/**
 * Creates MutationObserver protection callback.
 *
 * @param styles Styles data objects.
 *
 * @returns Callback for styles protection.
 */
const createProtectionCallback = styles => {
  const protectionCallback = (mutations, extObserver) => {
    if (!mutations[0]) {
      return;
    }
    const target = mutations[0].target;
    extObserver.disconnect();
    styles.forEach(_ref => {
      let style = _ref.style,
        skipContent = _ref.skipContent;
      setStyleToElement(target, style, skipContent);
    });
    extObserver.observe(target, PROTECTION_OBSERVER_OPTIONS);
  };
  return protectionCallback;
};

/**
 * Sets up a MutationObserver which protects style attributes from changes.
 *
 * @param node DOM node.
 * @param rules Rule data objects.
 * @returns Mutation observer used to protect attribute or null if there's nothing to protect.
 */
const protectStyleAttribute = (node, rules) => {
  if (!natives.MutationObserver) {
    return null;
  }
  const styles = [];
  rules.forEach(ruleData => {
    const style = ruleData.style;
    // some rules might have only debug property in style declaration
    // e.g. 'div:has(> a) { debug: true }' -> parsed to boolean `ruleData.debug`
    // so no style is fine, and here we should collect only valid styles to protect
    if (style) {
      styles.push({
        style,
        skipContent: !!ruleData.hasInternalContent
      });
    }
  });
  const protectionObserver = new ExtMutationObserver(createProtectionCallback(styles));
  protectionObserver.observe(node, PROTECTION_OBSERVER_OPTIONS);
  return protectionObserver;
};

const STATS_DECIMAL_DIGITS_COUNT = 4;
/**
 * A helper class for applied rule stats.
 */
class TimingStats {
  /**
   * Creates new TimingStats.
   */
  constructor() {
    this.appliesTimings = [];
    this.appliesCount = 0;
    this.timingsSum = 0;
    this.meanTiming = 0;
    this.squaredSum = 0;
    this.standardDeviation = 0;
  }

  /**
   * Observe target element and mark observer as active.
   *
   * @param elapsedTimeMs Time in ms.
   */
  push(elapsedTimeMs) {
    this.appliesTimings.push(elapsedTimeMs);
    this.appliesCount += 1;
    this.timingsSum += elapsedTimeMs;
    this.meanTiming = this.timingsSum / this.appliesCount;
    this.squaredSum += elapsedTimeMs * elapsedTimeMs;
    this.standardDeviation = Math.sqrt(this.squaredSum / this.appliesCount - Math.pow(this.meanTiming, 2));
  }
}
/**
 * Makes the timestamps more readable.
 *
 * @param timestamp Raw timestamp.
 *
 * @returns Fine-looking timestamps.
 */
const beautifyTimingNumber = timestamp => {
  return Number(timestamp.toFixed(STATS_DECIMAL_DIGITS_COUNT));
};

/**
 * Improves timing stats readability.
 *
 * @param rawTimings Collected timings with raw timestamp.
 *
 * @returns Fine-looking timing stats.
 */
const beautifyTimings = rawTimings => {
  return {
    appliesTimings: rawTimings.appliesTimings.map(t => beautifyTimingNumber(t)),
    appliesCount: beautifyTimingNumber(rawTimings.appliesCount),
    timingsSum: beautifyTimingNumber(rawTimings.timingsSum),
    meanTiming: beautifyTimingNumber(rawTimings.meanTiming),
    standardDeviation: beautifyTimingNumber(rawTimings.standardDeviation)
  };
};

/**
 * Prints timing information if debugging mode is enabled.
 *
 * @param context ExtendedCss context.
 */
const printTimingInfo = context => {
  if (context.areTimingsPrinted) {
    return;
  }
  context.areTimingsPrinted = true;
  const timingsLogData = {};
  context.parsedRules.forEach(ruleData => {
    if (ruleData.timingStats) {
      const selector = ruleData.selector,
        style = ruleData.style,
        debug = ruleData.debug,
        matchedElements = ruleData.matchedElements;
      // style declaration for some rules is parsed to debug property and no style to apply
      // e.g. 'div:has(> a) { debug: true }'
      if (!style && !debug) {
        throw new Error(`Rule should have style declaration for selector: '${selector}'`);
      }
      const selectorData = {
        selectorParsed: selector,
        timings: beautifyTimings(ruleData.timingStats)
      };
      // `ruleData.style` may contain `remove` pseudo-property
      // and make logs look better
      if (style && style[REMOVE_PSEUDO_MARKER] === PSEUDO_PROPERTY_POSITIVE_VALUE) {
        selectorData.removed = true;
        // no matchedElements for such case as they are removed after ExtendedCss applied
      } else {
        selectorData.styleApplied = style || null;
        selectorData.matchedElements = matchedElements;
      }
      timingsLogData[selector] = selectorData;
    }
  });
  if (Object.keys(timingsLogData).length === 0) {
    return;
  }
  // add location.href to the message to distinguish frames
  extended_css_esm_logger.info('[ExtendedCss] Timings in milliseconds for %o:\n%o', window.location.href, timingsLogData);
};

/**
 * Finds affectedElement object for the specified DOM node.
 *
 * @param affElements Array of affected elements — context.affectedElements.
 * @param domNode DOM node.
 * @returns Found affectedElement or undefined.
 */
const findAffectedElement = (affElements, domNode) => {
  return affElements.find(affEl => affEl.node === domNode);
};

/**
 * Applies specified rule and returns list of elements affected.
 *
 * @param context ExtendedCss context.
 * @param ruleData Rule to apply.
 * @returns List of elements affected by the rule.
 */
const applyRule = (context, ruleData) => {
  // debugging mode can be enabled in two ways:
  // 1. for separate rules - by `{ debug: true; }`
  // 2. for all rules simultaneously by:
  //   - `{ debug: global; }` in any rule
  //   - positive `debug` property in ExtCssConfiguration
  const isDebuggingMode = !!ruleData.debug || context.debug;
  let startTime;
  if (isDebuggingMode) {
    startTime = performance.now();
  }
  const ast = ruleData.ast;
  const nodes = [];
  // selector can be successfully parser into ast with no error
  // but its applying by native Document.querySelectorAll() still may throw an error
  // e.g. 'div[..banner]'
  try {
    nodes.push(...selectElementsByAst(ast));
  } catch (e) {
    // log the error only in debug mode
    if (context.debug) {
      extended_css_esm_logger.error(extended_css_esm_getErrorMessage(e));
    }
  }
  nodes.forEach(node => {
    let affectedElement = findAffectedElement(context.affectedElements, node);
    if (affectedElement) {
      affectedElement.rules.push(ruleData);
    } else {
      // element is affected first time
      affectedElement = {
        node,
        // affected DOM node
        rules: [ruleData],
        // rule to be applied
        originalStyle: node.style.cssText,
        // original node style
        protectionObserver: null,
        // style attribute observer
        appliedRules: new WeakSet()
      };
      context.affectedElements.push(affectedElement);
    }

    // apply regular styles of the rule right away,
    // so selectors which depend on applied styles can match in the same pass;
    // actions are applied after all rules are queried
    applyRuleStyles(context, affectedElement);
  });
  if (isDebuggingMode && startTime) {
    const elapsedTimeMs = performance.now() - startTime;
    if (!ruleData.timingStats) {
      ruleData.timingStats = new TimingStats();
    }
    ruleData.timingStats.push(elapsedTimeMs);
  }
  return nodes;
};

/**
 * Applies filtering rules once.
 *
 * @param context ExtendedCss context.
 *
 * @returns True if the pass changed the DOM with removals.
 */
const applyRulesPass = context => {
  let hasDomMutations = false;
  const newSelectedElements = new Set();
  // reset rules collected during the previous pass:
  // only rules matching elements in the current pass should be applied,
  // otherwise actions could be replayed for elements which no longer match;
  // the callback-selected node is also reset and set again
  // if the callback is called during this pass
  context.affectedElements.forEach(affectedElement => {
    affectedElement.rules = [];
    affectedElement.callbackNode = undefined;
  });
  // some rules could make call - selector.querySelectorAll() temporarily to change node id attribute
  // this caused MutationObserver to call recursively
  // https://github.com/AdguardTeam/ExtendedCss/issues/81
  disconnectDocument(context);
  context.parsedRules.forEach(ruleData => {
    const nodes = applyRule(context, ruleData);
    nodes.forEach(node => newSelectedElements.add(node));
    // save matched elements to ruleData as linked to applied rule
    // only for debugging purposes
    if (ruleData.debug) {
      ruleData.matchedElements = nodes;
    }
  });
  // apply collected actions to each affected element once per pass:
  // regular styles and the sticky regular-styles flag
  // are handled by `applyRuleStyles()` while rules are collected
  context.affectedElements.forEach(affectedElement => {
    if (!newSelectedElements.has(affectedElement.node)) {
      return;
    }
    hasDomMutations = applyStyle(context, affectedElement) || hasDomMutations;
    // add style protection observer only for elements with regular styles
    if (!affectedElement.removed && affectedElement.hasRegularStyles && !affectedElement.protectionObserver) {
      affectedElement.protectionObserver = protectStyleAttribute(affectedElement.node, affectedElement.rules);
    }
  });

  // Now revert styles for elements which are no more affected
  let affLength = context.affectedElements.length;
  // do nothing if there is no elements to process
  while (affLength) {
    const affectedElement = context.affectedElements[affLength - 1];
    if (!affectedElement) {
      break;
    }
    if (!newSelectedElements.has(affectedElement.node)) {
      // revert styles only if the element had regular styles applied
      if (affectedElement.hasRegularStyles) {
        revertStyle(affectedElement);
      }
      context.affectedElements.splice(affLength - 1, 1);
    }
    affLength -= 1;
  }
  return hasDomMutations;
};

/**
 * Applies filtering rules.
 *
 * A pass can change the DOM: removed elements or attributes can make
 * other elements match, e.g. `#child:remove()` makes its parent match `:empty`.
 * The document observer is disconnected during the pass,
 * so such changes should be handled by re-running the pass.
 *
 * @param context ExtendedCss context.
 */
const applyRules = context => {
  while (applyRulesPass(context)) {
    // repeat while the pass changes the DOM
  }
  // After styles are applied we can start observe again
  observeDocument(context);
  printTimingInfo(context);
};

/**
 * Result of selector validation.
 */

/**
 * Interface for ExtendedCss constructor argument. Needed to create the instance of ExtendedCss.
 *
 * ExtendedCss configuration may contain:
 * - `styleSheet` — CSS stylesheet of rules to apply;
 * - `cssRules` — list of separated CSS rules instead of or additionally to the CSS stylesheet;
 * - `beforeStyleApplied` — the callback for matched elements;
 * - `debug` — flag for global logging which is useful for selectors debugging.
 *
 * > Both `styleSheet` and `cssRules` are optional but at least one of them should be set.
 *
 * > If both `styleSheet` and `cssRules` are set, both of them are to be applied.
 *
 * CSS stylesheet and list of CSS rules can contain not just extended selectors
 * but standard ones, and all of them will be applied by the lib.
 *
 * CSS comments and at-rules are not supported.
 */

/**
 * Main class of ExtendedCss lib.
 *
 * Parses css stylesheet with any selectors (passed to its argument as styleSheet),
 * and guarantee its applying as mutation observer is used to prevent the restyling of needed elements by other scripts.
 * This style protection is limited to 50 times to avoid infinite loop (MAX_STYLE_PROTECTION_COUNT).
 * Our own ThrottleWrapper is used for styles applying to avoid too often lib reactions on page mutations.
 *
 * Constructor creates the instance of class which should be run be `apply()` method to apply the rules,
 * and the applying can be stopped by `dispose()`.
 *
 * Can be used to select page elements by selector with `query()` method (similar to `Document.querySelectorAll()`),
 * which does not require instance creating.
 */
class ExtendedCss {
  /**
   * Creates new ExtendedCss.
   *
   * @param configuration ExtendedCss configuration.
   */
  constructor(configuration) {
    if (!configuration) {
      throw new Error('ExtendedCss configuration should be provided.');
    }
    this.applyRulesCallbackListener = this.applyRulesCallbackListener.bind(this);
    this.context = {
      beforeStyleApplied: configuration.beforeStyleApplied,
      debug: false,
      affectedElements: [],
      isDomObserved: false,
      removalsStatistic: {},
      actionRemovalsStatistic: new WeakMap(),
      parsedRules: [],
      scheduler: new ThrottleWrapper(this.applyRulesCallbackListener)
    };

    // TODO: throw an error instead of logging and handle it in related products.
    if (!isBrowserSupported()) {
      extended_css_esm_logger.error('Browser is not supported by ExtendedCss');
      return;
    }

    // at least 'styleSheet' or 'cssRules' should be provided
    if (!configuration.styleSheet && !configuration.cssRules) {
      throw new Error("ExtendedCss configuration should have 'styleSheet' or 'cssRules' defined.");
    }

    // 'styleSheet' and 'cssRules' are optional
    // and both can be provided at the same time
    // so both should be parsed and applied in such case
    if (configuration.styleSheet) {
      // stylesheet parsing can fail on some invalid selectors
      try {
        this.context.parsedRules.push(...parseStylesheet(configuration.styleSheet, extCssDocument));
      } catch (e) {
        // eslint-disable-next-line max-len
        throw new Error(`Pass the rules as configuration.cssRules since configuration.styleSheet cannot be parsed because of: '${extended_css_esm_getErrorMessage(e)}'`);
      }
    }
    if (configuration.cssRules) {
      this.context.parsedRules.push(...parseRules(configuration.cssRules, extCssDocument));
    }

    // true if set in configuration
    // or any rule in styleSheet has `debug: global`
    this.context.debug = configuration.debug || this.context.parsedRules.some(ruleData => {
      return ruleData.debug === DEBUG_PSEUDO_PROPERTY_GLOBAL_VALUE;
    });
    if (this.context.beforeStyleApplied && typeof this.context.beforeStyleApplied !== 'function') {
      // eslint-disable-next-line max-len
      throw new Error(`Invalid configuration. Type of 'beforeStyleApplied' should be a function, received: '${typeof this.context.beforeStyleApplied}'`);
    }
  }

  /**
   * Invokes {@link applyRules} function with current app context.
   * 
   * This method is bound to the class instance in the constructor because it is called
   * in {@link ThrottleWrapper} and on the DOMContentLoaded event.
   */
  applyRulesCallbackListener() {
    applyRules(this.context);
  }

  /**
   * Initializes ExtendedCss.
   *
   * Should be executed on page ASAP,
   * otherwise the :contains() pseudo-class may work incorrectly.
   */
  init() {
    /**
     * Native Node textContent getter must be intercepted as soon as possible,
     * and stored as it is needed for proper work of :contains() pseudo-class
     * because DOM Node prototype 'textContent' property may be mocked.
     *
     * @see {@link https://github.com/AdguardTeam/ExtendedCss/issues/127}
     */
    nativeTextContent.setGetter();
  }

  /**
   * Applies stylesheet rules on page.
   */
  apply() {
    applyRules(this.context);
    if (document.readyState !== 'complete') {
      document.addEventListener('DOMContentLoaded', this.applyRulesCallbackListener, false);
    }
  }

  /**
   * Disposes ExtendedCss and removes our styles from matched elements.
   */
  dispose() {
    disconnectDocument(this.context);
    this.context.affectedElements.forEach(el => {
      // action-only elements were not modified by us, so they should not be reverted
      if (el.hasRegularStyles) {
        revertStyle(el);
      }
    });
    // reset action removals statistic, so actions can be applied
    // by `apply()` again after the instance was disposed
    this.context.actionRemovalsStatistic = new WeakMap();
    document.removeEventListener('DOMContentLoaded', this.applyRulesCallbackListener, false);
  }

  /**
   * Exposed for testing purposes only.
   *
   * @returns Array of AffectedElement data objects.
   */
  getAffectedElements() {
    return this.context.affectedElements;
  }

  /**
   * Returns a list of the document's elements that match the specified selector.
   * Uses ExtCssDocument.querySelectorAll().
   *
   * @param selector Selector text.
   * @param noTiming If true, do not print the timings to the console (defaults to true).
   *
   * @throws An error if selector is not valid.
   * @returns A list of elements that match the selector.
   */
  static query(selector) {
    let noTiming = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
    if (typeof selector !== 'string') {
      throw new Error('Selector should be defined as a string.');
    }
    const start = performance.now();
    try {
      return extCssDocument.querySelectorAll(selector);
    } finally {
      const end = performance.now();
      if (!noTiming) {
        extended_css_esm_logger.info(`[ExtendedCss] Elapsed: ${Math.round((end - start) * 1000)} μs.`);
      }
    }
  }

  /**
   * Validates selector.
   *
   * @param inputSelector Selector text to validate.
   *
   * @returns Result of selector validation.
   */
  static validate(inputSelector) {
    try {
      // ExtendedCss in general supports action pseudo-classes in a selector
      // but ExtendedCss.query() does not support them as they should be parsed by stylesheet parser.
      // so for validation we have to handle selectors with action pseudo-classes in them
      const _parseActionSelector = parseActionSelector(inputSelector),
        selector = _parseActionSelector.selector;
      ExtendedCss.query(selector);
      return {
        ok: true,
        error: null
      };
    } catch (e) {
      // not valid input `selector` should be logged eventually
      const error = `Error: Invalid selector: '${inputSelector}' -- ${extended_css_esm_getErrorMessage(e)}`;
      return {
        ok: false,
        error
      };
    }
  }
}



;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+tswebextension@7.0.1_@adguard+re2-wasm@1.2.0_typescript@5.6.3/node_modules/@adguard/tswebextension/dist/common/constants.js
/**
 * Filter ID which is used for User rules.
 */
const USER_FILTER_ID = 0;
/**
 * Filter ID which is used for Allowlist.
 */
const ALLOWLIST_FILTER_ID = 100;
/**
 * Custom filters identifiers starts from this number.
 */
const CUSTOM_FILTERS_START_ID = 1000;
/**
 * Filter ID which is used for temporarily disabled rules (as trusted)
 * for the blocking page triggered by rules.
 */
const BLOCKING_TRUSTED_FILTER_ID = (/* unused pure expression or super */ null && (-10));
/**
 * Tab ID for background page.
 */
const BACKGROUND_TAB_ID = (/* unused pure expression or super */ null && (-1));
/**
 * Line feed character.
 */
const LF = '\n';
/**
 * Semicolon character.
 */
const constants_SEMICOLON = ';';
/**
 * Timeout used for deletion of request context data and frame context data from the storage.
 */
const FRAME_DELETION_TIMEOUT_MS = 3000;
/**
 * Document level frame id.
 */
const MAIN_FRAME_ID = 0;
/**
 * Value of the parent frame id if no parent frame exists.
 *
 * @see {@link https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/webRequest/onBeforeRequest#parentframeid}
 */
const NO_PARENT_FRAME_ID = (/* unused pure expression or super */ null && (-1));



;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+tswebextension@7.0.1_@adguard+re2-wasm@1.2.0_typescript@5.6.3/node_modules/@adguard/tswebextension/dist/common/css-hits-counter.js


/**
 * This storage is used to keep track of counted rules received from node elements.
 */
class HitsStorage {
    /**
     * Map storage.
     *
     * A `WeakMap` is used so that counted elements are not retained for the
     * page lifetime. This matters for the short-lived probes collected during
     * loading: their detached subtrees are not referenced anywhere else once
     * they are dropped, and the storage must not keep them alive.
     */
    map = new WeakMap();
    /**
     * Checks if element is counted.
     *
     * @param element Html element.
     * @param rule Rule text.
     *
     * @returns True if element is counted.
     */
    isCounted(element, rule) {
        return this.map.get(element) === rule;
    }
    /**
     * Stores rule-element info in storage.
     *
     * @param element Html element.
     * @param rule Rule text.
     */
    setCounted(element, rule) {
        this.map.set(element, rule);
    }
}

/**
 * Tags that must never be temporarily re-inserted into the page.
 *
 * Baits are hidden content elements, usually `div`/`span`, while re-inserting
 * resource-bearing or structural tags can re-run page side effects: re-issue
 * network requests, reload a frame, re-apply styles or fire custom element
 * callbacks. The counter re-inserts collected elements to read their computed
 * style, so such tags must not be collected.
 */
const IGNORED_TAGS = [
    'script', 'html', 'body', 'head', 'style', 'link', 'meta', 'title', 'base',
    'img', 'picture', 'source', 'iframe', 'frame', 'object', 'embed', 'video',
    'audio', 'track', 'svg',
];
/**
 * Tags inside a probe's subtree that make the whole subtree non-restorable.
 *
 * Re-inserting these re-runs page side effects: reloads a frame, re-issues a
 * network request or restarts media. The list is narrower than
 * {@link IGNORED_TAGS}: it must not include tags whose re-insertion is safe,
 * otherwise baits that contain them (e.g. an anti-adblock bait with a
 * `<script>` child, which is common) are never restored and their hits are
 * lost. In particular, an already executed `<script>` does not run again when
 * it is re-inserted, so scripts are allowed in subtrees.
 */
const RESTRICTED_SUBTREE_TAGS = [
    'link', 'img', 'picture', 'source', 'iframe', 'frame', 'object', 'embed',
    'video', 'audio', 'track',
    // SVG image elements load their `href`, so they are resource-bearing
    // even though the `svg` root itself is safe for inline graphics.
    'image',
];
/**
 * Checks whether an element with the given tag must not be re-inserted as
 * part of a probe's subtree.
 *
 * @param tagName Tag name to check.
 *
 * @returns True if the tag makes the subtree non-restorable.
 */
const isRestrictedSubtreeTag = (tagName) => {
    const normalizedTagName = tagName.toLowerCase();
    return RESTRICTED_SUBTREE_TAGS.includes(normalizedTagName)
        // Custom elements run their callbacks on re-insertion.
        || normalizedTagName.includes('-');
};
/**
 * Checks whether an element with the given tag must never be temporarily
 * re-inserted into the page.
 *
 * Custom elements are rejected as well: re-inserting them runs page-side
 * callbacks (`connectedCallback`/`disconnectedCallback`), which is exactly
 * the kind of page code the counter must not trigger.
 *
 * @param tagName Tag name to check.
 *
 * @returns True if the tag is ignored.
 */
const isIgnoredProbeTag = (tagName) => {
    const normalizedTagName = tagName.toLowerCase();
    return IGNORED_TAGS.includes(normalizedTagName)
        // Custom element names must contain a hyphen.
        || normalizedTagName.includes('-');
};
/**
 * Checks whether a detached element can be safely re-inserted into the page
 * to read its computed style.
 *
 * The check covers the element itself and its whole subtree: re-inserting a
 * `div` that contains an `iframe` reloads the frame, and a custom element
 * inside runs its callbacks, even though the root tag looks safe. Subtrees
 * are checked against {@link RESTRICTED_SUBTREE_TAGS}, which is narrower than
 * {@link IGNORED_TAGS} to keep baits with safe children, e.g. scripts,
 * restorable.
 *
 * @param element Detached element to check.
 * @param descendants Descendants of the element, if already collected by the
 * caller. When omitted, the subtree is queried.
 *
 * @returns True if the element can be re-inserted.
 */
const isProbeRestorable = (element, descendants) => {
    if (isIgnoredProbeTag(element.tagName)) {
        return false;
    }
    if (descendants) {
        for (let i = 0; i < descendants.length; i += 1) {
            if (isRestrictedSubtreeTag(descendants[i].tagName)) {
                return false;
            }
        }
        return true;
    }
    const children = element.querySelectorAll('*');
    for (let i = 0; i < children.length; i += 1) {
        if (isRestrictedSubtreeTag(children[i].tagName)) {
            return false;
        }
    }
    return true;
};
/**
 * Maximum number of probes kept in a pending queue.
 *
 * The collector uses it to bound its buffer, and the counter uses it to bound
 * the queue it accumulates while the collector keeps observing. When the
 * queue is full, new elements are dropped: baits are usually created by a
 * script in `<head>`, so the earliest probes are the valuable ones, while
 * later churn is more likely to be unrelated. Dropped elements are not marked
 * as seen, so if the page adds and removes one again after the queue is
 * drained, it can still be collected.
 */
const MAX_PENDING_PROBES = 500;
/**
 * Collects short-lived elements that are added and removed during the
 * document loading.
 *
 * The counter is created asynchronously, after the cosmetic data is received
 * from the background. Until then, the page can already create and remove
 * anti-adblock probe elements, for example from a script in `<head>`. This
 * collector observes the DOM from the very beginning of the document loading
 * and keeps references to such elements, so that the counter can check them
 * once it is initialized.
 *
 * The collector stays alive after the counter is initialized and keeps
 * feeding newly collected probes to it: a bait can be added during the
 * loading and removed later, after the counter already exists. It stops
 * observing when it is stopped explicitly or after
 * {@link MAX_OBSERVATION_TIME_MS}.
 */
class PendingProbesCollector {
    /**
     * Maximum observation time in milliseconds.
     *
     * If the counter is not initialized by then (e.g. the background is not
     * responding), the observer is disconnected and the collected elements
     * are dropped to avoid a permanent overhead and DOM retention on the
     * page.
     */
    static MAX_OBSERVATION_TIME_MS = 30000;
    /**
     * Mutation observer.
     */
    observer = null;
    /**
     * Collected elements.
     */
    pendingProbes = [];
    /**
     * Roots of subtrees appended during the observation window.
     *
     * Used to detect elements that were added and then removed later: the
     * removal callback checks the removed element and the node it was removed
     * from against this set, walking up the still-linked ancestor chain. Only
     * roots are stored, because a mutation record reports only the root of an
     * appended subtree.
     */
    addedElements = new WeakSet();
    /**
     * Deduplication set for collected elements.
     */
    collectedElements = new WeakSet();
    /**
     * Timer disconnecting the observer after {@link MAX_OBSERVATION_TIME_MS}.
     */
    observationTimeoutId = null;
    /**
     * Callback receiving newly collected probes.
     */
    onProbesCollected = null;
    /**
     * Callback invoked when observation ends without an explicit stop, e.g.
     * after {@link MAX_OBSERVATION_TIME_MS}.
     */
    onObservationEnded = null;
    /**
     * Whether the collector is currently observing the DOM.
     *
     * @returns True if the collector is observing.
     */
    get isObserving() {
        return this.observer !== null;
    }
    /**
     * Starts DOM observation.
     */
    start() {
        if (this.observer) {
            return;
        }
        const { MutationObserver } = window;
        if (!MutationObserver) {
            return;
        }
        this.observer = new MutationObserver((mutationRecords) => {
            this.collectProbes(mutationRecords, true);
        });
        // `document.documentElement` may not exist yet at `document_start`,
        // so observe the document itself.
        this.observer.observe(document, {
            childList: true,
            subtree: true,
        });
        this.observationTimeoutId = window.setTimeout(() => {
            this.observationTimeoutId = null;
            this.disconnect();
        }, PendingProbesCollector.MAX_OBSERVATION_TIME_MS);
    }
    /**
     * Sets a callback receiving newly collected probes.
     *
     * Probes collected before the callback is set are passed to it
     * immediately.
     *
     * @param callback Callback receiving collected probes, or `null` to
     * unsubscribe.
     */
    setOnProbesCollected(callback) {
        this.onProbesCollected = callback;
        if (callback) {
            // Flush undelivered records and the buffer, so probes collected
            // before the subscription are not lost.
            const probes = this.takePendingProbes();
            if (probes.length > 0) {
                callback(probes);
            }
        }
    }
    /**
     * Sets a callback invoked when observation ends without an explicit stop.
     *
     * The counter uses it to start its own observer if the collector times
     * out while the document is still loading.
     *
     * @param callback Callback invoked when observation ends, or `null` to
     * unsubscribe.
     */
    setOnObservationEnded(callback) {
        this.onObservationEnded = callback;
    }
    /**
     * Returns collected probes and keeps observing.
     *
     * Mutation records that have not been delivered yet are processed before
     * returning, so no collected element is lost at the handover to the
     * counter.
     *
     * @returns Probes collected since the previous take.
     */
    takePendingProbes() {
        this.flushQueuedRecords();
        const probes = this.pendingProbes;
        this.pendingProbes = [];
        return probes;
    }
    /**
     * Stops observation and drops collected elements.
     */
    stop() {
        this.onProbesCollected = null;
        // An explicit stop must not make the counter start its observer.
        this.onObservationEnded = null;
        this.disconnect();
        this.pendingProbes = [];
    }
    /**
     * Disconnects the observer, cancels the observation timeout and drops
     * collected elements.
     */
    disconnect() {
        if (this.observer) {
            this.observer.disconnect();
            this.observer = null;
        }
        if (this.observationTimeoutId !== null) {
            window.clearTimeout(this.observationTimeoutId);
            this.observationTimeoutId = null;
        }
        // Do not retain detached DOM subtrees once observation ends: the
        // probes collected so far are stale and would otherwise live for the
        // page lifetime.
        this.pendingProbes = [];
        // Notify the subscriber, e.g. so the counter can start its own
        // observer if the collector times out while the document is still
        // loading. An explicit stop() clears the callback first.
        this.onObservationEnded?.();
    }
    /**
     * Processes mutation records that are queued but not delivered yet.
     */
    flushQueuedRecords() {
        if (this.observer) {
            this.collectProbes(this.observer.takeRecords(), false);
        }
    }
    /**
     * Collects detached elements from mutation records.
     *
     * @param mutationRecords Mutation records delivered by the observer.
     * @param notify Flag telling whether the subscriber should be notified
     * about newly collected probes.
     */
    collectProbes(mutationRecords, notify) {
        let hasNewProbes = false;
        for (let i = 0; i < mutationRecords.length; i += 1) {
            const mutationRecord = mutationRecords[i];
            const { addedNodes } = mutationRecord;
            for (let j = 0; j < addedNodes.length; j += 1) {
                const node = addedNodes[j];
                if (node.nodeType !== node.ELEMENT_NODE) {
                    continue;
                }
                const element = node;
                // The element was added and already removed before the
                // observer callback has been invoked.
                if (!element.parentNode) {
                    if (PendingProbesCollector.isCollectableNode(element)) {
                        // Remember the element even if the queue is full, so
                        // it can be collected when it is removed after the
                        // queue has been drained.
                        this.addedElements.add(element);
                        hasNewProbes = this.collectProbe(element, mutationRecord) || hasNewProbes;
                    }
                    continue;
                }
                // Remember only the appended root: a mutation record reports
                // just the root of an appended subtree. Descendants are
                // resolved lazily on removal by walking up from the removal
                // target, so no subtree scan is needed here.
                this.addedElements.add(element);
            }
            const { removedNodes } = mutationRecord;
            for (let j = 0; j < removedNodes.length; j += 1) {
                const node = removedNodes[j];
                if (!PendingProbesCollector.isCollectableNode(node)) {
                    continue;
                }
                // The element was added during the observation window and
                // removed later.
                if (!node.parentNode
                    && this.wasAddedDuringObservation(node, mutationRecord.target)) {
                    hasNewProbes = this.collectProbe(node, mutationRecord) || hasNewProbes;
                }
            }
        }
        if (!hasNewProbes || !notify || !this.onProbesCollected) {
            return;
        }
        const probes = this.pendingProbes;
        this.pendingProbes = [];
        this.onProbesCollected(probes);
    }
    /**
     * Checks whether an element was added during the observation window.
     *
     * A mutation record reports only the root of an appended subtree, so a
     * removed descendant has no addition record of its own. It was still
     * added during the window if it was reported as added itself, or if the
     * node it was removed from (or one of its ancestors) was appended during
     * the window: in that case the element came with that subtree, or was
     * added later and has its own addition record.
     *
     * The ancestor chain is still linked for a detached subtree, so this also
     * covers an element removed in the same task its container was appended
     * in, before the observer callback runs.
     *
     * @param node Removed element.
     * @param target Node the element was removed from.
     *
     * @returns True if the element was added during the observation.
     */
    wasAddedDuringObservation(node, target) {
        if (this.addedElements.has(node)) {
            return true;
        }
        let current = target;
        while (current) {
            if (current instanceof Element && this.addedElements.has(current)) {
                return true;
            }
            current = current.parentNode;
        }
        return false;
    }
    /**
     * Stores a detached element.
     *
     * The element is not stored if it cannot be safely re-inserted (see
     * {@link isProbeRestorable}) or if the queue is full.
     *
     * @param element Detached element.
     * @param mutationRecord Mutation record the element was found in.
     *
     * @returns True if the element was stored.
     */
    collectProbe(element, mutationRecord) {
        if (this.collectedElements.has(element)) {
            return false;
        }
        if (this.pendingProbes.length >= MAX_PENDING_PROBES) {
            // Keep the earliest probes. The element is not marked as seen, so
            // if the page adds and removes it again after the queue is
            // drained, it can still be collected. Check the cap before
            // scanning the subtree: when the queue is full, the scan would be
            // wasted work for an element that is dropped anyway.
            return false;
        }
        if (!isProbeRestorable(element)) {
            // Mark the element as seen to avoid rescanning its subtree on
            // every repeated mutation record.
            this.collectedElements.add(element);
            return false;
        }
        this.collectedElements.add(element);
        this.pendingProbes.push({
            element,
            target: mutationRecord.target,
            previousSibling: mutationRecord.previousSibling,
            nextSibling: mutationRecord.nextSibling,
        });
        return true;
    }
    /**
     * Checks if the node should be collected.
     *
     * @param node Node to check.
     *
     * @returns True if the node is an element with a re-insertable tag.
     */
    static isCollectableNode(node) {
        // `node.ELEMENT_NODE` is used instead of the `Element` global, so the
        // check does not depend on the global scope availability.
        return node.nodeType === node.ELEMENT_NODE
            && !isIgnoredProbeTag(node.tagName);
    }
}

/**
 * Utils class.
 */
class ElementUtils {
    /**
     * Serialize HTML element.
     *
     * @param element Element to serialize.
     *
     * @returns String representation of the element.
     */
    static elementToString(element) {
        const s = [];
        s.push('<');
        s.push(element.localName);
        const { attributes } = element;
        for (let i = 0; i < attributes.length; i += 1) {
            const attr = attributes[i];
            s.push(' ');
            s.push(attr.name);
            s.push('="');
            const value = attr.value === null ? '' : attr.value.replace(/"/g, '\\"');
            s.push(value);
            s.push('"');
        }
        s.push('>');
        return s.join('');
    }
    /**
     * Appends node children to the array.
     *
     * @param node Element whose children we would like to add.
     * @param arrayWithNodes Array where we add children.
     */
    static appendChildren(node, arrayWithNodes) {
        const children = node.querySelectorAll('*');
        if (children && children.length > 0) {
            for (let i = 0; i < children.length; i += 1) {
                arrayWithNodes.push(children[i]);
            }
        }
    }
    /**
     * Adds elements into array if they are not in the array yet.
     *
     * @param targetArray Array where we add elements.
     * @param sourceArray Array with elements.
     */
    static addUnique(targetArray, sourceArray) {
        if (sourceArray.length > 0) {
            for (let i = 0; i < sourceArray.length; i += 1) {
                const sourceElement = sourceArray[i];
                if (targetArray.indexOf(sourceElement) === -1) {
                    targetArray.push(sourceElement);
                }
            }
        }
    }
    /**
     * Removes all elements in array.
     *
     * @param elements Array with elements.
     */
    static removeElements(elements) {
        for (let i = 0; i < elements.length; i += 1) {
            const element = elements[i];
            element.remove();
        }
    }
    /**
     * Parses hits info from style content.
     *
     * @param content Style content.
     * @param attributeMarker Attribute marker.
     *
     * @returns Rule info or null.
     */
    static parseInfo(content, attributeMarker) {
        if (!content || content.indexOf(attributeMarker) < 0) {
            return null;
        }
        let filterIdAndRuleText = decodeURIComponent(content);
        // 'content' value may include open and close quotes.
        filterIdAndRuleText = ElementUtils.removeQuotes(filterIdAndRuleText);
        // Remove prefix
        filterIdAndRuleText = filterIdAndRuleText.substring(attributeMarker.length);
        // Attribute 'content' in css looks like: {content: 'adguard{filterId};{ruleIndex}'}
        const index = filterIdAndRuleText.indexOf(';');
        if (index < 0) {
            return null;
        }
        const filterId = Number.parseInt(filterIdAndRuleText.slice(0, index), 10);
        if (Number.isNaN(filterId)) {
            return null;
        }
        const ruleIndex = Number.parseInt(filterIdAndRuleText.slice(index + 1), 10);
        if (Number.isNaN(ruleIndex)) {
            return null;
        }
        return { filterId, ruleIndex };
    }
    /**
     * Parses hits info from style content.
     *
     * @param content Style.
     * @param attributeMarker Attribute marker.
     *
     * @returns Rule info or null.
     */
    static parseExtendedStyleInfo(content, attributeMarker) {
        const important = '!important';
        const indexOfImportant = content.lastIndexOf(important);
        if (indexOfImportant === -1) {
            return ElementUtils.parseInfo(content, attributeMarker);
        }
        const contentWithoutImportant = content.substring(0, indexOfImportant).trim();
        return ElementUtils.parseInfo(contentWithoutImportant, attributeMarker);
    }
    /**
     * Unquotes specified value.
     *
     * @param value Value to unquote.
     *
     * @returns Unquoted value.
     */
    static removeQuotes(value) {
        if (value.length > 1
            && ((value[0] === '"' && value[value.length - 1] === '"')
                || (value[0] === '\'' && value[value.length - 1] === '\''))) {
            // Remove double-quotes or single-quotes
            return value.substring(1, value.length - 1);
        }
        return value;
    }
}

const DEFAULT_ELEMENT_TO_STRING = true;
/**
 * Collects CSS hits. Markers are injected by the cosmetic emitter as the
 * `--adguard-hit` custom property (see `CosmeticApiCommon`); the reader
 * probes each element's computed style and reports matches via the
 * callback passed to the constructor.
 */
class CssHitsCounter {
    /**
     * We split CSS hits counting into smaller batches of elements and schedule them one by one using setTimeout.
     */
    static COUNT_CSS_HITS_BATCH_DELAY = 5;
    /**
     * Size of small batches of elements we count.
     */
    static CSS_HITS_BATCH_SIZE = 25;
    /**
     * Marker value prefix; encodes as `adguard<id>%3B<idx>`.
     */
    static MARKER_PREFIX = 'adguard';
    /**
     * Custom property carrying the marker (see `CosmeticApiCommon`).
     */
    static MARKER_PROPERTY_NAME = '--adguard-hit';
    /**
     * We delay countAllCssHits function if it was called too frequently from mutationObserver.
     */
    static COUNT_ALL_CSS_HITS_TIMEOUT_MS = 500;
    /**
     * Delay between attempts to count pending probes, in milliseconds.
     *
     * The marker styles may be injected slightly later than the cosmetic
     * data is received, so a probe that does not match any rule yet is
     * reinserted and checked again.
     */
    static PENDING_PROBES_RETRY_DELAY_MS = 100;
    /**
     * Number of attempts to count pending probes.
     */
    static PENDING_PROBES_MAX_ATTEMPTS = 5;
    /**
     * Callback function for counted css hits handling.
     */
    onCssHitsFoundCallback;
    /**
     * Hits storage.
     */
    hitsStorage = new HitsStorage();
    /**
     * Mutation observer.
     */
    observer = null;
    /**
     * Counting on process flag.
     */
    countIsWorking = false;
    /**
     * Probes collected before and after the counter initialization.
     */
    pendingProbes = [];
    /**
     * Collector feeding the counter with short-lived elements, if any.
     */
    pendingProbesCollector = null;
    /**
     * Elements that were already temporarily re-inserted by the mutation
     * observer.
     */
    probedElements = new WeakSet();
    /**
     * Elements that the mutation observer re-inserted and successfully
     * counted.
     *
     * The collector and the counter's own mutation observer can both report
     * the same element, so {@link countPendingProbes} must not re-insert it
     * again. Elements that did not match any rule are not added here: they
     * are still retried by the pending probes pass, since the marker styles
     * may be applied later.
     */
    countedProbes = new WeakSet();
    /**
     * Elements intentionally removed by ExtendedCss.
     *
     * ExtendedCss reports hits for them synchronously before removal, so the
     * counter must not restore these detached elements to the DOM.
     */
    extendedCssRemovedElements = new WeakSet();
    /**
     * Number of counting attempts already performed for each pending probe.
     *
     * Attempts are tracked per probe, so probes delivered later get their own
     * retry budget instead of sharing the in-flight one.
     */
    pendingProbeAttempts = new WeakMap();
    /**
     * Whether a native marker hit has already been observed.
     *
     * The marker styles are injected as a whole, so once any element produced
     * a hit, a probe that did not match on its first attempt will not match on
     * a retry either. Retrying it would only keep detached subtrees alive and
     * delay the probes that follow in the queue.
     */
    markerStylesApplied = false;
    /**
     * Timer for the next attempt to count {@link pendingProbes}.
     */
    pendingProbesTimeoutId = null;
    /**
     * Timer for the debounced full CSS hits scan.
     */
    countAllCssHitsTimeoutId = null;
    /**
     * Lifecycle cleanup flag. Delayed callbacks check it before doing work.
     */
    stopped = false;
    /**
     * Flag determining if we should convert elements to string, or not.
     *
     * @private
     */
    elementToString = DEFAULT_ELEMENT_TO_STRING;
    /**
     * Bound readystatechange listener, stored so stop() can remove the same
     * function reference.
     */
    boundStartCounter = this.startCounter.bind(this);
    /**
     * Attaches the mutation observer while the document is still loading when
     * no pending probes collector is provided, so elements added and removed
     * before the document becomes interactive are not missed. With a
     * collector, the collector already covers that window, so the counter's
     * own observer starts at `interactive`, together with the full DOM scan.
     *
     * @param callback Which receives {@link ICountedElement} and handles counted css hits.
     * @param options CssHitsCounter options.
     */
    constructor(callback, options) {
        if (options) {
            const { elementToString, pendingProbes, pendingProbesCollector } = options;
            if (elementToString !== undefined) {
                this.elementToString = elementToString;
            }
            if (pendingProbes && pendingProbes.length > 0) {
                // Copy the array: the counter adds probes to its own queue,
                // so the caller's array must not change.
                this.enqueuePendingProbes(pendingProbes);
            }
            if (pendingProbesCollector) {
                this.pendingProbesCollector = pendingProbesCollector;
                const collectedProbes = pendingProbesCollector.takePendingProbes();
                if (collectedProbes.length > 0) {
                    this.enqueuePendingProbes(collectedProbes);
                }
                pendingProbesCollector.setOnProbesCollected((probes) => {
                    this.addPendingProbes(probes);
                });
                pendingProbesCollector.setOnObservationEnded(() => {
                    // The collector stopped before the document became
                    // interactive: it no longer covers the loading window, so
                    // the counter must start its own observer.
                    if (!this.stopped && !this.observer) {
                        this.countCssHitsForMutations();
                    }
                });
            }
        }
        this.onCssHitsFoundCallback = callback;
        if (document.readyState === 'complete'
            || document.readyState === 'interactive') {
            this.countCssHits();
        }
        else {
            // Start observing immediately during the document loading when
            // no active collector covers that window: waiting for
            // `readystatechange` misses elements that are added and removed
            // before the document becomes interactive. With an active
            // collector, the counter's own observer starts at `interactive`
            // to avoid walking every mutation twice while the page is
            // parsing.
            if (!this.pendingProbesCollector?.isObserving) {
                this.countCssHitsForMutations();
            }
            document.addEventListener('readystatechange', this.boundStartCounter);
        }
        // Probes collected before the counter initialization are counted
        // after the observer is attached, so no mutation can slip between
        // the two.
        this.countPendingProbes();
    }
    /**
     * Stops css hits counting process.
     */
    stop() {
        this.stopped = true;
        this.onCssHitsFoundCallback = () => { };
        if (this.observer) {
            this.observer.disconnect();
        }
        if (this.pendingProbesTimeoutId !== null) {
            window.clearTimeout(this.pendingProbesTimeoutId);
            this.pendingProbesTimeoutId = null;
        }
        if (this.countAllCssHitsTimeoutId !== null) {
            window.clearTimeout(this.countAllCssHitsTimeoutId);
            this.countAllCssHitsTimeoutId = null;
        }
        if (this.pendingProbesCollector) {
            this.pendingProbesCollector.stop();
            this.pendingProbesCollector = null;
        }
        this.pendingProbes = [];
        document.removeEventListener('readystatechange', this.boundStartCounter);
    }
    /**
     * Adds probes to the pending queue, keeping at most
     * {@link MAX_PENDING_PROBES} probes.
     *
     * The earliest probes are kept: baits are usually created by a script in
     * `<head>`, while later churn is more likely to be unrelated.
     *
     * @param probes Probes to enqueue.
     */
    enqueuePendingProbes(probes) {
        const available = MAX_PENDING_PROBES - this.pendingProbes.length;
        if (available <= 0) {
            return;
        }
        if (probes.length > available) {
            this.pendingProbes.push(...probes.slice(0, available));
            return;
        }
        this.pendingProbes.push(...probes);
    }
    /**
     * Adds probes collected after the counter initialization.
     *
     * The probes are counted by the regular probe processing pass. If a pass
     * or a retry is already scheduled, the new probes are picked up by it and
     * get their own retry budget.
     *
     * @param probes Probes collected by {@link PendingProbesCollector}.
     */
    addPendingProbes(probes) {
        if (this.stopped || probes.length === 0) {
            return;
        }
        this.enqueuePendingProbes(probes);
        if (this.pendingProbesTimeoutId !== null) {
            // A pass or a retry is already scheduled and will pick the new
            // probes up.
            return;
        }
        this.pendingProbesTimeoutId = window.setTimeout(() => {
            this.pendingProbesTimeoutId = null;
            this.countPendingProbes();
        }, 0);
    }
    /**
     * ExtendedCss callback: reads the legacy `content:` marker from the
     * parsed rule object, reports a hit, and clears the marker so it
     * never reaches the DOM.
     *
     * The ExtendedCss path was *not* affected by AG-265 — its rules are
     * applied imperatively, never inserted as a stylesheet, so the
     * `content:` marker cannot leak. Reading from the parsed object is
     * required because ExtendedCss invokes this callback **before**
     * `setStyleToElement` writes anything to the node, so computed
     * style is not yet populated. After parsing, the marker declaration
     * is blanked to prevent any visible flash on rules that do not also
     * hide the element.
     *
     * @param affectedEl Affected element from ExtendedCss.
     *
     * @returns The same affected element, unchanged.
     */
    countAffectedByExtendedCss(affectedEl) {
        if (affectedEl && affectedEl.rules && affectedEl.rules.length > 0) {
            const result = [];
            for (const rule of affectedEl.rules) {
                if (rule.style?.remove === 'true') {
                    this.extendedCssRemovedElements.add(affectedEl.node);
                }
                if (rule.style && rule.style.content) {
                    const ruleInfo = ElementUtils.parseExtendedStyleInfo(rule.style.content, CssHitsCounter.MARKER_PREFIX);
                    if (ruleInfo === null) {
                        continue;
                    }
                    const { filterId, ruleIndex } = ruleInfo;
                    if (filterId !== undefined && ruleIndex !== undefined) {
                        const element = this.elementToString
                            ? ElementUtils.elementToString(affectedEl.node)
                            : affectedEl.node;
                        result.push({
                            filterId,
                            ruleIndex,
                            element,
                        });
                        // clear style content to avoid duplicate counting and
                        // to prevent the marker text from being painted.
                        rule.style.content = '';
                    }
                }
            }
            this.onCssHitsFoundCallback(result);
        }
        return affectedEl;
    }
    /**
     * Starts counting process.
     */
    startCounter() {
        if (this.stopped) {
            return;
        }
        if (document.readyState === 'interactive'
            || document.readyState === 'complete') {
            // Without a collector the observer is already attached during
            // loading. With a collector it starts now, together with the full
            // scan after the document has been parsed.
            if (!this.observer) {
                this.countCssHitsForMutations();
            }
            this.countAllCssHits();
            document.removeEventListener('readystatechange', this.boundStartCounter);
        }
    }
    /**
     * Counts css hits.
     */
    countCssHits() {
        // Start observing first. Otherwise an element added between the
        // initial querySelectorAll snapshot and the observer setup can be
        // missed forever if it is removed before the next full scan.
        this.countCssHitsForMutations();
        this.countAllCssHits();
    }
    /**
     * Counts css hits for already affected elements.
     */
    countAllCssHits() {
        if (this.stopped) {
            return;
        }
        // The full scan is performed only after the document has been parsed:
        // the debounced mutation callback can fire while the document is
        // still loading.
        if (document.readyState !== 'interactive'
            && document.readyState !== 'complete') {
            return;
        }
        // we don't start counting again all css hits till previous count process wasn't finished
        if (this.countIsWorking) {
            return;
        }
        this.countIsWorking = true;
        const elements = document.querySelectorAll('*');
        this.countCssHitsBatch(elements, 0, CssHitsCounter.CSS_HITS_BATCH_SIZE, CssHitsCounter.CSS_HITS_BATCH_SIZE, [], (result) => {
            if (result.length > 0) {
                this.onCssHitsFoundCallback(result);
            }
            this.countIsWorking = false;
        });
    }
    /**
     * Main calculation function.
     * 1. Selects sub collection from elements.
     * 2. For each element from sub collection: retrieves calculated css 'content'
     * attribute and if it contains 'adguard'
     * marker then retrieves rule text and filter identifier.
     * 3. Starts next task with some delay.
     *
     * @param elements Collection of all elements.
     * @param start Start of batch.
     * @param end End of batch.
     * @param step Size of batch.
     * @param result Collection for save result.
     * @param callback Finish callback.
     */
    // eslint-disable-next-line max-len
    countCssHitsBatch(elements, start, end, step, result, callback) {
        if (this.stopped) {
            return;
        }
        const length = Math.min(end, elements.length);
        result = result.concat(this.countCssHitsForElements(elements, start, length));
        if (length === elements.length) {
            callback(result);
            return;
        }
        start = end;
        end += step;
        // Start next task with some delay
        window.setTimeout(() => {
            this.countCssHitsBatch(elements, start, end, step, result, callback);
        }, CssHitsCounter.COUNT_CSS_HITS_BATCH_DELAY);
    }
    /**
     * Counts css hits for array of elements.
     *
     * @param elements Array of elements.
     * @param start Start of batch.
     * @param length Length of batch.
     * @param countedElements Optional set receiving elements that produced a hit.
     *
     * @returns Data with information about rule and element.
     */
    countCssHitsForElements(elements, start, length, countedElements) {
        start = start || 0;
        length = length || elements.length;
        const result = [];
        for (let i = start; i < length; i += 1) {
            const element = elements[i];
            const cssHitData = CssHitsCounter.getCssHitData(element);
            if (!cssHitData) {
                continue;
            }
            // A marker proves that the injected styles are already applied,
            // regardless of whether this element was counted before.
            this.markerStylesApplied = true;
            const { filterId, ruleIndex } = cssHitData;
            const ruleAndFilterString = filterId + constants_SEMICOLON + ruleIndex;
            if (this.hitsStorage.isCounted(element, ruleAndFilterString)) {
                countedElements?.add(element);
                continue;
            }
            this.hitsStorage.setCounted(element, ruleAndFilterString);
            countedElements?.add(element);
            result.push({
                filterId,
                ruleIndex,
                element: this.elementToString ? ElementUtils.elementToString(element) : element,
            });
        }
        return result;
    }
    /**
     * Counts css hits for mutations.
     */
    countCssHitsForMutations() {
        // eslint-disable-next-line prefer-destructuring
        const MutationObserver = window.MutationObserver;
        if (!MutationObserver) {
            return;
        }
        if (this.observer) {
            this.observer.disconnect();
        }
        // A new observer replaces the previous one, so a debounce armed by
        // the previous observer must not run a full scan anymore.
        if (this.countAllCssHitsTimeoutId !== null) {
            window.clearTimeout(this.countAllCssHitsTimeoutId);
            this.countAllCssHitsTimeoutId = null;
        }
        this.observer = new MutationObserver(((mutationRecords) => {
            // Collect probe elements, count them, then remove from their targets
            const probeElements = [];
            const childrenOfProbeElements = [];
            const potentialProbeElements = [];
            mutationRecords.forEach((mutationRecord) => {
                if (mutationRecord.addedNodes.length === 0) {
                    return;
                }
                for (let i = 0; i < mutationRecord.addedNodes.length; i += 1) {
                    const node = mutationRecord.addedNodes[i];
                    if (!(node instanceof Element)) {
                        continue;
                    }
                    const { target } = mutationRecord;
                    if (!node.parentNode && target) {
                        // If this node has been appended to the DOM and counted once, do not add
                        // it again.
                        if (this.probedElements.has(node)) {
                            continue;
                        }
                        // Elements removed by ExtendedCss are reported by it,
                        // so they must not be put back into the page.
                        if (this.extendedCssRemovedElements.has(node)) {
                            continue;
                        }
                        // CSS rules could be applied to the nodes inside probe element
                        // that's why we get all child elements of added node
                        const childrenOfProbe = [];
                        ElementUtils.appendChildren(node, childrenOfProbe);
                        // Never re-insert resource-bearing or custom element
                        // subtrees: it re-runs page side effects.
                        if (!isProbeRestorable(node, childrenOfProbe)) {
                            continue;
                        }
                        const restoreTarget = CssHitsCounter.getProbeRestoreTarget(target);
                        // Without a connected ancestor the probe cannot be
                        // measured in its original cascade context.
                        if (!restoreTarget) {
                            continue;
                        }
                        // Most likely this is a "probe" element that was added and then
                        // immediately removed from DOM.
                        // We re-add it and check if any rule matched it
                        probeElements.push(node);
                        // To ensure that this "probe" node has only been added once to the DOM,
                        // we add it to the weak set.
                        this.probedElements.add(node);
                        childrenOfProbeElements.push(...childrenOfProbe);
                        if (this.observer) {
                            this.observer.disconnect();
                        }
                        CssHitsCounter.insertProbe(node, restoreTarget, mutationRecord.previousSibling, mutationRecord.nextSibling);
                    }
                    else if (node.parentNode && target) {
                        // Sometimes probe elements are appended to the DOM
                        potentialProbeElements.push(node);
                        ElementUtils.appendChildren(node, potentialProbeElements);
                    }
                }
            });
            // If the list of potential probe elements is relatively small,
            // we can count CSS hits immediately
            if (potentialProbeElements.length > 0
                && potentialProbeElements.length <= CssHitsCounter.CSS_HITS_BATCH_SIZE) {
                const result = this.countCssHitsForElements(potentialProbeElements, 0, null);
                if (result.length > 0) {
                    this.onCssHitsFoundCallback(result);
                }
            }
            const allProbeElements = [];
            ElementUtils.addUnique(allProbeElements, childrenOfProbeElements);
            ElementUtils.addUnique(allProbeElements, probeElements);
            if (allProbeElements.length > 0) {
                const countedElements = new Set();
                const result = this.countCssHitsForElements(allProbeElements, 0, null, countedElements);
                if (result.length > 0) {
                    this.onCssHitsFoundCallback(result);
                }
                // Remember which probes matched, so the collector does not
                // re-insert them again. A hit on a descendant also proves
                // that the probe was checked, so walk up from every counted
                // element and mark all probe roots that contain it.
                const probeRoots = new Set(probeElements);
                countedElements.forEach((element) => {
                    let node = element;
                    while (node) {
                        if (node instanceof Element && probeRoots.has(node)) {
                            this.countedProbes.add(node);
                        }
                        node = node.parentNode;
                    }
                });
                /**
                 * Don't remove child elements of probe elements
                 * https://github.com/AdguardTeam/AdguardBrowserExtension/issues/1096.
                 */
                ElementUtils.removeElements(probeElements);
                this.startObserver();
            }
            // debounce counting all css hits when mutation record fires
            if (this.countAllCssHitsTimeoutId !== null) {
                window.clearTimeout(this.countAllCssHitsTimeoutId);
            }
            this.countAllCssHitsTimeoutId = window.setTimeout(() => {
                this.countAllCssHitsTimeoutId = null;
                this.countAllCssHits();
            }, CssHitsCounter.COUNT_ALL_CSS_HITS_TIMEOUT_MS);
        }));
        this.startObserver();
    }
    /**
     * Orders pending probes for processing.
     *
     * A probe whose target is another probe's element (or is inside it) must
     * be processed after that probe: the ancestor has to be restored to the
     * document before the descendant can be measured in its original parent.
     * Dependent probes are grouped and kept in the same chunk, because
     * restored probes are removed at the end of a chunk.
     *
     * @param probes Pending probes in removal order.
     *
     * @returns Chunks of probes in processing order.
     */
    static orderPendingProbes(probes) {
        const probeByElement = new Map();
        probes.forEach((probe) => {
            probeByElement.set(probe.element, probe);
        });
        const dependencyByProbe = new Map();
        const getDependency = (probe) => {
            if (dependencyByProbe.has(probe)) {
                return dependencyByProbe.get(probe) ?? null;
            }
            let dependency = null;
            let current = probe.target;
            while (current) {
                if (current instanceof Element) {
                    const candidate = probeByElement.get(current);
                    if (candidate && candidate !== probe) {
                        dependency = candidate;
                        break;
                    }
                }
                current = current.parentNode;
            }
            dependencyByProbe.set(probe, dependency);
            return dependency;
        };
        const rootByProbe = new Map();
        const getRoot = (probe, visiting) => {
            const cached = rootByProbe.get(probe);
            if (cached) {
                return cached;
            }
            if (visiting.has(probe)) {
                return probe;
            }
            visiting.add(probe);
            const dependency = getDependency(probe);
            const root = dependency ? getRoot(dependency, visiting) : probe;
            visiting.delete(probe);
            rootByProbe.set(probe, root);
            return root;
        };
        const depthByProbe = new Map();
        const getDepth = (probe, visiting) => {
            const cached = depthByProbe.get(probe);
            if (cached !== undefined) {
                return cached;
            }
            if (visiting.has(probe)) {
                return 0;
            }
            visiting.add(probe);
            const dependency = getDependency(probe);
            const depth = dependency ? getDepth(dependency, visiting) + 1 : 0;
            visiting.delete(probe);
            depthByProbe.set(probe, depth);
            return depth;
        };
        const indexByProbe = new Map();
        probes.forEach((probe, index) => {
            indexByProbe.set(probe, index);
            getDepth(probe, new Set());
        });
        const groups = new Map();
        const groupOrder = [];
        probes.forEach((probe) => {
            const root = getRoot(probe, new Set());
            let group = groups.get(root);
            if (!group) {
                group = [];
                groups.set(root, group);
                groupOrder.push(root);
            }
            group.push(probe);
        });
        // Process dependent groups first, so a large batch of independent
        // probes cannot delay a container/bait pair indefinitely.
        const orderedGroups = [
            ...groupOrder.filter((root) => (groups.get(root)?.length ?? 0) > 1),
            ...groupOrder.filter((root) => (groups.get(root)?.length ?? 0) <= 1),
        ];
        const getAncestors = (probe) => {
            const ancestors = [];
            const seen = new Set();
            let dependency = getDependency(probe);
            while (dependency && !seen.has(dependency)) {
                ancestors.unshift(dependency);
                seen.add(dependency);
                dependency = getDependency(dependency);
            }
            return ancestors;
        };
        /**
         * Splits a dependent group into chunks that fit the batch size when
         * the group has independent branches.
         *
         * The group is sorted by depth, so each chunk keeps the ancestors of
         * its probes. Ancestors processed in a previous chunk are added again
         * to the next chunk, because restored probes are removed at the end
         * of a chunk. A dependency chain deeper than the batch size is kept
         * as one chunk, because it cannot be measured in smaller independent
         * pieces.
         *
         * @param group Dependent probes sorted by depth.
         *
         * @returns Chunks of probes.
         */
        const splitDependentGroup = (group) => {
            const groupChunks = [];
            let groupChunk = [];
            let groupChunkSet = new Set();
            group.forEach((probe) => {
                const ancestors = getAncestors(probe);
                let missingAncestors = ancestors.filter((ancestor) => !groupChunkSet.has(ancestor));
                if (groupChunk.length > 0
                    && groupChunk.length + missingAncestors.length + 1
                        > CssHitsCounter.CSS_HITS_BATCH_SIZE) {
                    groupChunks.push(groupChunk);
                    groupChunk = [];
                    groupChunkSet = new Set();
                    missingAncestors = ancestors;
                }
                missingAncestors.forEach((ancestor) => {
                    groupChunk.push(ancestor);
                    groupChunkSet.add(ancestor);
                });
                groupChunk.push(probe);
                groupChunkSet.add(probe);
            });
            if (groupChunk.length > 0) {
                groupChunks.push(groupChunk);
            }
            // A chunk that only repeats probes from later chunks cannot make
            // progress: after it is processed, every probe is still in the
            // queue as an ancestor. Drop such chunks. A deep dependency chain
            // then collapses into its last chunk, which is processed as one
            // task, because the chain cannot be measured in smaller
            // independent pieces.
            const seenProbes = new Set();
            for (let i = groupChunks.length - 1; i >= 0; i -= 1) {
                const chunkToCheck = groupChunks[i];
                const hasUniqueProbe = chunkToCheck
                    .some((probe) => !seenProbes.has(probe));
                if (hasUniqueProbe) {
                    chunkToCheck.forEach((probe) => seenProbes.add(probe));
                }
                else {
                    groupChunks.splice(i, 1);
                }
            }
            return groupChunks;
        };
        const chunks = [];
        let chunk = [];
        orderedGroups.forEach((root) => {
            const group = groups.get(root);
            group.sort((a, b) => (depthByProbe.get(a) - depthByProbe.get(b))
                || ((indexByProbe.get(a) ?? 0) - (indexByProbe.get(b) ?? 0)));
            // A dependent group larger than the batch size is split into
            // chunks that keep the ancestors of every probe in the chunk.
            if (group.length > CssHitsCounter.CSS_HITS_BATCH_SIZE) {
                if (chunk.length > 0) {
                    chunks.push(chunk);
                    chunk = [];
                }
                chunks.push(...splitDependentGroup(group));
                return;
            }
            if (chunk.length > 0
                && chunk.length + group.length > CssHitsCounter.CSS_HITS_BATCH_SIZE) {
                chunks.push(chunk);
                chunk = [];
            }
            chunk.push(...group);
            if (chunk.length >= CssHitsCounter.CSS_HITS_BATCH_SIZE) {
                chunks.push(chunk);
                chunk = [];
            }
        });
        if (chunk.length > 0) {
            chunks.push(chunk);
        }
        return chunks;
    }
    /**
     * Counts probes collected before and after the counter initialization.
     *
     * Each probe is temporarily reinserted into the document, so that the
     * injected marker can be read from its computed style, and removed
     * synchronously after the counting, so it is never painted. The probes
     * are processed in small chunks when possible, so a large queue does not
     * block the page in one task; a dependency chain deeper than the chunk
     * size is processed as one chunk. Nothing stays in the document between
     * chunks.
     *
     * Probes are ordered by dependency: a probe removed from another probe's
     * element is processed after that element is restored, and dependent
     * probes are kept in the same chunk. Without this, a bait removed before
     * its container would be measured with a detached target, and a container
     * removed before its bait would be removed again before the bait is
     * processed.
     *
     * Probes that did not match any rule are retried a few times, since the
     * marker styles may be injected slightly after the cosmetic data is
     * received. Once any hit is observed, the styles are known to be applied,
     * so unmatched probes are not retried; a probe is also not retried when
     * its own subtree already produced a hit. An ancestor probe stays queued
     * while a probe that still needs a retry depends on it, even if the
     * ancestor's own retry budget is exhausted.
     *
     * Only native stylesheet markers are detected this way: ExtendedCss
     * rules are reported when ExtendedCss itself applies them to an element.
     */
    countPendingProbes() {
        if (this.stopped || this.pendingProbes.length === 0) {
            return;
        }
        const allProbes = this.pendingProbes;
        this.pendingProbes = [];
        const chunks = CssHitsCounter.orderPendingProbes(allProbes);
        const probes = chunks[0] ?? [];
        // Probes that did not fit into this chunk, if any.
        const remainingProbes = chunks.slice(1).flat();
        // An ancestor probe is repeated in each dependent chunk; it will be
        // processed again in a later chunk, so it must not spend its retry
        // budget here.
        const remainingProbeSet = new Set(remainingProbes);
        // Elements that another probe in this chunk was removed from. A
        // counted probe that is such an ancestor must be restored again,
        // otherwise the dependent probe cannot be measured in its original
        // parent.
        const ancestorElements = new Set();
        probes.forEach(({ target }) => {
            let node = target;
            while (node) {
                if (node instanceof Element) {
                    ancestorElements.add(node);
                }
                node = node.parentNode;
            }
        });
        const elementsToCount = [];
        const restoredProbeElements = [];
        const countedElements = new Set();
        // Probes that do not need another pass: counted or intentionally
        // skipped (e.g. their subtree must not be re-inserted).
        const settledProbes = new Set();
        // Maps every counted element to the probe it belongs to, so a probe
        // is not retried once any element of its subtree has matched.
        const probeByElement = new Map();
        let result = [];
        if (this.observer) {
            this.observer.disconnect();
        }
        try {
            for (let i = 0; i < probes.length; i += 1) {
                const probe = probes[i];
                const { element } = probe;
                // The mutation observer already re-inserted and counted the
                // element, or, once the marker styles are known to be
                // applied, already re-inserted it without a hit. It must not
                // be put back again unless another probe in this chunk
                // depends on it.
                if ((this.countedProbes.has(element)
                    || (this.markerStylesApplied && this.probedElements.has(element)))
                    && !ancestorElements.has(element)) {
                    settledProbes.add(probe);
                    continue;
                }
                // ExtendedCss already reported the hit and removed the
                // element itself, so it must not be put back.
                if (this.extendedCssRemovedElements.has(element)) {
                    settledProbes.add(probe);
                    continue;
                }
                // The page may re-attach the element (or move it into a
                // detached container) while the probe is queued. Never move
                // such an element: re-inserting it would tear it out of its
                // container. A connected element can still be counted in
                // place; a detached one cannot match any rule.
                if (element.parentNode) {
                    if (!element.isConnected) {
                        settledProbes.add(probe);
                        continue;
                    }
                    const attachedDescendants = [];
                    ElementUtils.appendChildren(element, attachedDescendants);
                    elementsToCount.push(element);
                    probeByElement.set(element, probe);
                    for (let j = 0; j < attachedDescendants.length; j += 1) {
                        elementsToCount.push(attachedDescendants[j]);
                        probeByElement.set(attachedDescendants[j], probe);
                    }
                    continue;
                }
                const descendants = [];
                ElementUtils.appendChildren(element, descendants);
                // Do not re-insert resource-bearing or custom element
                // subtrees: it re-runs page side effects.
                if (!isProbeRestorable(element, descendants)) {
                    settledProbes.add(probe);
                    continue;
                }
                const restoreTarget = CssHitsCounter.getProbeRestoreTarget(probe.target);
                // Without a connected ancestor the probe cannot be measured
                // in its original cascade context, so do not restore it in an
                // unrelated position and do not burn its retry budget.
                if (!restoreTarget) {
                    settledProbes.add(probe);
                    continue;
                }
                CssHitsCounter.insertProbe(element, restoreTarget, probe.previousSibling, probe.nextSibling);
                restoredProbeElements.push(element);
                elementsToCount.push(element);
                probeByElement.set(element, probe);
                for (let j = 0; j < descendants.length; j += 1) {
                    elementsToCount.push(descendants[j]);
                    probeByElement.set(descendants[j], probe);
                }
            }
            result = this.countCssHitsForElements(elementsToCount, 0, null, countedElements);
        }
        finally {
            /**
             * Don't remove child elements of probe elements
             * https://github.com/AdguardTeam/AdguardBrowserExtension/issues/1096.
             */
            ElementUtils.removeElements(restoredProbeElements);
            this.startObserver();
        }
        if (result.length > 0) {
            this.onCssHitsFoundCallback(result);
        }
        // A matched element (the probe itself or one of its descendants)
        // means the marker styles are applied, so the probe must not be
        // retried. Each remaining probe has its own retry budget, so probes
        // delivered while a retry is armed are not dropped with the batch
        // they joined.
        const probesWithHit = new Set();
        countedElements.forEach((element) => {
            const probe = probeByElement.get(element);
            if (probe) {
                probesWithHit.add(probe);
            }
        });
        const retryProbes = [];
        for (let i = 0; i < probes.length; i += 1) {
            const probe = probes[i];
            if (settledProbes.has(probe) || probesWithHit.has(probe)) {
                continue;
            }
            // The marker styles are already known to be applied: this probe
            // did not match, and a retry would not change that.
            if (this.markerStylesApplied) {
                continue;
            }
            // The next chunk processes this probe again as an ancestor, so
            // do not spend its retry budget on chunking.
            if (remainingProbeSet.has(probe)) {
                continue;
            }
            const attempts = (this.pendingProbeAttempts.get(probe) ?? 0) + 1;
            this.pendingProbeAttempts.set(probe, attempts);
            if (attempts < CssHitsCounter.PENDING_PROBES_MAX_ATTEMPTS) {
                retryProbes.push(probe);
            }
        }
        // A retrying probe still needs its ancestor to restore the original
        // parent. Keep that ancestor queued even when its own retry budget is
        // exhausted; otherwise the retrying probe would be measured with a
        // detached target.
        if (!this.markerStylesApplied
            && (retryProbes.length > 0 || remainingProbes.length > 0)) {
            const neededAncestorElements = new Set();
            const collectAncestors = (probe) => {
                let node = probe.target;
                while (node) {
                    if (node instanceof Element) {
                        neededAncestorElements.add(node);
                    }
                    node = node.parentNode;
                }
            };
            retryProbes.forEach(collectAncestors);
            remainingProbes.forEach(collectAncestors);
            const retryProbeSet = new Set(retryProbes);
            for (let i = 0; i < probes.length; i += 1) {
                const probe = probes[i];
                if (settledProbes.has(probe)
                    || probesWithHit.has(probe)
                    || retryProbeSet.has(probe)
                    || remainingProbeSet.has(probe)) {
                    continue;
                }
                if (neededAncestorElements.has(probe.element)) {
                    retryProbes.push(probe);
                    retryProbeSet.add(probe);
                }
            }
        }
        // Retried probes are processed before the next chunk, so their retry
        // delay is not stretched by a large queue.
        const queuedProbes = remainingProbes.length > 0
            ? [...retryProbes, ...remainingProbes]
            : retryProbes;
        // A probe can appear in several dependent chunks as an ancestor; the
        // next pass re-splits the group, so keep a single queue entry.
        const uniqueQueuedProbes = [...new Set(queuedProbes)];
        if (uniqueQueuedProbes.length === 0 || this.stopped) {
            return;
        }
        this.pendingProbes = uniqueQueuedProbes;
        // Only the retried probes need to wait for the marker styles; the
        // next chunk of fresh probes can be processed right away.
        const delay = retryProbes.length > 0 || remainingProbes.length === 0
            ? CssHitsCounter.PENDING_PROBES_RETRY_DELAY_MS
            : CssHitsCounter.COUNT_CSS_HITS_BATCH_DELAY;
        this.pendingProbesTimeoutId = window.setTimeout(() => {
            this.pendingProbesTimeoutId = null;
            this.countPendingProbes();
        }, delay);
    }
    /**
     * Starts mutation observer.
     */
    startObserver() {
        if (this.observer && !this.stopped) {
            // TODO: Check, maybe we should observer for 'characterData' and
            // 'characterDataOldValue' like it was in the old extension code
            this.observer.observe(document.documentElement || document, {
                childList: true,
                subtree: true,
                attributes: true,
            });
        }
    }
    /**
     * Returns the node where a detached probe can be temporarily restored
     * before `getComputedStyle` is called.
     *
     * The probe must be measured in its original cascade context: restoring it
     * in a different tree position could report a hit for a rule that does not
     * actually match the element, or miss a context-dependent rule. Therefore
     * the original mutation target is used only if it is still a connected
     * element. `isConnected` is inherited, so a detached target has no
     * connected ancestor either.
     *
     * @param target Original mutation target.
     *
     * @returns The target if it is a connected element, otherwise `null`.
     */
    static getProbeRestoreTarget(target) {
        return target instanceof Element && target.isConnected ? target : null;
    }
    /**
     * Temporarily restores a detached probe to the document at its original
     * position, when possible.
     *
     * @param element Detached probe element.
     * @param target Node to append the probe to.
     * @param previousSibling Sibling preceding the probe at the moment of the mutation.
     * @param nextSibling Sibling following the probe at the moment of the mutation.
     */
    static insertProbe(element, target, previousSibling, nextSibling) {
        if (nextSibling && nextSibling.parentNode === target) {
            target.insertBefore(element, nextSibling);
            return;
        }
        if (previousSibling && previousSibling.parentNode === target) {
            target.insertBefore(element, previousSibling.nextSibling);
            return;
        }
        target.appendChild(element);
    }
    /**
     * Reads the `--adguard-hit` marker from an element's computed style (AG-265).
     *
     * @param element Element to probe.
     *
     * @returns Rule info or `null` if no marker is present.
     */
    static getCssHitData(element) {
        try {
            const value = getComputedStyle(element)
                .getPropertyValue(CssHitsCounter.MARKER_PROPERTY_NAME);
            if (!value) {
                return null;
            }
            return ElementUtils.parseInfo(value, CssHitsCounter.MARKER_PREFIX);
        }
        catch {
            // Malformed marker values (e.g. broken percent-encoding) or
            // elements that cannot be measured should not break counting.
            return null;
        }
    }
}



;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+tswebextension@7.0.1_@adguard+re2-wasm@1.2.0_typescript@5.6.3/node_modules/@adguard/tswebextension/dist/common/hidden-style.js
/**
 * Css, injected to broken element for hiding.
 */
// eslint-disable-next-line max-len
const HIDING_STYLE = '{ display: none!important; visibility: hidden!important; height: 0px!important; min-height: 0px!important; }';
/**
 * Creates hiding css rule for specified tag with src attribute.
 *
 * @param tag Element tag for css selector.
 * @param src `src` attribute value for css selector. If value is the empty string
 * then the selector does not represent anything.
 * @param matching Attribute matching type. Currently support strict (=) and suffix ($=) matching.
 * Default to strict.
 *
 * @returns Css rule text.
 */
function createHidingCssRule(tag, src, matching = "=" /* AttributeMatching.Strict */) {
    return `${tag}[src${matching}"${src}"] ${HIDING_STYLE}\n`;
}



;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+tswebextension@7.0.1_@adguard+re2-wasm@1.2.0_typescript@5.6.3/node_modules/@adguard/tswebextension/dist/content-script.mv3.js











/**
 * This class applies cookie rules in page context.
 *
 * Steps:
 * - content script requests matching cookie rules for the frame
 *   (in which this script is executed)
 * - service returns matching set of rules data to content script
 * - the rules are applied with {@link CookieController}
 * - filtering log receives callback with applied rules data.
 *
 * The important point is: there is no way to run cookie controller script via
 * browser.tabs.executeScript cause one only could be executed for all frames or
 * main frame only. But it's not correct cause there should be different rules
 * for each frame.
 */
class content_script_mv3_CookieController {
    /**
     * Retry timeout for {@link MessageType.GetCookieRules} request to background in milliseconds.
     */
    static GET_COOKIE_RULES_RETRY_TIMEOUT_MS = 100;
    /**
     * Max {@link MessageType.GetCookieRules} request limit.
     */
    static MAX_GET_COOKIE_RULES_TRIES = 200;
    /**
     * Number of {@link MessageType.GetCookieRules} requests.
     */
    tries = 0;
    /**
     * Creates new {@link CookieController} instance.
     */
    constructor() {
        this.process = this.process.bind(this);
    }
    /**
     * Init cookie rules processing.
     */
    init() {
        this.process();
    }
    /**
     * Sends {@link MessageType.GetCosmeticData} message to background and process response.
     */
    async process() {
        const response = await sendAppMessage({
            type: message_constants_MessageType.GetCookieRules,
            payload: {
                documentUrl: document.location.href,
            },
        });
        if (response) {
            this.applyCookieRules(response);
        }
    }
    /**
     * Process {@link MessageType.ContentScriptCookieRulesData} response from background.
     *
     * If {@link response.isAppStarted} is false, retry
     * request after {@link GET_COOKIE_RULES_RETRY_TIMEOUT_MS} milliseconds.
     * Else apply cookie rules from {@link response.cookieRules}.
     *
     * @param response Response cookie rules data from background.
     */
    applyCookieRules = async (response) => {
        const { isAppStarted, cookieRules } = response;
        if (!isAppStarted && this.tries <= content_script_mv3_CookieController.MAX_GET_COOKIE_RULES_TRIES) {
            this.tries += 1;
            setTimeout(this.process, content_script_mv3_CookieController.GET_COOKIE_RULES_RETRY_TIMEOUT_MS);
            return;
        }
        if (!response || cookieRules === undefined || cookieRules.length === 0) {
            return;
        }
        try {
            const onRuleApplied = (data) => {
                sendAppMessage({
                    type: message_constants_MessageType.SaveCookieLogEvent,
                    payload: data,
                });
            };
            const cookieController = new CookieController$1(onRuleApplied);
            cookieController.apply(cookieRules);
        }
        catch (e) {
            // eslint-disable-next-line no-console
            console.error(e);
            /**
             * Content script injected on in every frame, but document cookie API in
             * iframes can be blocked by website CSP policy. We ignore this cases.
             * Content script matching defined in browser extension.
             * TODO: move error handling to it.
             */
        }
    };
}

/**
 * This class applies cosmetic rules in page context.
 */
class CosmeticController {
    /**
     * Retry timeout for {@link MessageType.GetCosmeticData} request to background in milliseconds.
     */
    static GET_COSMETIC_DATA_RETRY_TIMEOUT_MS = 100;
    /**
     * Max {@link MessageType.GetCosmeticData} request limit.
     */
    static MAX_GET_COSMETIC_DATA_TRIES = 200;
    /**
     * Number of {@link MessageType.GetCosmeticData} requests.
     */
    tries = 0;
    /**
     * Module that collects statistics about the usage of CSS rules.
     */
    cssHitsCounter;
    /**
     * Collects short-lived elements created before the counter initialization.
     */
    pendingProbesCollector = new PendingProbesCollector();
    /**
     * Creates new {@link CosmeticController} instance.
     */
    constructor() {
        this.process = this.process.bind(this);
        this.beforeStyleApplied = this.beforeStyleApplied.bind(this);
    }
    /**
     * Init cosmetic processing.
     */
    init() {
        // Start observing the DOM before the asynchronous cosmetic data
        // request, so that elements created and removed during the document
        // loading are not missed by the CSS hits counter.
        this.pendingProbesCollector.start();
        this.process();
    }
    /**
     * Sends {@link MessageType.GetCosmeticData} message to background and process response.
     */
    async process() {
        try {
            const res = await sendAppMessage({
                type: message_constants_MessageType.GetCosmeticData,
                payload: {
                    documentUrl: window.location.href,
                },
            });
            if (res) {
                this.applyExtendedCss(res);
                return;
            }
        }
        catch (e) {
            this.pendingProbesCollector.stop();
            throw e;
        }
        // Without a response the counter is never created, so the collected
        // probes will never be counted: stop observing the DOM.
        this.pendingProbesCollector.stop();
    }
    /**
     * Process {@link MessageType.GetCosmeticData} response from background.
     *
     * If {@link cosmeticData.isAppStarted} is false, retry
     * request after {@link GET_COSMETIC_DATA_RETRY_TIMEOUT_MS} milliseconds.
     * Else apply extended css rules from {@link cosmeticData.extCssText}
     * and enable {@link CssHitsCounter} if {@link cosmeticData.areHitsStatsCollected} is true.
     *
     * @param cosmeticData Response cosmetic data from background.
     */
    applyExtendedCss(cosmeticData) {
        const { isAppStarted, extCssRules, areHitsStatsCollected, nativeCssSelectors, } = cosmeticData;
        if (!isAppStarted
            && this.tries <= CosmeticController.MAX_GET_COSMETIC_DATA_TRIES) {
            this.tries += 1;
            setTimeout(this.process, CosmeticController.GET_COSMETIC_DATA_RETRY_TIMEOUT_MS);
            return;
        }
        if (areHitsStatsCollected) {
            this.cssHitsCounter = CosmeticController.createCssHitsCounter(this.pendingProbesCollector);
        }
        else {
            this.pendingProbesCollector.stop();
        }
        CosmeticController.repairNativeCss(nativeCssSelectors);
        if (!extCssRules || extCssRules.length === 0) {
            return;
        }
        const extendedCssConfig = {
            cssRules: extCssRules,
        };
        if (areHitsStatsCollected) {
            extendedCssConfig.beforeStyleApplied = this.beforeStyleApplied;
        }
        const extendedCss = new ExtendedCss(extendedCssConfig);
        extendedCss.apply();
    }
    /**
     * Validates native CSS element-hiding selectors and injects a corrective
     * `<style>` element containing only the valid ones if any invalid selectors
     * are found.
     *
     * The background already injected grouped native CSS via the browser API.
     * When any selector in a group is invalid, the browser drops the entire
     * group. This method validates all selectors and, if any are invalid,
     * re-injects only the valid selectors individually to restore correct filtering.
     *
     * @param selectors Individual native CSS element-hiding selectors.
     */
    static repairNativeCss(selectors) {
        if (!selectors || selectors.length === 0) {
            return;
        }
        const { valid, invalid } = validateSelectors(selectors);
        if (invalid.length === 0) {
            return;
        }
        if (valid.length === 0) {
            return;
        }
        const style = document.createElement('style');
        style.setAttribute('type', 'text/css');
        style.textContent = valid
            .map((sel) => `${sel} ${HIDING_STYLE}`)
            .join('\n');
        (document.head || document.documentElement).appendChild(style);
    }
    /**
     * Preprocess {@link IAffectedElement} for {@link ExtendedCss} instance.
     *
     * @param el Record with required 'content' style property in rules.
     *
     * @returns Affected element record.
     */
    beforeStyleApplied(el) {
        if (!this.cssHitsCounter) {
            return el;
        }
        return this.cssHitsCounter.countAffectedByExtendedCss(el);
    }
    /**
     * Create new {@link CssHitsCounter} instance.
     *
     * @param pendingProbesCollector Collector of short-lived elements.
     *
     * @returns CssHitsCounter instance.
     */
    static createCssHitsCounter(pendingProbesCollector) {
        return new CssHitsCounter((stats) => {
            sendAppMessage({
                type: message_constants_MessageType.SaveCssHitsStats,
                payload: stats,
            });
        }, { pendingProbesCollector });
    }
}

const cosmeticController = new CosmeticController();
cosmeticController.init();
const content_script_mv3_cookieController = new content_script_mv3_CookieController();
content_script_mv3_cookieController.init();

;// CONCATENATED MODULE: ./Extension/src/common/messages/constants.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ /**
 * Important: do not use z.inferOf, because it brings a lot of side effects with
 * many dependencies to the bundle.
 *
 * Also please try, if possible, to not import here external modules
 * other that types.
 */ const constants_APP_MESSAGE_HANDLER_NAME = 'app';
/**
 * Message types used for message passing between extension contexts
 * (popup, filtering log, content scripts, background)
 */ var constants_MessageType = /*#__PURE__*/ function(MessageType) {
    MessageType["CreateEventListener"] = "createEventListener";
    MessageType["RemoveListener"] = "removeListener";
    MessageType["OpenExtensionStore"] = "openExtensionStore";
    MessageType["AddAndEnableFilter"] = "addAndEnableFilter";
    MessageType["ApplySettingsJson"] = "applySettingsJson";
    MessageType["OpenFilteringLog"] = "openFilteringLog";
    MessageType["OpenFullscreenUserRules"] = "openFullscreenUserRules";
    MessageType["CloseFullscreenUserRules"] = "closeFullscreenUserRules";
    MessageType["UpdateFullscreenUserRulesTheme"] = "updateFullscreenUserRulesTheme";
    MessageType["ResetBlockedAdsCount"] = "resetBlockedAdsCount";
    MessageType["ResetSettings"] = "resetSettings";
    MessageType["GetUserRules"] = "getUserRules";
    MessageType["SaveUserRules"] = "saveUserRules";
    MessageType["GetAllowlistDomains"] = "getAllowlistDomains";
    MessageType["SaveAllowlistDomains"] = "saveAllowlistDomains";
    MessageType["CheckFiltersUpdate"] = "checkFiltersUpdate";
    MessageType["GetCategoriesFilters"] = "getCategoriesFilters";
    MessageType["CheckExtensionUpdateMv3"] = "checkExtensionUpdateMv3";
    MessageType["UpdateExtensionMv3"] = "updateExtensionMv3";
    MessageType["DisableFiltersGroup"] = "disableFiltersGroup";
    MessageType["DisableFilter"] = "disableFilter";
    MessageType["ClearUnusedFiltersStatus"] = "clearUnusedFiltersStatus";
    MessageType["LoadCustomFilterInfo"] = "loadCustomFilterInfo";
    MessageType["SubscribeToCustomFilter"] = "subscribeToCustomFilter";
    MessageType["RemoveAntiBannerFilter"] = "removeAntiBannerFilter";
    MessageType["GetIsAppInitialized"] = "getIsAppInitialized";
    MessageType["GetTabInfoForPopup"] = "getTabInfoForPopup";
    MessageType["ChangeApplicationFilteringPaused"] = "changeApplicationFilteringPaused";
    MessageType["OpenRulesLimitsTab"] = "openRulesLimitsTab";
    MessageType["OpenSettingsTab"] = "openSettingsTab";
    MessageType["OpenAssistant"] = "openAssistant";
    MessageType["OpenAbuseTab"] = "openAbuseTab";
    MessageType["OpenSiteReportTab"] = "openSiteReportTab";
    MessageType["OpenExtensionsSettingsPage"] = "openExtensionsSettingsPage";
    MessageType["OpenExtensionDetailsPage"] = "openExtensionDetailsPage";
    MessageType["ResetUserRulesForPage"] = "resetUserRulesForPage";
    MessageType["RemoveAllowlistDomain"] = "removeAllowlistDomain";
    MessageType["AddAllowlistDomainForTabId"] = "addAllowlistDomainForTabId";
    MessageType["AddAllowlistDomainForUrl"] = "addAllowlistDomainForUrl";
    MessageType["OnOpenFilteringLogPage"] = "onOpenFilteringLogPage";
    MessageType["GetFilteringLogData"] = "getFilteringLogData";
    MessageType["InitializeFrameScript"] = "initializeFrameScript";
    MessageType["InitializeBlockingPageScript"] = "initializeBlockingPageScript";
    MessageType["OnCloseFilteringLogPage"] = "onCloseFilteringLogPage";
    MessageType["GetFilteringInfoByTabId"] = "getFilteringInfoByTabId";
    MessageType["SynchronizeOpenTabs"] = "synchronizeOpenTabs";
    MessageType["ClearEventsByTabId"] = "clearEventsByTabId";
    MessageType["RefreshPage"] = "refreshPage";
    MessageType["AddUserRule"] = "addUserRule";
    MessageType["RemoveUserRule"] = "removeUserRule";
    MessageType["EnableFiltersGroup"] = "enableFiltersGroup";
    MessageType["NotifyListeners"] = "notifyListeners";
    MessageType["AddLongLivedConnection"] = "addLongLivedConnection";
    MessageType["GetOptionsData"] = "getOptionsData";
    MessageType["GetAutoDisableNotifications"] = "getAutoDisableNotifications";
    MessageType["AcknowledgeAutoDisableNotifications"] = "acknowledgeAutoDisableNotifications";
    MessageType["ChangeUserSettings"] = "changeUserSetting";
    MessageType["CheckRequestFilterReady"] = "checkRequestFilterReady";
    MessageType["OpenThankYouPage"] = "openThankYouPage";
    MessageType["OpenSafebrowsingTrusted"] = "openSafebrowsingTrusted";
    MessageType["GetSelectorsAndScripts"] = "getSelectorsAndScripts";
    MessageType["CheckPageScriptWrapperRequest"] = "checkPageScriptWrapperRequest";
    MessageType["ProcessShouldCollapse"] = "processShouldCollapse";
    MessageType["ProcessShouldCollapseMany"] = "processShouldCollapseMany";
    MessageType["AddFilteringSubscription"] = "addFilterSubscription";
    MessageType["SetNotificationViewed"] = "setNotificationViewed";
    MessageType["SaveCssHitsStats"] = "saveCssHitStats";
    MessageType["GetCookieRules"] = "getCookieRules";
    MessageType["SaveCookieLogEvent"] = "saveCookieRuleEvent";
    MessageType["LoadSettingsJson"] = "loadSettingsJson";
    MessageType["AddUrlToTrusted"] = "addUrlToTrusted";
    MessageType["SetPreserveLogState"] = "setPreserveLogState";
    MessageType["GetUserRulesEditorData"] = "getUserRulesEditorData";
    MessageType["GetEditorStorageContent"] = "getEditorStorageContent";
    MessageType["SetEditorStorageContent"] = "setEditorStorageContent";
    MessageType["SetFilteringLogWindowState"] = "setFilteringLogWindowState";
    MessageType["AppInitialized"] = "appInitialized";
    MessageType["UpdateTotalBlocked"] = "updateTotalBlocked";
    MessageType["ScriptletCloseWindow"] = "scriptletCloseWindow";
    MessageType["ShowRuleLimitsAlert"] = "showRuleLimitsAlert";
    MessageType["ShowAlertPopup"] = "showAlertPopup";
    MessageType["ShowVersionUpdatedPopup"] = "showVersionUpdatedPopup";
    MessageType["ShowEdgeMv3MigrationPopup"] = "showEdgeMv3MigrationPopup";
    MessageType["UpdateListeners"] = "updateListeners";
    MessageType["SetConsentedFilters"] = "setConsentedFilters";
    MessageType["GetIsConsentedFilter"] = "getIsConsentedFilter";
    MessageType["SendTelemetryCustomEvent"] = "sendTelemetryCustomEvent";
    MessageType["SendTelemetryPageViewEvent"] = "sendTelemetryPageViewEvent";
    MessageType["AddTelemetryOpenedPage"] = "addTelemetryOpenedPage";
    MessageType["RemoveTelemetryOpenedPage"] = "removeTelemetryOpenedPage";
    MessageType["DismissSearchPageAccessNotification"] = "dismissSearchPageAccessNotification";
    MessageType["GetRulesLimitsCountersMv3"] = "getRulesLimitsCountersMv3";
    MessageType["CanEnableStaticFilterMv3"] = "canEnableStaticFilterMv3";
    MessageType["CanEnableStaticGroupMv3"] = "canEnableStaticGroupMv3";
    MessageType["ClearRulesLimitsWarningMv3"] = "clearRulesLimitsWarningMv3";
    MessageType["CurrentLimitsMv3"] = "currentLimitsMv3";
    MessageType["GetExtensionStatusForPopupMV3"] = "getExtensionStatusForPopupMV3";
    MessageType["ImportConfiguration"] = "importConfiguration";
    MessageType["IsPendingForImport"] = "isPendingForImport";
    MessageType["GetPendingImportBlockWebrtc"] = "getPendingImportBlockWebrtc";
    MessageType["ApplyImportConfiguration"] = "applyImportConfiguration";
    MessageType["CancelImportConfiguration"] = "cancelImportConfiguration";
    MessageType["GenerateShareUrl"] = "generateShareUrl";
    MessageType["ReapplyCanvasProtection"] = "reapplyCanvasProtection";
    return MessageType;
}({});
const FULLSCREEN_STATE = 'fullscreen';
/**
 * Id of the link to the extension settings in the Edge MV3 migration popup.
 * The background renders the link into `userScriptsText`, the content script handles its clicks.
 */ const EDGE_MV3_MIGRATION_SETTINGS_LINK_ID = 'adguard-edge-mv3-migration-settings-link';

;// CONCATENATED MODULE: ./Extension/src/common/messages/message-handler.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 

/**
 * Type guard for messages that have a 'type' field with possible {@link MessageType}.
 *
 * @note Added to no bring here huge zod library.
 *
 * @param message Unknown message.
 *
 * @returns True if message has 'type' field with possible {@link MessageType}.
 */ const messageHasTypeField = (message)=>{
    return typeof message === 'object' && message !== null && 'type' in message;
};
/**
 * Type guard for messages that have a 'type' field and 'data' field and looks like {@link Message}.
 *
 * @note Added to no bring here huge zod library.
 *
 * @param message Unknown message.
 *
 * @returns True if message has 'type' and 'data' fields and looks like {@link Message}.
 */ const messageHasTypeAndDataFields = (message)=>{
    return messageHasTypeField(message) && 'data' in message;
};
/**
 * API for handling Messages via {@link browser.runtime.onMessage}
 */ class MessageHandler {
    listeners = new Map();
    constructor(){
        this.handleMessage = this.handleMessage.bind(this);
    }
    init() {
        browser_polyfill_default().runtime.onMessage.addListener(this.handleMessage);
    }
    /**
     * Add message listener.
     * Listeners limited to 1 per message type to prevent race
     * condition while response processing.
     *
     * TODO: implement listeners priority execution strategy
     *
     * @param type - {@link ValidMessageTypes}
     * @param listener - {@link MessageListener}
     *
     * @throws error, if message listener already added
     */ addListener(type, listener) {
        if (this.listeners.has(type)) {
            throw new Error(`Message handler: ${type} listener has already been registered`);
        }
        // Cast through unknown to help TS understand that the listener is of
        // the correct type. It will check types at compile time.
        this.listeners.set(type, listener);
    }
    /**
     * Removes message listener.
     *
     * @param type - {@link ValidMessageTypes}
     */ removeListener(type) {
        this.listeners.delete(type);
    }
    /**
     * Removes all listeners
     */ removeListeners() {
        this.listeners.clear();
    }
    /**
     * Check if the message is of type {@link Message}.
     *
     * @param message Message of basic type {@link Message} or {@link EngineMessage}.
     *
     * @returns True if the message is of type {@link Message}.
     */ static isValidMessageType(message) {
        return message.handlerName === constants_APP_MESSAGE_HANDLER_NAME && 'type' in message;
    }
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/@adguard+logger@2.0.0/node_modules/@adguard/logger/dist/es/index.mjs
/**
 * Checks if error has message.
 *
 * @param error Error object.
 *
 * @returns True if error has message.
 */
function es_isErrorWithMessage(error) {
    return (typeof error === 'object'
        && error !== null
        && 'message' in error
        && typeof error.message === 'string');
}
/**
 * Converts error to the error with a message.
 *
 * @param maybeError Possible error.
 *
 * @returns Error with a message.
 */
function es_toErrorWithMessage(maybeError) {
    if (es_isErrorWithMessage(maybeError)) {
        return maybeError;
    }
    try {
        return new Error(JSON.stringify(maybeError));
    }
    catch {
        // fallback in case there's an error stringifying the maybeError
        // like with circular references, for example.
        return new Error(String(maybeError));
    }
}
/**
 * Converts an error object to an error with a message. This method might be helpful to handle thrown errors.
 *
 * @param error Error object.
 *
 * @returns Message of the error.
 */
function es_getErrorMessage(error) {
    return es_toErrorWithMessage(error).message;
}

/**
 * Pads a number with leading zeros.
 *
 * @param num The number to pad.
 * @param size The number of digits to pad to.
 *
 * @returns The padded number.
 */
const es_pad = (num, size = 2) => {
    return num.toString().padStart(size, '0');
};
/**
 * Formats a date into an ISO 8601-like string with milliseconds.
 *
 * @param {Date|number} date The date object or timestamp to format.
 *
 * @returns {string} The formatted date string.
 */
const es_formatTime = (date) => {
    const d = (date instanceof Date) ? date : new Date(date);
    const year = d.getFullYear();
    const month = es_pad(d.getMonth() + 1); // Months are 0-based
    const day = es_pad(d.getDate());
    const hour = es_pad(d.getHours());
    const minute = es_pad(d.getMinutes());
    const second = es_pad(d.getSeconds());
    const millisecond = es_pad(d.getMilliseconds(), 3); // Milliseconds are 3 digits
    return `${year}-${month}-${day}T${hour}:${minute}:${second}:${millisecond}`;
};

/**
 * String presentation of log levels, for convenient users usage.
 * Ordered in the same way as LogLevelNumeric.
 *
 * First three levels will be shown to users, and the last two are for developers.
 */
var dist_es_LogLevel;
(function (LogLevel) {
    /**
     * For errors.
     */
    LogLevel["Error"] = "error";
    /**
     * For not critical errors.
     */
    LogLevel["Warn"] = "warn";
    /**
     * For important information.
     * Use for general operational messages.
     */
    LogLevel["Info"] = "info";
    /**
     * For debugging purposes, e.g. Inside conditions, loops or some edge cases.
     */
    LogLevel["Debug"] = "debug";
    /**
     * For ultra-detailed, step-by-step traces (like stack traces or flow tracking).
     */
    LogLevel["Verbose"] = "verbose";
})(dist_es_LogLevel || (dist_es_LogLevel = {}));
/**
 * Log levels map, which maps number level to string level.
 * Ordered in the same way as LogLevelNumeric.
 */
const es_levelMapNumToString = {
    [1 /* LogLevelNumeric.Error */]: dist_es_LogLevel.Error,
    [2 /* LogLevelNumeric.Warn */]: dist_es_LogLevel.Warn,
    [3 /* LogLevelNumeric.Info */]: dist_es_LogLevel.Info,
    [4 /* LogLevelNumeric.Debug */]: dist_es_LogLevel.Debug,
    [5 /* LogLevelNumeric.Verbose */]: dist_es_LogLevel.Verbose,
};
/**
 * Log levels map, which maps string level to number level.
 */
const es_levelMapStringToNum = Object.entries(es_levelMapNumToString)
    .reduce((acc, [key, value]) => {
    // Here, key is originally a string since Object.entries() returns [string, string][].
    // We need to cast the key to LogLevelNumeric correctly without causing type mismatches.
    const numericKey = Number(key);
    if (!Number.isNaN(numericKey)) {
        acc[value] = numericKey;
    }
    return acc;
}, {});
/**
 * Methods supported by console. Used to manage levels.
 * Ordered in the same way as LogLevelNumeric.
 */
var dist_es_LogMethod;
(function (LogMethod) {
    LogMethod["Error"] = "error";
    LogMethod["Warn"] = "warn";
    LogMethod["Info"] = "info";
    LogMethod["Debug"] = "debug";
    LogMethod["Trace"] = "trace";
})(dist_es_LogMethod || (dist_es_LogMethod = {}));
/**
 * Simple logger with log levels.
 */
class es_Logger {
    currentLevelValue = 3 /* LogLevelNumeric.Info */;
    writer;
    /**
     * Constructor.
     *
     * @param writer Writer object.
     */
    constructor(writer = console) {
        this.writer = writer;
        // bind the logging methods to avoid losing context
        this.error = this.error.bind(this);
        this.warn = this.warn.bind(this);
        this.info = this.info.bind(this);
        this.debug = this.debug.bind(this);
        this.trace = this.trace.bind(this);
    }
    /**
     * Print error messages.
     * Use when something went wrong.
     *
     * @param args Printed arguments.
     */
    error(...args) {
        this.print(1 /* LogLevelNumeric.Error */, dist_es_LogMethod.Error, args);
    }
    /**
     * Print warn messages.
     * Use when Something might go wrong.
     *
     * @param args Printed arguments.
     */
    warn(...args) {
        this.print(2 /* LogLevelNumeric.Warn */, dist_es_LogMethod.Warn, args);
    }
    /**
     * Print messages you want to disclose to users.
     * Use for general operational messages.
     *
     * @param args Printed arguments.
     */
    info(...args) {
        this.print(3 /* LogLevelNumeric.Info */, dist_es_LogMethod.Info, args);
    }
    /**
     * Print debug messages. Usually used for technical information.
     *
     * @param args Printed arguments.
     */
    debug(...args) {
        this.print(4 /* LogLevelNumeric.Debug */, dist_es_LogMethod.Debug, args);
    }
    /**
     * Print trace messages.
     * Ultra-detailed, step-by-step traces (like stack traces or flow tracking).
     *
     * @param args Printed arguments.
     */
    trace(...args) {
        this.print(5 /* LogLevelNumeric.Verbose */, dist_es_LogMethod.Trace, args);
    }
    /**
     * Getter for log level.
     *
     * @returns Logger level.
     */
    get currentLevel() {
        return es_levelMapNumToString[this.currentLevelValue];
    }
    /**
     * Setter for log level. With this method log level can be updated dynamically.
     *
     * @param logLevel Logger level.
     *
     * @throws Error if log level is not supported.
     */
    set currentLevel(logLevel) {
        const level = es_levelMapStringToNum[logLevel];
        if (level === undefined) {
            throw new Error(`Logger supports only the following levels: ${[Object.values(dist_es_LogLevel).join(', ')]}`);
        }
        this.currentLevelValue = level;
    }
    /**
     * Converts error to string, and adds stack trace.
     *
     * @param error Error to print.
     *
     * @returns Error message.
     */
    static errorToString(error) {
        const message = es_getErrorMessage(error);
        return `${message}\nStack trace:\n${error.stack}`;
    }
    /**
     * Prints error message with stack trace.
     * It prints the message with the stack trace in a collapsed group.
     * This is useful for debugging purposes, as it allows to see the stack trace
     * without cluttering the console with too many messages.
     *
     * @param formattedTime Formatted time.
     * @param formattedArgs Formatted arguments.
     */
    printWithStackTrace(formattedTime, formattedArgs) {
        // If grouping is not supported, print just expanded trace, but this
        // leads to a lot of dirty logs in the console, since the stack trace
        // will be printed for every message.
        if (!this.writer.groupCollapsed || !this.writer.groupEnd) {
            // Print expanded trace
            this.writer.trace(formattedTime, ...formattedArgs);
            return;
        }
        // Print collapsed trace to make logs more readable and access to stack
        // trace by clicking on the group.
        this.writer.groupCollapsed(formattedTime, ...formattedArgs);
        this.writer.trace();
        this.writer.groupEnd();
    }
    /**
     * Wrapper over log methods.
     *
     * @param level Logger level.
     * @param method Logger method.
     * @param args Printed arguments.
     */
    print(level, method, args) {
        // Skip writing if the basic conditions are not met.
        if (this.currentLevelValue < level) {
            return;
        }
        // Do not print if no arguments are passed.
        if (!args || args.length === 0 || !args[0]) {
            return;
        }
        const formattedArgs = args.map((value) => {
            if (value instanceof Error) {
                return es_Logger.errorToString(value);
            }
            if (value && typeof value.message === 'string') {
                return value.message;
            }
            if (typeof value === 'object' && value !== null) {
                return JSON.stringify(value);
            }
            return String(value);
        });
        const formattedTime = `${es_formatTime(new Date())}:`;
        /**
         * If current log level is Debug or Verbose, print all channels with stack
         * trace via using writer.trace method to help identify the location of the
         * log.
         *
         * Exception is Error method, because it is already contains build-in
         * stack trace.
         */
        if (this.currentLevelValue >= es_levelMapStringToNum[dist_es_LogLevel.Debug]
            && method !== dist_es_LogMethod.Error) {
            this.printWithStackTrace(formattedTime, formattedArgs);
            return;
        }
        // Otherwise just print with requested method of writer.
        this.writer[method](formattedTime, ...formattedArgs);
    }
}



;// CONCATENATED MODULE: ./Extension/src/background/storages/browser-storage.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ /**
 * Wrapper for StorageArea with dev-friendly interface.
 *
 * @template Data The type of the value stored in the storage.
 */ class BrowserStorage {
    storage;
    /**
     * Constructs an instance of the BrowserStorage class.
     *
     * @param storage The storage area to use.
     */ constructor(storage){
        this.storage = storage;
    }
    /**
     * Sets data to storage.
     *
     * @param key Storage key.
     * @param value Storage value.
     */ async set(key, value) {
        await this.storage.set({
            [key]: value
        });
    }
    /**
     * Returns data from storage.
     *
     * @param key Storage key.
     *
     * @returns Storage value.
     */ async get(key) {
        return this.storage.get(key).then((data)=>data[key]);
    }
    /**
     * Removes data from storage.
     *
     * @param key Storage key.
     */ async remove(key) {
        await this.storage.remove(key);
    }
    /**
     * Sets multiple key-value pairs in the storage.
     *
     * @param data The key-value pairs to set.
     *
     * @returns True if all operations were successful, false otherwise.
     *
     * @example
     * ```ts
     * const storage = new Storage();
     * await storage.setMultiple({
     *    key1: 'value1',
     *    key2: 'value2',
     * });
     * ```
     */ // TODO: Implement some kind of transaction to ensure atomicity, if possible
    // Note: We only use this method for Firefox if "Never Remember History" is enabled
    async setMultiple(data) {
        try {
            await this.storage.set(data);
            return true;
        } catch (e) {
            return false;
        }
    }
    /**
     * Removes multiple key-value pairs from the storage.
     *
     * @param keys The keys to remove.
     *
     * @returns True if all operations were successful, false otherwise.
     */ async removeMultiple(keys) {
        await this.storage.remove(keys);
        return true;
    }
    /**
     * Get the entire contents of the storage.
     *
     * @returns Promise that resolves with the entire contents of the storage.
     */ async entries() {
        return this.storage.get(null);
    }
    /**
     * Get all keys from the storage.
     *
     * @returns Promise that resolves with all keys from the storage.
     */ async keys() {
        return Object.keys(await this.entries());
    }
    /**
     * Checks if the storage has a key.
     *
     * @param key The key to check.
     *
     * @returns True if the key exists, false otherwise.
     */ async has(key) {
        return this.storage.get(key).then((data)=>key in data);
    }
    /**
     * Clears the storage.
     */ async clear() {
        await this.storage.clear();
    }
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/nanoid@3.3.6/node_modules/nanoid/index.browser.js

let random = bytes => crypto.getRandomValues(new Uint8Array(bytes))
let customRandom = (alphabet, defaultSize, getRandom) => {
  let mask = (2 << (Math.log(alphabet.length - 1) / Math.LN2)) - 1
  let step = -~((1.6 * mask * defaultSize) / alphabet.length)
  return (size = defaultSize) => {
    let id = ''
    while (true) {
      let bytes = getRandom(step)
      let j = step
      while (j--) {
        id += alphabet[bytes[j] & mask] || ''
        if (id.length === size) return id
      }
    }
  }
}
let customAlphabet = (alphabet, size = 21) =>
  customRandom(alphabet, size, random)
let nanoid = (size = 21) =>
  crypto.getRandomValues(new Uint8Array(size)).reduce((id, byte) => {
    byte &= 63
    if (byte < 36) {
      id += byte.toString(36)
    } else if (byte < 62) {
      id += (byte - 26).toString(36).toUpperCase()
    } else if (byte > 62) {
      id += '-'
    } else {
      id += '_'
    }
    return id
  }, '')


;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/double-indexed-kv.js
class DoubleIndexedKV {
    constructor() {
        this.keyToValue = new Map();
        this.valueToKey = new Map();
    }
    set(key, value) {
        this.keyToValue.set(key, value);
        this.valueToKey.set(value, key);
    }
    getByKey(key) {
        return this.keyToValue.get(key);
    }
    getByValue(value) {
        return this.valueToKey.get(value);
    }
    clear() {
        this.keyToValue.clear();
        this.valueToKey.clear();
    }
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/registry.js

class Registry {
    constructor(generateIdentifier) {
        this.generateIdentifier = generateIdentifier;
        this.kv = new DoubleIndexedKV();
    }
    register(value, identifier) {
        if (this.kv.getByValue(value)) {
            return;
        }
        if (!identifier) {
            identifier = this.generateIdentifier(value);
        }
        this.kv.set(identifier, value);
    }
    clear() {
        this.kv.clear();
    }
    getIdentifier(value) {
        return this.kv.getByValue(value);
    }
    getValue(identifier) {
        return this.kv.getByKey(identifier);
    }
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/class-registry.js

class ClassRegistry extends Registry {
    constructor() {
        super(c => c.name);
        this.classToAllowedProps = new Map();
    }
    register(value, options) {
        if (typeof options === 'object') {
            if (options.allowProps) {
                this.classToAllowedProps.set(value, options.allowProps);
            }
            super.register(value, options.identifier);
        }
        else {
            super.register(value, options);
        }
    }
    getAllowedProps(value) {
        return this.classToAllowedProps.get(value);
    }
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/util.js
function valuesOfObj(record) {
    if ('values' in Object) {
        // eslint-disable-next-line es5/no-es6-methods
        return Object.values(record);
    }
    const values = [];
    // eslint-disable-next-line no-restricted-syntax
    for (const key in record) {
        if (record.hasOwnProperty(key)) {
            values.push(record[key]);
        }
    }
    return values;
}
function find(record, predicate) {
    const values = valuesOfObj(record);
    if ('find' in values) {
        // eslint-disable-next-line es5/no-es6-methods
        return values.find(predicate);
    }
    const valuesNotNever = values;
    for (let i = 0; i < valuesNotNever.length; i++) {
        const value = valuesNotNever[i];
        if (predicate(value)) {
            return value;
        }
    }
    return undefined;
}
function forEach(record, run) {
    Object.entries(record).forEach(([key, value]) => run(value, key));
}
function includes(arr, value) {
    return arr.indexOf(value) !== -1;
}
function findArr(record, predicate) {
    for (let i = 0; i < record.length; i++) {
        const value = record[i];
        if (predicate(value)) {
            return value;
        }
    }
    return undefined;
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/custom-transformer-registry.js

class CustomTransformerRegistry {
    constructor() {
        this.transfomers = {};
    }
    register(transformer) {
        this.transfomers[transformer.name] = transformer;
    }
    findApplicable(v) {
        return find(this.transfomers, transformer => transformer.isApplicable(v));
    }
    findByName(name) {
        return this.transfomers[name];
    }
}

;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/is.js
const getType = (payload) => Object.prototype.toString.call(payload).slice(8, -1);
const isUndefined = (payload) => typeof payload === 'undefined';
const isNull = (payload) => payload === null;
const isPlainObject = (payload) => {
    if (typeof payload !== 'object' || payload === null)
        return false;
    if (payload === Object.prototype)
        return false;
    if (Object.getPrototypeOf(payload) === null)
        return true;
    return Object.getPrototypeOf(payload) === Object.prototype;
};
const isEmptyObject = (payload) => isPlainObject(payload) && Object.keys(payload).length === 0;
const isArray = (payload) => Array.isArray(payload);
const isString = (payload) => typeof payload === 'string';
const is_isNumber = (payload) => typeof payload === 'number' && !isNaN(payload);
const isBoolean = (payload) => typeof payload === 'boolean';
const isRegExp = (payload) => payload instanceof RegExp;
const isMap = (payload) => payload instanceof Map;
const isSet = (payload) => payload instanceof Set;
const isSymbol = (payload) => getType(payload) === 'Symbol';
const isDate = (payload) => payload instanceof Date && !isNaN(payload.valueOf());
const isError = (payload) => payload instanceof Error;
const isNaNValue = (payload) => typeof payload === 'number' && isNaN(payload);
const isPrimitive = (payload) => isBoolean(payload) ||
    isNull(payload) ||
    isUndefined(payload) ||
    is_isNumber(payload) ||
    isString(payload) ||
    isSymbol(payload);
const isBigint = (payload) => typeof payload === 'bigint';
const isInfinite = (payload) => payload === Infinity || payload === -Infinity;
const isTypedArray = (payload) => ArrayBuffer.isView(payload) && !(payload instanceof DataView);
const isURL = (payload) => payload instanceof URL;

;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/pathstringifier.js
const escapeKey = (key) => key.replace(/\./g, '\\.');
const stringifyPath = (path) => path
    .map(String)
    .map(escapeKey)
    .join('.');
const parsePath = (string) => {
    const result = [];
    let segment = '';
    for (let i = 0; i < string.length; i++) {
        let char = string.charAt(i);
        const isEscapedDot = char === '\\' && string.charAt(i + 1) === '.';
        if (isEscapedDot) {
            segment += '.';
            i++;
            continue;
        }
        const isEndOfSegment = char === '.';
        if (isEndOfSegment) {
            result.push(segment);
            segment = '';
            continue;
        }
        segment += char;
    }
    const lastSegment = segment;
    result.push(lastSegment);
    return result;
};

;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/transformer.js


function simpleTransformation(isApplicable, annotation, transform, untransform) {
    return {
        isApplicable,
        annotation,
        transform,
        untransform,
    };
}
const simpleRules = [
    simpleTransformation(isUndefined, 'undefined', () => null, () => undefined),
    simpleTransformation(isBigint, 'bigint', v => v.toString(), v => {
        if (typeof BigInt !== 'undefined') {
            return BigInt(v);
        }
        console.error('Please add a BigInt polyfill.');
        return v;
    }),
    simpleTransformation(isDate, 'Date', v => v.toISOString(), v => new Date(v)),
    simpleTransformation(isError, 'Error', (v, superJson) => {
        const baseError = {
            name: v.name,
            message: v.message,
        };
        superJson.allowedErrorProps.forEach(prop => {
            baseError[prop] = v[prop];
        });
        return baseError;
    }, (v, superJson) => {
        const e = new Error(v.message);
        e.name = v.name;
        e.stack = v.stack;
        superJson.allowedErrorProps.forEach(prop => {
            e[prop] = v[prop];
        });
        return e;
    }),
    simpleTransformation(isRegExp, 'regexp', v => '' + v, regex => {
        const body = regex.slice(1, regex.lastIndexOf('/'));
        const flags = regex.slice(regex.lastIndexOf('/') + 1);
        return new RegExp(body, flags);
    }),
    simpleTransformation(isSet, 'set', 
    // (sets only exist in es6+)
    // eslint-disable-next-line es5/no-es6-methods
    v => [...v.values()], v => new Set(v)),
    simpleTransformation(isMap, 'map', v => [...v.entries()], v => new Map(v)),
    simpleTransformation((v) => isNaNValue(v) || isInfinite(v), 'number', v => {
        if (isNaNValue(v)) {
            return 'NaN';
        }
        if (v > 0) {
            return 'Infinity';
        }
        else {
            return '-Infinity';
        }
    }, Number),
    simpleTransformation((v) => v === 0 && 1 / v === -Infinity, 'number', () => {
        return '-0';
    }, Number),
    simpleTransformation(isURL, 'URL', v => v.toString(), v => new URL(v)),
];
function compositeTransformation(isApplicable, annotation, transform, untransform) {
    return {
        isApplicable,
        annotation,
        transform,
        untransform,
    };
}
const symbolRule = compositeTransformation((s, superJson) => {
    if (isSymbol(s)) {
        const isRegistered = !!superJson.symbolRegistry.getIdentifier(s);
        return isRegistered;
    }
    return false;
}, (s, superJson) => {
    const identifier = superJson.symbolRegistry.getIdentifier(s);
    return ['symbol', identifier];
}, v => v.description, (_, a, superJson) => {
    const value = superJson.symbolRegistry.getValue(a[1]);
    if (!value) {
        throw new Error('Trying to deserialize unknown symbol');
    }
    return value;
});
const constructorToName = [
    Int8Array,
    Uint8Array,
    Int16Array,
    Uint16Array,
    Int32Array,
    Uint32Array,
    Float32Array,
    Float64Array,
    Uint8ClampedArray,
].reduce((obj, ctor) => {
    obj[ctor.name] = ctor;
    return obj;
}, {});
const typedArrayRule = compositeTransformation(isTypedArray, v => ['typed-array', v.constructor.name], v => [...v], (v, a) => {
    const ctor = constructorToName[a[1]];
    if (!ctor) {
        throw new Error('Trying to deserialize unknown typed array');
    }
    return new ctor(v);
});
function isInstanceOfRegisteredClass(potentialClass, superJson) {
    if (potentialClass?.constructor) {
        const isRegistered = !!superJson.classRegistry.getIdentifier(potentialClass.constructor);
        return isRegistered;
    }
    return false;
}
const classRule = compositeTransformation(isInstanceOfRegisteredClass, (clazz, superJson) => {
    const identifier = superJson.classRegistry.getIdentifier(clazz.constructor);
    return ['class', identifier];
}, (clazz, superJson) => {
    const allowedProps = superJson.classRegistry.getAllowedProps(clazz.constructor);
    if (!allowedProps) {
        return { ...clazz };
    }
    const result = {};
    allowedProps.forEach(prop => {
        result[prop] = clazz[prop];
    });
    return result;
}, (v, a, superJson) => {
    const clazz = superJson.classRegistry.getValue(a[1]);
    if (!clazz) {
        throw new Error('Trying to deserialize unknown class - check https://github.com/blitz-js/superjson/issues/116#issuecomment-773996564');
    }
    return Object.assign(Object.create(clazz.prototype), v);
});
const customRule = compositeTransformation((value, superJson) => {
    return !!superJson.customTransformerRegistry.findApplicable(value);
}, (value, superJson) => {
    const transformer = superJson.customTransformerRegistry.findApplicable(value);
    return ['custom', transformer.name];
}, (value, superJson) => {
    const transformer = superJson.customTransformerRegistry.findApplicable(value);
    return transformer.serialize(value);
}, (v, a, superJson) => {
    const transformer = superJson.customTransformerRegistry.findByName(a[1]);
    if (!transformer) {
        throw new Error('Trying to deserialize unknown custom value');
    }
    return transformer.deserialize(v);
});
const compositeRules = [classRule, symbolRule, customRule, typedArrayRule];
const transformValue = (value, superJson) => {
    const applicableCompositeRule = findArr(compositeRules, rule => rule.isApplicable(value, superJson));
    if (applicableCompositeRule) {
        return {
            value: applicableCompositeRule.transform(value, superJson),
            type: applicableCompositeRule.annotation(value, superJson),
        };
    }
    const applicableSimpleRule = findArr(simpleRules, rule => rule.isApplicable(value, superJson));
    if (applicableSimpleRule) {
        return {
            value: applicableSimpleRule.transform(value, superJson),
            type: applicableSimpleRule.annotation,
        };
    }
    return undefined;
};
const simpleRulesByAnnotation = {};
simpleRules.forEach(rule => {
    simpleRulesByAnnotation[rule.annotation] = rule;
});
const untransformValue = (json, type, superJson) => {
    if (isArray(type)) {
        switch (type[0]) {
            case 'symbol':
                return symbolRule.untransform(json, type, superJson);
            case 'class':
                return classRule.untransform(json, type, superJson);
            case 'custom':
                return customRule.untransform(json, type, superJson);
            case 'typed-array':
                return typedArrayRule.untransform(json, type, superJson);
            default:
                throw new Error('Unknown transformation: ' + type);
        }
    }
    else {
        const transformation = simpleRulesByAnnotation[type];
        if (!transformation) {
            throw new Error('Unknown transformation: ' + type);
        }
        return transformation.untransform(json, superJson);
    }
};

;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/accessDeep.js


const getNthKey = (value, n) => {
    const keys = value.keys();
    while (n > 0) {
        keys.next();
        n--;
    }
    return keys.next().value;
};
function validatePath(path) {
    if (includes(path, '__proto__')) {
        throw new Error('__proto__ is not allowed as a property');
    }
    if (includes(path, 'prototype')) {
        throw new Error('prototype is not allowed as a property');
    }
    if (includes(path, 'constructor')) {
        throw new Error('constructor is not allowed as a property');
    }
}
const getDeep = (object, path) => {
    validatePath(path);
    for (let i = 0; i < path.length; i++) {
        const key = path[i];
        if (isSet(object)) {
            object = getNthKey(object, +key);
        }
        else if (isMap(object)) {
            const row = +key;
            const type = +path[++i] === 0 ? 'key' : 'value';
            const keyOfRow = getNthKey(object, row);
            switch (type) {
                case 'key':
                    object = keyOfRow;
                    break;
                case 'value':
                    object = object.get(keyOfRow);
                    break;
            }
        }
        else {
            object = object[key];
        }
    }
    return object;
};
const setDeep = (object, path, mapper) => {
    validatePath(path);
    if (path.length === 0) {
        return mapper(object);
    }
    let parent = object;
    for (let i = 0; i < path.length - 1; i++) {
        const key = path[i];
        if (isArray(parent)) {
            const index = +key;
            parent = parent[index];
        }
        else if (isPlainObject(parent)) {
            parent = parent[key];
        }
        else if (isSet(parent)) {
            const row = +key;
            parent = getNthKey(parent, row);
        }
        else if (isMap(parent)) {
            const isEnd = i === path.length - 2;
            if (isEnd) {
                break;
            }
            const row = +key;
            const type = +path[++i] === 0 ? 'key' : 'value';
            const keyOfRow = getNthKey(parent, row);
            switch (type) {
                case 'key':
                    parent = keyOfRow;
                    break;
                case 'value':
                    parent = parent.get(keyOfRow);
                    break;
            }
        }
    }
    const lastKey = path[path.length - 1];
    if (isArray(parent)) {
        parent[+lastKey] = mapper(parent[+lastKey]);
    }
    else if (isPlainObject(parent)) {
        parent[lastKey] = mapper(parent[lastKey]);
    }
    if (isSet(parent)) {
        const oldValue = getNthKey(parent, +lastKey);
        const newValue = mapper(oldValue);
        if (oldValue !== newValue) {
            parent.delete(oldValue);
            parent.add(newValue);
        }
    }
    if (isMap(parent)) {
        const row = +path[path.length - 2];
        const keyToRow = getNthKey(parent, row);
        const type = +lastKey === 0 ? 'key' : 'value';
        switch (type) {
            case 'key': {
                const newKey = mapper(keyToRow);
                parent.set(newKey, parent.get(keyToRow));
                if (newKey !== keyToRow) {
                    parent.delete(keyToRow);
                }
                break;
            }
            case 'value': {
                parent.set(keyToRow, mapper(parent.get(keyToRow)));
                break;
            }
        }
    }
    return object;
};

;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/plainer.js






function traverse(tree, walker, origin = []) {
    if (!tree) {
        return;
    }
    if (!isArray(tree)) {
        forEach(tree, (subtree, key) => traverse(subtree, walker, [...origin, ...parsePath(key)]));
        return;
    }
    const [nodeValue, children] = tree;
    if (children) {
        forEach(children, (child, key) => {
            traverse(child, walker, [...origin, ...parsePath(key)]);
        });
    }
    walker(nodeValue, origin);
}
function applyValueAnnotations(plain, annotations, superJson) {
    traverse(annotations, (type, path) => {
        plain = setDeep(plain, path, v => untransformValue(v, type, superJson));
    });
    return plain;
}
function applyReferentialEqualityAnnotations(plain, annotations) {
    function apply(identicalPaths, path) {
        const object = getDeep(plain, parsePath(path));
        identicalPaths.map(parsePath).forEach(identicalObjectPath => {
            plain = setDeep(plain, identicalObjectPath, () => object);
        });
    }
    if (isArray(annotations)) {
        const [root, other] = annotations;
        root.forEach(identicalPath => {
            plain = setDeep(plain, parsePath(identicalPath), () => plain);
        });
        if (other) {
            forEach(other, apply);
        }
    }
    else {
        forEach(annotations, apply);
    }
    return plain;
}
const isDeep = (object, superJson) => isPlainObject(object) ||
    isArray(object) ||
    isMap(object) ||
    isSet(object) ||
    isInstanceOfRegisteredClass(object, superJson);
function addIdentity(object, path, identities) {
    const existingSet = identities.get(object);
    if (existingSet) {
        existingSet.push(path);
    }
    else {
        identities.set(object, [path]);
    }
}
function generateReferentialEqualityAnnotations(identitites, dedupe) {
    const result = {};
    let rootEqualityPaths = undefined;
    identitites.forEach(paths => {
        if (paths.length <= 1) {
            return;
        }
        // if we're not deduping, all of these objects continue existing.
        // putting the shortest path first makes it easier to parse for humans
        // if we're deduping though, only the first entry will still exist, so we can't do this optimisation.
        if (!dedupe) {
            paths = paths
                .map(path => path.map(String))
                .sort((a, b) => a.length - b.length);
        }
        const [representativePath, ...identicalPaths] = paths;
        if (representativePath.length === 0) {
            rootEqualityPaths = identicalPaths.map(stringifyPath);
        }
        else {
            result[stringifyPath(representativePath)] = identicalPaths.map(stringifyPath);
        }
    });
    if (rootEqualityPaths) {
        if (isEmptyObject(result)) {
            return [rootEqualityPaths];
        }
        else {
            return [rootEqualityPaths, result];
        }
    }
    else {
        return isEmptyObject(result) ? undefined : result;
    }
}
const plainer_walker = (object, identities, superJson, dedupe, path = [], objectsInThisPath = [], seenObjects = new Map()) => {
    const primitive = isPrimitive(object);
    if (!primitive) {
        addIdentity(object, path, identities);
        const seen = seenObjects.get(object);
        if (seen) {
            // short-circuit result if we've seen this object before
            return dedupe
                ? {
                    transformedValue: null,
                }
                : seen;
        }
    }
    if (!isDeep(object, superJson)) {
        const transformed = transformValue(object, superJson);
        const result = transformed
            ? {
                transformedValue: transformed.value,
                annotations: [transformed.type],
            }
            : {
                transformedValue: object,
            };
        if (!primitive) {
            seenObjects.set(object, result);
        }
        return result;
    }
    if (includes(objectsInThisPath, object)) {
        // prevent circular references
        return {
            transformedValue: null,
        };
    }
    const transformationResult = transformValue(object, superJson);
    const transformed = transformationResult?.value ?? object;
    const transformedValue = isArray(transformed) ? [] : {};
    const innerAnnotations = {};
    forEach(transformed, (value, index) => {
        if (index === '__proto__' ||
            index === 'constructor' ||
            index === 'prototype') {
            throw new Error(`Detected property ${index}. This is a prototype pollution risk, please remove it from your object.`);
        }
        const recursiveResult = plainer_walker(value, identities, superJson, dedupe, [...path, index], [...objectsInThisPath, object], seenObjects);
        transformedValue[index] = recursiveResult.transformedValue;
        if (isArray(recursiveResult.annotations)) {
            innerAnnotations[index] = recursiveResult.annotations;
        }
        else if (isPlainObject(recursiveResult.annotations)) {
            forEach(recursiveResult.annotations, (tree, key) => {
                innerAnnotations[escapeKey(index) + '.' + key] = tree;
            });
        }
    });
    const result = isEmptyObject(innerAnnotations)
        ? {
            transformedValue,
            annotations: !!transformationResult
                ? [transformationResult.type]
                : undefined,
        }
        : {
            transformedValue,
            annotations: !!transformationResult
                ? [transformationResult.type, innerAnnotations]
                : innerAnnotations,
        };
    if (!primitive) {
        seenObjects.set(object, result);
    }
    return result;
};

;// CONCATENATED MODULE: ./node_modules/.pnpm/is-what@4.1.16/node_modules/is-what/dist/index.js
function dist_getType(payload) {
  return Object.prototype.toString.call(payload).slice(8, -1);
}

function isAnyObject(payload) {
  return dist_getType(payload) === "Object";
}

function dist_isArray(payload) {
  return dist_getType(payload) === "Array";
}

function isBlob(payload) {
  return dist_getType(payload) === "Blob";
}

function dist_isBoolean(payload) {
  return dist_getType(payload) === "Boolean";
}

function dist_isDate(payload) {
  return dist_getType(payload) === "Date" && !isNaN(payload);
}

function isEmptyArray(payload) {
  return dist_isArray(payload) && payload.length === 0;
}

function dist_isPlainObject(payload) {
  if (dist_getType(payload) !== "Object")
    return false;
  const prototype = Object.getPrototypeOf(payload);
  return !!prototype && prototype.constructor === Object && prototype === Object.prototype;
}

function dist_isEmptyObject(payload) {
  return dist_isPlainObject(payload) && Object.keys(payload).length === 0;
}

function isEmptyString(payload) {
  return payload === "";
}

function dist_isError(payload) {
  return dist_getType(payload) === "Error" || payload instanceof Error;
}

function isFile(payload) {
  return dist_getType(payload) === "File";
}

function isFullArray(payload) {
  return dist_isArray(payload) && payload.length > 0;
}

function isFullObject(payload) {
  return dist_isPlainObject(payload) && Object.keys(payload).length > 0;
}

function dist_isString(payload) {
  return dist_getType(payload) === "String";
}

function isFullString(payload) {
  return dist_isString(payload) && payload !== "";
}

function isFunction(payload) {
  return typeof payload === "function";
}

function isType(payload, type) {
  if (!(type instanceof Function)) {
    throw new TypeError("Type must be a function");
  }
  if (!Object.prototype.hasOwnProperty.call(type, "prototype")) {
    throw new TypeError("Type is not a class");
  }
  const name = type.name;
  return dist_getType(payload) === name || Boolean(payload && payload.constructor === type);
}

function isInstanceOf(value, classOrClassName) {
  if (typeof classOrClassName === "function") {
    for (let p = value; p; p = Object.getPrototypeOf(p)) {
      if (isType(p, classOrClassName)) {
        return true;
      }
    }
    return false;
  } else {
    for (let p = value; p; p = Object.getPrototypeOf(p)) {
      if (dist_getType(p) === classOrClassName) {
        return true;
      }
    }
    return false;
  }
}

function dist_isMap(payload) {
  return dist_getType(payload) === "Map";
}

function dist_isNaNValue(payload) {
  return dist_getType(payload) === "Number" && isNaN(payload);
}

function dist_isNumber(payload) {
  return dist_getType(payload) === "Number" && !isNaN(payload);
}

function isNegativeNumber(payload) {
  return dist_isNumber(payload) && payload < 0;
}

function dist_isNull(payload) {
  return dist_getType(payload) === "Null";
}

function isOneOf(a, b, c, d, e) {
  return (value) => a(value) || b(value) || !!c && c(value) || !!d && d(value) || !!e && e(value);
}

function dist_isUndefined(payload) {
  return dist_getType(payload) === "Undefined";
}

const isNullOrUndefined = isOneOf(dist_isNull, dist_isUndefined);

function isObject(payload) {
  return dist_isPlainObject(payload);
}

function isObjectLike(payload) {
  return isAnyObject(payload);
}

function isPositiveNumber(payload) {
  return dist_isNumber(payload) && payload > 0;
}

function dist_isSymbol(payload) {
  return dist_getType(payload) === "Symbol";
}

function dist_isPrimitive(payload) {
  return dist_isBoolean(payload) || dist_isNull(payload) || dist_isUndefined(payload) || dist_isNumber(payload) || dist_isString(payload) || dist_isSymbol(payload);
}

function isPromise(payload) {
  return dist_getType(payload) === "Promise";
}

function dist_isRegExp(payload) {
  return dist_getType(payload) === "RegExp";
}

function dist_isSet(payload) {
  return dist_getType(payload) === "Set";
}

function isWeakMap(payload) {
  return dist_getType(payload) === "WeakMap";
}

function isWeakSet(payload) {
  return dist_getType(payload) === "WeakSet";
}



;// CONCATENATED MODULE: ./node_modules/.pnpm/copy-anything@3.0.5/node_modules/copy-anything/dist/index.js


function assignProp(carry, key, newVal, originalObject, includeNonenumerable) {
  const propType = {}.propertyIsEnumerable.call(originalObject, key) ? "enumerable" : "nonenumerable";
  if (propType === "enumerable")
    carry[key] = newVal;
  if (includeNonenumerable && propType === "nonenumerable") {
    Object.defineProperty(carry, key, {
      value: newVal,
      enumerable: false,
      writable: true,
      configurable: true
    });
  }
}
function copy(target, options = {}) {
  if (dist_isArray(target)) {
    return target.map((item) => copy(item, options));
  }
  if (!dist_isPlainObject(target)) {
    return target;
  }
  const props = Object.getOwnPropertyNames(target);
  const symbols = Object.getOwnPropertySymbols(target);
  return [...props, ...symbols].reduce((carry, key) => {
    if (dist_isArray(options.props) && !options.props.includes(key)) {
      return carry;
    }
    const val = target[key];
    const newVal = copy(val, options);
    assignProp(carry, key, newVal, target, options.nonenumerable);
    return carry;
  }, {});
}



;// CONCATENATED MODULE: ./node_modules/.pnpm/superjson@2.2.1/node_modules/superjson/dist/index.js





class SuperJSON {
    /**
     * @param dedupeReferentialEqualities  If true, SuperJSON will make sure only one instance of referentially equal objects are serialized and the rest are replaced with `null`.
     */
    constructor({ dedupe = false, } = {}) {
        this.classRegistry = new ClassRegistry();
        this.symbolRegistry = new Registry(s => s.description ?? '');
        this.customTransformerRegistry = new CustomTransformerRegistry();
        this.allowedErrorProps = [];
        this.dedupe = dedupe;
    }
    serialize(object) {
        const identities = new Map();
        const output = plainer_walker(object, identities, this, this.dedupe);
        const res = {
            json: output.transformedValue,
        };
        if (output.annotations) {
            res.meta = {
                ...res.meta,
                values: output.annotations,
            };
        }
        const equalityAnnotations = generateReferentialEqualityAnnotations(identities, this.dedupe);
        if (equalityAnnotations) {
            res.meta = {
                ...res.meta,
                referentialEqualities: equalityAnnotations,
            };
        }
        return res;
    }
    deserialize(payload) {
        const { json, meta } = payload;
        let result = copy(json);
        if (meta?.values) {
            result = applyValueAnnotations(result, meta.values, this);
        }
        if (meta?.referentialEqualities) {
            result = applyReferentialEqualityAnnotations(result, meta.referentialEqualities);
        }
        return result;
    }
    stringify(object) {
        return JSON.stringify(this.serialize(object));
    }
    parse(string) {
        return this.deserialize(JSON.parse(string));
    }
    registerClass(v, options) {
        this.classRegistry.register(v, options);
    }
    registerSymbol(v, identifier) {
        this.symbolRegistry.register(v, identifier);
    }
    registerCustom(transformer, name) {
        this.customTransformerRegistry.register({
            name,
            ...transformer,
        });
    }
    allowErrorProps(...props) {
        this.allowedErrorProps.push(...props);
    }
}
SuperJSON.defaultInstance = new SuperJSON();
SuperJSON.serialize = SuperJSON.defaultInstance.serialize.bind(SuperJSON.defaultInstance);
SuperJSON.deserialize = SuperJSON.defaultInstance.deserialize.bind(SuperJSON.defaultInstance);
SuperJSON.stringify = SuperJSON.defaultInstance.stringify.bind(SuperJSON.defaultInstance);
SuperJSON.parse = SuperJSON.defaultInstance.parse.bind(SuperJSON.defaultInstance);
SuperJSON.registerClass = SuperJSON.defaultInstance.registerClass.bind(SuperJSON.defaultInstance);
SuperJSON.registerSymbol = SuperJSON.defaultInstance.registerSymbol.bind(SuperJSON.defaultInstance);
SuperJSON.registerCustom = SuperJSON.defaultInstance.registerCustom.bind(SuperJSON.defaultInstance);
SuperJSON.allowErrorProps = SuperJSON.defaultInstance.allowErrorProps.bind(SuperJSON.defaultInstance);

const serialize = SuperJSON.serialize;
const deserialize = SuperJSON.deserialize;
const stringify = SuperJSON.stringify;
const dist_parse = SuperJSON.parse;
const registerClass = SuperJSON.registerClass;
const registerCustom = SuperJSON.registerCustom;
const registerSymbol = SuperJSON.registerSymbol;
const allowErrorProps = SuperJSON.allowErrorProps;

;// CONCATENATED MODULE: ./node_modules/.pnpm/idb@8.0.2/node_modules/idb/build/index.js
const instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);

let idbProxyableTypes;
let cursorAdvanceMethods;
// This is a function to prevent it throwing up in node environments.
function getIdbProxyableTypes() {
    return (idbProxyableTypes ||
        (idbProxyableTypes = [
            IDBDatabase,
            IDBObjectStore,
            IDBIndex,
            IDBCursor,
            IDBTransaction,
        ]));
}
// This is a function to prevent it throwing up in node environments.
function getCursorAdvanceMethods() {
    return (cursorAdvanceMethods ||
        (cursorAdvanceMethods = [
            IDBCursor.prototype.advance,
            IDBCursor.prototype.continue,
            IDBCursor.prototype.continuePrimaryKey,
        ]));
}
const transactionDoneMap = new WeakMap();
const transformCache = new WeakMap();
const reverseTransformCache = new WeakMap();
function promisifyRequest(request) {
    const promise = new Promise((resolve, reject) => {
        const unlisten = () => {
            request.removeEventListener('success', success);
            request.removeEventListener('error', error);
        };
        const success = () => {
            resolve(wrap(request.result));
            unlisten();
        };
        const error = () => {
            reject(request.error);
            unlisten();
        };
        request.addEventListener('success', success);
        request.addEventListener('error', error);
    });
    // This mapping exists in reverseTransformCache but doesn't exist in transformCache. This
    // is because we create many promises from a single IDBRequest.
    reverseTransformCache.set(promise, request);
    return promise;
}
function cacheDonePromiseForTransaction(tx) {
    // Early bail if we've already created a done promise for this transaction.
    if (transactionDoneMap.has(tx))
        return;
    const done = new Promise((resolve, reject) => {
        const unlisten = () => {
            tx.removeEventListener('complete', complete);
            tx.removeEventListener('error', error);
            tx.removeEventListener('abort', error);
        };
        const complete = () => {
            resolve();
            unlisten();
        };
        const error = () => {
            reject(tx.error || new DOMException('AbortError', 'AbortError'));
            unlisten();
        };
        tx.addEventListener('complete', complete);
        tx.addEventListener('error', error);
        tx.addEventListener('abort', error);
    });
    // Cache it for later retrieval.
    transactionDoneMap.set(tx, done);
}
let idbProxyTraps = {
    get(target, prop, receiver) {
        if (target instanceof IDBTransaction) {
            // Special handling for transaction.done.
            if (prop === 'done')
                return transactionDoneMap.get(target);
            // Make tx.store return the only store in the transaction, or undefined if there are many.
            if (prop === 'store') {
                return receiver.objectStoreNames[1]
                    ? undefined
                    : receiver.objectStore(receiver.objectStoreNames[0]);
            }
        }
        // Else transform whatever we get back.
        return wrap(target[prop]);
    },
    set(target, prop, value) {
        target[prop] = value;
        return true;
    },
    has(target, prop) {
        if (target instanceof IDBTransaction &&
            (prop === 'done' || prop === 'store')) {
            return true;
        }
        return prop in target;
    },
};
function replaceTraps(callback) {
    idbProxyTraps = callback(idbProxyTraps);
}
function wrapFunction(func) {
    // Due to expected object equality (which is enforced by the caching in `wrap`), we
    // only create one new func per func.
    // Cursor methods are special, as the behaviour is a little more different to standard IDB. In
    // IDB, you advance the cursor and wait for a new 'success' on the IDBRequest that gave you the
    // cursor. It's kinda like a promise that can resolve with many values. That doesn't make sense
    // with real promises, so each advance methods returns a new promise for the cursor object, or
    // undefined if the end of the cursor has been reached.
    if (getCursorAdvanceMethods().includes(func)) {
        return function (...args) {
            // Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
            // the original object.
            func.apply(unwrap(this), args);
            return wrap(this.request);
        };
    }
    return function (...args) {
        // Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
        // the original object.
        return wrap(func.apply(unwrap(this), args));
    };
}
function transformCachableValue(value) {
    if (typeof value === 'function')
        return wrapFunction(value);
    // This doesn't return, it just creates a 'done' promise for the transaction,
    // which is later returned for transaction.done (see idbObjectHandler).
    if (value instanceof IDBTransaction)
        cacheDonePromiseForTransaction(value);
    if (instanceOfAny(value, getIdbProxyableTypes()))
        return new Proxy(value, idbProxyTraps);
    // Return the same value back if we're not going to transform it.
    return value;
}
function wrap(value) {
    // We sometimes generate multiple promises from a single IDBRequest (eg when cursoring), because
    // IDB is weird and a single IDBRequest can yield many responses, so these can't be cached.
    if (value instanceof IDBRequest)
        return promisifyRequest(value);
    // If we've already transformed this value before, reuse the transformed value.
    // This is faster, but it also provides object equality.
    if (transformCache.has(value))
        return transformCache.get(value);
    const newValue = transformCachableValue(value);
    // Not all types are transformed.
    // These may be primitive types, so they can't be WeakMap keys.
    if (newValue !== value) {
        transformCache.set(value, newValue);
        reverseTransformCache.set(newValue, value);
    }
    return newValue;
}
const unwrap = (value) => reverseTransformCache.get(value);

/**
 * Open a database.
 *
 * @param name Name of the database.
 * @param version Schema version.
 * @param callbacks Additional callbacks.
 */
function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
    const request = indexedDB.open(name, version);
    const openPromise = wrap(request);
    if (upgrade) {
        request.addEventListener('upgradeneeded', (event) => {
            upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
        });
    }
    if (blocked) {
        request.addEventListener('blocked', (event) => blocked(
        // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion, event.newVersion, event));
    }
    openPromise
        .then((db) => {
        if (terminated)
            db.addEventListener('close', () => terminated());
        if (blocking) {
            db.addEventListener('versionchange', (event) => blocking(event.oldVersion, event.newVersion, event));
        }
    })
        .catch(() => { });
    return openPromise;
}
/**
 * Delete a database.
 *
 * @param name Name of the database.
 */
function deleteDB(name, { blocked } = {}) {
    const request = indexedDB.deleteDatabase(name);
    if (blocked) {
        request.addEventListener('blocked', (event) => blocked(
        // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion, event));
    }
    return wrap(request).then(() => undefined);
}

const readMethods = ['get', 'getKey', 'getAll', 'getAllKeys', 'count'];
const writeMethods = ['put', 'add', 'delete', 'clear'];
const cachedMethods = new Map();
function getMethod(target, prop) {
    if (!(target instanceof IDBDatabase &&
        !(prop in target) &&
        typeof prop === 'string')) {
        return;
    }
    if (cachedMethods.get(prop))
        return cachedMethods.get(prop);
    const targetFuncName = prop.replace(/FromIndex$/, '');
    const useIndex = prop !== targetFuncName;
    const isWrite = writeMethods.includes(targetFuncName);
    if (
    // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) ||
        !(isWrite || readMethods.includes(targetFuncName))) {
        return;
    }
    const method = async function (storeName, ...args) {
        // isWrite ? 'readwrite' : undefined gzipps better, but fails in Edge :(
        const tx = this.transaction(storeName, isWrite ? 'readwrite' : 'readonly');
        let target = tx.store;
        if (useIndex)
            target = target.index(args.shift());
        // Must reject if op rejects.
        // If it's a write operation, must reject if tx.done rejects.
        // Must reject with op rejection first.
        // Must resolve with op value.
        // Must handle both promises (no unhandled rejections)
        return (await Promise.all([
            target[targetFuncName](...args),
            isWrite && tx.done,
        ]))[0];
    };
    cachedMethods.set(prop, method);
    return method;
}
replaceTraps((oldTraps) => ({
    ...oldTraps,
    get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
    has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop),
}));

const advanceMethodProps = ['continue', 'continuePrimaryKey', 'advance'];
const methodMap = {};
const advanceResults = new WeakMap();
const ittrProxiedCursorToOriginalProxy = new WeakMap();
const cursorIteratorTraps = {
    get(target, prop) {
        if (!advanceMethodProps.includes(prop))
            return target[prop];
        let cachedFunc = methodMap[prop];
        if (!cachedFunc) {
            cachedFunc = methodMap[prop] = function (...args) {
                advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
            };
        }
        return cachedFunc;
    },
};
async function* iterate(...args) {
    // tslint:disable-next-line:no-this-assignment
    let cursor = this;
    if (!(cursor instanceof IDBCursor)) {
        cursor = await cursor.openCursor(...args);
    }
    if (!cursor)
        return;
    cursor = cursor;
    const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
    ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
    // Map this double-proxy back to the original, so other cursor methods work.
    reverseTransformCache.set(proxiedCursor, unwrap(cursor));
    while (cursor) {
        yield proxiedCursor;
        // If one of the advancing methods was not called, call continue().
        cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
        advanceResults.delete(proxiedCursor);
    }
}
function isIteratorProp(target, prop) {
    return ((prop === Symbol.asyncIterator &&
        instanceOfAny(target, [IDBIndex, IDBObjectStore, IDBCursor])) ||
        (prop === 'iterate' && instanceOfAny(target, [IDBIndex, IDBObjectStore])));
}
replaceTraps((oldTraps) => ({
    ...oldTraps,
    get(target, prop, receiver) {
        if (isIteratorProp(target, prop))
            return iterate;
        return oldTraps.get(target, prop, receiver);
    },
    has(target, prop) {
        return isIteratorProp(target, prop) || oldTraps.has(target, prop);
    },
}));



;// CONCATENATED MODULE: ./Extension/src/background/storages/constants.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ /**
 * Name of the IndexedDB database used by the extension.
 */ const IDB_STORAGE_NAME = 'adguardIDB';
/**
 * Version of the IndexedDB database used by the extension.
 */ const IDB_STORAGE_VERSION = 1;
/**
 * Name of the object store inside the IndexedDB database.
 */ const IDB_STORE_NAME = 'defaultStore';
/**
 * Separator between a storage key prefix and a filter identifier.
 */ const FILTER_STORAGE_KEY_COMBINER = '_';
/**
 * Prefix of the storage key that contains preprocessed filter content.
 */ const FILTER_CONTENT_STORAGE_KEY = 'filterContent';
/**
 * Prefix of the storage key that contains filter conversion data.
 */ const FILTER_CONVERSION_DATA_STORAGE_KEY = 'conversionData';

;// CONCATENATED MODULE: ./Extension/src/background/storages/idb-storage.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 


/**
 * Provides a storage mechanism using IndexedDB. This class implements the
 * StorageInterface with asynchronous methods to interact with the database.
 *
 * @template Data The type of the value stored in the storage.
 */ class IDBStorage {
    /**
     * The default name of the store within the database.
     */ static DEFAULT_STORE_NAME = IDB_STORE_NAME;
    /**
     * The default version of the database.
     */ static DEFAULT_IDB_VERSION = IDB_STORAGE_VERSION;
    /**
     * The default name of the database.
     */ static DEFAULT_IDB_NAME = IDB_STORAGE_NAME;
    /**
     * Holds the instance of the IndexedDB database.
     */ db = null;
    /**
     * Promise to get IndexedDB database.
     */ dbGetterPromise = null;
    /**
     * The name of the database.
     */ name;
    /**
     * The version of the database. Used for upgrades.
     */ version;
    /**
     * The name of the store within the database.
     */ store;
    /**
     * Constructs an instance of the IDBStorage class.
     *
     * @param [name=IDBStorage.DEFAULT_IDB_NAME] The name of the database.
     * @param [version=1] The version of the database.
     * @param [store=IDBStorage.DEFAULT_STORE_NAME] The name of the store within the database.
     */ constructor(name = IDBStorage.DEFAULT_IDB_NAME, version = IDBStorage.DEFAULT_IDB_VERSION, store = IDBStorage.DEFAULT_STORE_NAME){
        this.name = name;
        this.version = version;
        this.store = store;
    }
    /**
     * Ensures the database is opened before any operations. If the database
     * is not already opened, it opens the database.
     *
     * @returns The opened database instance.
     */ async getOpenedDb() {
        if (this.db) {
            return this.db;
        }
        if (this.dbGetterPromise) {
            return this.dbGetterPromise;
        }
        this.dbGetterPromise = (async ()=>{
            this.db = await openDB(this.name, this.version, {
                upgrade: (db)=>{
                    // Make sure the store exists
                    if (!db.objectStoreNames.contains(this.store)) {
                        db.createObjectStore(this.store);
                    }
                }
            });
            this.dbGetterPromise = null;
            return this.db;
        })();
        return this.dbGetterPromise;
    }
    /**
     * Retrieves a value by key from the store.
     *
     * @param key The key of the value to retrieve.
     *
     * @returns The value associated with the key.
     */ async get(key) {
        const db = await this.getOpenedDb();
        return db.get(this.store, key);
    }
    /**
     * Sets a value in the store with the specified key.
     *
     * @param key The key under which to store the value.
     * @param value The value to store.
     */ async set(key, value) {
        const db = await this.getOpenedDb();
        await db.put(this.store, value, key);
    }
    /**
     * Removes a value from the store by key.
     *
     * @param key The key of the value to remove.
     */ async remove(key) {
        const db = await this.getOpenedDb();
        await db.delete(this.store, key);
    }
    /**
     * Atomic set operation for multiple key-value pairs.
     * This method is using transaction to ensure atomicity, if any of the operations fail,
     * the entire operation is rolled back. This helps to prevent data corruption / inconsistency.
     *
     * @param data The key-value pairs to set.
     *
     * @returns True if all operations were successful, false otherwise.
     *
     * @example
     * ```ts
     * const storage = new IDBStorage();
     * await storage.setMultiple({
     *    key1: 'value1',
     *    key2: 'value2',
     * });
     * ```
     */ async setMultiple(data) {
        const db = await this.getOpenedDb();
        const tx = db.transaction(this.store, 'readwrite');
        try {
            await Promise.all(Object.entries(data).map(([key, value])=>tx.store.put(value, key)));
            await tx.done;
        } catch (e) {
            logger_logger.error('[ext.IDBStorage.setMultiple]: error while setting multiple keys in the storage:', e);
            tx.abort();
            return false;
        }
        return true;
    }
    /**
     * Removes multiple key-value pairs from the storage.
     *
     * @param keys The keys to remove.
     *
     * @returns True if all operations were successful, false otherwise.
     */ async removeMultiple(keys) {
        const db = await this.getOpenedDb();
        const tx = db.transaction(this.store, 'readwrite');
        try {
            await Promise.all(keys.map((key)=>tx.store.delete(key)));
            await tx.done;
        } catch (e) {
            logger_logger.error('[ext.IDBStorage.removeMultiple]: error while removing multiple keys from the storage:', e);
            tx.abort();
            return false;
        }
        return true;
    }
    /**
     * Get the entire contents of the storage.
     *
     * @returns Promise that resolves with the entire contents of the storage.
     */ async entries() {
        const db = await this.getOpenedDb();
        const entries = {};
        const tx = db.transaction(this.store, 'readonly');
        // eslint-disable-next-line no-restricted-syntax
        for await (const cursor of tx.store){
            const key = String(cursor.key);
            entries[key] = cursor.value;
        }
        return entries;
    }
    /**
     * Get all keys in the storage.
     *
     * @returns Promise that resolves with all keys in the storage.
     */ async keys() {
        const db = await this.getOpenedDb();
        const idbKeys = await db.getAllKeys(this.store);
        return idbKeys.map((key)=>key.toString());
    }
    /**
     * Check if a key exists in the storage.
     *
     * @param key The key to check.
     *
     * @returns True if the key exists, false otherwise.
     */ async has(key) {
        const db = await this.getOpenedDb();
        const idbKey = await db.getKey(this.store, key);
        return idbKey !== undefined;
    }
    /**
     * Clears the storage.
     */ async clear() {
        const db = await this.getOpenedDb();
        await db.clear(this.store);
    }
}

;// CONCATENATED MODULE: ./Extension/src/background/storages/hybrid-storage.ts
/* eslint-disable @typescript-eslint/no-explicit-any */ /**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ /**
 * This file implements a hybrid storage solution that abstracts over different storage mechanisms,
 * providing a unified API for storage operations. It automatically chooses between IndexedDB storage and
 * a fallback storage mechanism based on the environment's capabilities.
 */ 




/**
 * Implements a hybrid storage mechanism that can switch between IndexedDB and a fallback storage
 * based on browser capabilities and environment constraints. This class adheres to the StorageInterface,
 * allowing for asynchronous get and set operations.
 *
 * @template Data The type of the value stored in the storage.
 */ class HybridStorage {
    /**
     * A flag indicating whether IndexedDB support has already been checked.
     */ static isIDBCapabilityChecked = false;
    /**
     * A promise that resolves to whether IndexedDB is supported in the environment.
     * This promise is used to cache the result of the support check to prevent multiple checks.
     */ static idbCapabilityCheckerPromise = null;
    /**
     * A flag that stores the result of the IndexedDB support check.
     * If true, IndexedDB is supported in the environment.
     */ static idbSupported = false;
    /**
     * Prefix for the test IndexedDB database name.
     * This test database is used to check if IndexedDB is supported in the current environment.
     */ static TEST_IDB_NAME_PREFIX = 'test_';
    /**
     * Version number for the test IndexedDB database.
     */ static TEST_IDB_VERSION = 1;
    /**
     * The key used to store metadata in SuperJSON-serialized data.
     */ static SUPERJSON_META_KEY = 'meta';
    /**
     * Holds the instance of the selected storage mechanism.
     *
     * @note We use SuperJSON to serialize and deserialize the data when using the fallback storage mechanism,
     * because it only supports storing JSON-serializable data.
     */ storage = null;
    /**
     * The storage area to use when IndexedDB is not supported.
     */ fallbackStorage;
    /**
     * Constructs an instance of the HybridStorage class.
     *
     * @param fallbackStorage The storage area to use when IndexedDB is not supported.
     */ constructor(fallbackStorage){
        this.fallbackStorage = fallbackStorage;
    }
    /**
     * Checks if the given storage is an instance of IDBStorage.
     *
     * @param storage The storage instance to check.
     *
     * @returns True if the storage is an instance of IDBStorage, false otherwise.
     */ static isIdbStorage(storage) {
        return storage instanceof IDBStorage;
    }
    /**
     * Determines the appropriate storage mechanism to use. If IndexedDB is supported, it uses IDBStorage;
     * otherwise, it falls back to a generic Storage mechanism. This selection is made once and cached
     * for subsequent operations.
     *
     * @returns The storage instance to be used for data operations.
     */ async getStorage() {
        if (this.storage) {
            return this.storage;
        }
        if (await HybridStorage.isIDBSupported()) {
            this.storage = new IDBStorage();
        } else {
            this.storage = new BrowserStorage(this.fallbackStorage);
        }
        return this.storage;
    }
    /**
     * Serializes the given data using SuperJSON.
     *
     * @param data The data to serialize.
     *
     * @returns The serialized data.
     */ static serialize = (data)=>SuperJSON.serialize(data);
    /**
     * Deserializes the given data using SuperJSON.
     *
     * @param data The data to deserialize.
     *
     * @returns The deserialized data.
     */ static deserialize = (data)=>SuperJSON.deserialize(data);
    /**
     * Checks if the given value is a SuperJSONResult.
     *
     * @param value The value to check.
     *
     * @returns True if the value is a SuperJSONResult, false otherwise.
     */ static isSuperJSONResult(value) {
        return typeof value === 'object' && value !== null && HybridStorage.SUPERJSON_META_KEY in value;
    }
    /**
     * Checks if IndexedDB is supported in the current environment.
     * This is determined by trying to open a test database; if successful, IndexedDB is supported.
     * The result of this check is cached to prevent multiple checks.
     *
     * @returns True if IndexedDB is supported, false otherwise.
     */ static async isIDBSupported() {
        if (HybridStorage.isIDBCapabilityChecked) {
            return HybridStorage.idbSupported;
        }
        if (HybridStorage.idbCapabilityCheckerPromise) {
            return HybridStorage.idbCapabilityCheckerPromise;
        }
        HybridStorage.idbCapabilityCheckerPromise = (async ()=>{
            try {
                const testDbName = `${HybridStorage.TEST_IDB_NAME_PREFIX}${nanoid()}`;
                const testDb = await openDB(testDbName, HybridStorage.TEST_IDB_VERSION);
                testDb.close();
                await deleteDB(testDbName);
                HybridStorage.idbSupported = true;
            } catch (e) {
                HybridStorage.idbSupported = false;
            }
            HybridStorage.isIDBCapabilityChecked = true;
            return HybridStorage.idbSupported;
        })();
        return HybridStorage.idbCapabilityCheckerPromise;
    }
    /**
     * Asynchronously sets a value for a given key in the selected storage mechanism.
     *
     * @param key The key under which the value is stored.
     * @param value The value to be stored.
     *
     * @returns A promise that resolves when the operation is complete.
     */ async set(key, value) {
        const storage = await this.getStorage();
        // If the selected storage mechanism is IndexedDB, we store the value as is,
        // as IndexedDB can store complex objects.
        if (HybridStorage.isIdbStorage(storage)) {
            return storage.set(key, value);
        }
        const serialized = HybridStorage.serialize(value);
        // If the serialized value contains a meta key, it means that the value provided
        // contains special data that are not JSON-serializable and require SuperJSON serialization,
        // like typed arrays, dates, and other complex objects.
        // In this case, we store the SuperJSON-serialized value.
        if (HybridStorage.SUPERJSON_META_KEY in serialized) {
            return storage.set(key, serialized);
        }
        // If the serialized value does not contain a meta key, it means that the value
        // provided was a primitive value or a plain object that is JSON-serializable,
        // and it does not contain any special data that requires SuperJSON serialization.
        // In this case, we store the value as is.
        return storage.set(key, value);
    }
    /**
     * Asynchronously retrieves the value for a given key from the selected storage mechanism.
     *
     * @param key The key whose value is to be retrieved.
     *
     * @returns A promise that resolves with the retrieved value, or undefined if the key does not exist.
     */ async get(key) {
        const storage = await this.getStorage();
        // If the selected storage mechanism is IndexedDB, we return the value as is,
        // as IndexedDB can store complex objects.
        if (HybridStorage.isIdbStorage(storage)) {
            return storage.get(key);
        }
        const value = await storage.get(key);
        // Do not attempt to deserialize undefined values.
        if (value === undefined) {
            return undefined;
        }
        // If the value is a SuperJSON-serialized object, we need to deserialize it.
        if (HybridStorage.isSuperJSONResult(value)) {
            return HybridStorage.deserialize(value);
        }
        // Otherwise, we return the value as is.
        return value;
    }
    /**
     * Asynchronously removes the value for a given key from the selected storage mechanism.
     *
     * @param key The key whose value is to be removed.
     */ async remove(key) {
        const storage = await this.getStorage();
        await storage.remove(key);
    }
    /**
     * Atomic set operation for multiple key-value pairs.
     * This method are using transaction to ensure atomicity, if any of the operations fail,
     * the entire operation is rolled back. This helps to prevent data corruption / inconsistency.
     *
     * @param data The key-value pairs to set.
     *
     * @returns True if all operations were successful, false otherwise.
     *
     * @example
     * ```ts
     * const storage = new HybridStorage();
     * await storage.setMultiple({
     *    key1: 'value1',
     *    key2: 'value2',
     * });
     * ```
     */ async setMultiple(data) {
        const storage = await this.getStorage();
        if (HybridStorage.isIdbStorage(storage)) {
            return await storage.setMultiple(data) ?? false;
        }
        const cloneData = Object.entries(data).reduce((acc, [key, value])=>{
            const serialized = SuperJSON.serialize(value);
            // If the serialized value contains a meta key, it means that the value provided
            // contains special data that are not JSON-serializable and require SuperJSON serialization,
            // like typed arrays, dates, and other complex objects.
            // In this case, we store the SuperJSON-serialized value.
            if (HybridStorage.SUPERJSON_META_KEY in serialized) {
                acc[key] = serialized;
                return acc;
            }
            // If the serialized value does not contain a meta key, it means that the value
            // provided was a primitive value or a plain object that is JSON-serializable,
            // and it does not contain any special data that requires SuperJSON serialization.
            // In this case, we store the value as is.
            acc[key] = value;
            return acc;
        }, {});
        return await storage.setMultiple(cloneData) ?? false;
    }
    /**
     * Removes multiple key-value pairs from the storage.
     *
     * @param keys The keys to remove.
     *
     * @returns True if all operations were successful, false otherwise.
     */ async removeMultiple(keys) {
        const storage = await this.getStorage();
        return await storage.removeMultiple(keys) ?? false;
    }
    /**
     * Get the entire contents of the storage.
     *
     * @returns Promise that resolves with the entire contents of the storage.
     */ async entries() {
        const storage = await this.getStorage();
        if (HybridStorage.isIdbStorage(storage)) {
            return storage.entries();
        }
        const entries = await storage.entries();
        return Object.entries(entries).reduce((acc, [key, value])=>{
            acc[key] = HybridStorage.isSuperJSONResult(value) ? HybridStorage.deserialize(value) : value;
            return acc;
        }, {});
    }
    /**
     * Get all keys from the storage.
     *
     * @returns Promise that resolves with all keys from the storage.
     */ async keys() {
        const storage = await this.getStorage();
        return storage.keys();
    }
    /**
     * Check if a key exists in the storage.
     *
     * @param key The key to check.
     *
     * @returns True if the key exists, false otherwise.
     */ async has(key) {
        const storage = await this.getStorage();
        return storage.has(key);
    }
    /**
     * Clears the storage.
     */ async clear() {
        const storage = await this.getStorage();
        await storage.clear();
    }
}

;// CONCATENATED MODULE: ./Extension/src/background/storages/shared-instances.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 



/**
 * Storage instance for accessing `browser.storage.local`.
 */ const browserStorage = new BrowserStorage((browser_polyfill_default()).storage.local);
/**
 * Storage instance for accessing `IndexedDB` with fallback to `browser.storage.local`.
 */ const hybridStorage = new HybridStorage((browser_polyfill_default()).storage.local);
// Expose storage instances to the global scope for debugging purposes,
// because it's hard to access them from the console in the background
// page or impossible from Application tab -> IndexedDB (showing empty page).
if (false) {}

;// CONCATENATED MODULE: ./Extension/src/common/logger.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 

/**
 * Extended logger with persistent log level setting.
 * Extends the base Logger class with browser storage integration
 * for saving and retrieving log level preferences.
 */ class ExtendedLogger extends es_Logger {
    /**
     * Key for storing the current log level in browser storage.
     */ static LOG_LEVEL_LOCAL_STORAGE_KEY = 'log-level';
    /**
     * Default log level based on the build configuration.
     */ static DEFAULT_LOG_LEVEL =  true ? dist_es_LogLevel.Info : 0;
    /**
     * Checks if the current log level is verbose (Debug or Verbose).
     *
     * This method is useful for determining if detailed logging should
     * be enabled across the application in different modules. Some kind of
     * "single point of truth".
     *
     * @returns True if current log level is Debug or Verbose, false otherwise.
     */ isVerbose() {
        return this.currentLevel === dist_es_LogLevel.Debug || this.currentLevel === dist_es_LogLevel.Verbose;
    }
    /**
     * Sets log with persistent value, which will be saved, if
     * browser.storage.local is available.
     *
     * @param level Log level to set.
     */ setLogLevel(level) {
        this.currentLevel = level;
        browserStorage.set(ExtendedLogger.LOG_LEVEL_LOCAL_STORAGE_KEY, level).catch((error)=>{
            // eslint-disable-next-line max-len
            this.error('[ext.ExtendedLogger.setLogLevel]: failed to save log level in browser.storage.local: ', error);
        });
    }
    /**
     * Validates if the provided value is a valid LogLevel.
     *
     * @param value Value to validate.
     *
     * @returns {boolean} True if the value is a valid LogLevel, false otherwise.
     */ static isValidLogLevel(value) {
        return typeof value === 'string' && Object.values(dist_es_LogLevel).includes(value);
    }
    /**
     * Initializes the logger by loading the saved log level from browser storage.
     * Falls back to the default log level if retrieval fails or the stored level is invalid.
     *
     * @returns Promise that resolves when initialization is complete.
     */ async init() {
        try {
            const logLevel = await browserStorage.get(ExtendedLogger.LOG_LEVEL_LOCAL_STORAGE_KEY);
            if (!ExtendedLogger.isValidLogLevel(logLevel)) {
                // Print a warning only if the log level is valuable.
                if (logLevel !== null && logLevel !== undefined) {
                    // eslint-disable-next-line max-len
                    this.warn('[ext.ExtendedLogger.init]: log level from browser.storage.local is not valid. Value: ', logLevel);
                }
                return;
            }
            try {
                this.setLogLevel(logLevel);
            } catch (e) {
                // eslint-disable-next-line max-len
                this.warn('[ext.ExtendedLogger.init]: failed to set log level from browser.storage.local, will set to default level. Error: ', e);
                this.setLogLevel(ExtendedLogger.DEFAULT_LOG_LEVEL);
            }
        } catch (error) {
            // eslint-disable-next-line max-len
            this.warn('[ext.ExtendedLogger.init]: failed to get log level from browser.storage.local: ', error);
        }
    }
    /**
     * Creates a new instance of ExtendedLogger.
     * Initializes the logger with the default log level based on build configuration.
     */ constructor(){
        super();
        this.currentLevel = ExtendedLogger.DEFAULT_LOG_LEVEL;
    }
}
const logger_logger = new ExtendedLogger();
// Expose logger to the window object,
// to have possibility to switch log level from the console.
// Example: adguard.logger.setCurrentLevel('trace');
// eslint-disable-next-line no-restricted-globals
Object.assign(self, {
    adguard: {
        ...self.adguard,
        logger: logger_logger
    }
});


;// CONCATENATED MODULE: ./Extension/src/content-script/content-utils/message-handler.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 


class ContentScriptMessageHandler extends MessageHandler {
    /**
     * For these messages we have separate handlers in the content script,
     * provided from tswebextension.
     */ static ExcludedAssistantMessages = new Set([
        message_constants_MessageType.InitAssistant,
        message_constants_MessageType.CloseAssistant
    ]);
    /**
     * Checks if the message is internal assistant message. If it is, we should
     * not handle it in the content script.
     *
     * @param message Message to check.
     * @param message.type Type of the message.
     *
     * @returns {boolean} True if the message is internal assistant message.
     */ static isInternalAssistantMessage(message) {
        return ContentScriptMessageHandler.ExcludedAssistantMessages.has(message.type);
    }
    handleMessage(message, sender) {
        // Check type.
        if (!ContentScriptMessageHandler.isValidMessageType(message)) {
            // Do not print errors for internal assistant messages.
            if (!ContentScriptMessageHandler.isInternalAssistantMessage(message)) {
                logger_logger.error('[ext.ContentScriptMessageHandler.handleMessage]: invalid message:', message);
            }
            return;
        }
        const listener = this.listeners.get(message.type);
        if (listener) {
            return Promise.resolve(listener(message, sender));
        }
    }
}
const messageHandler = new ContentScriptMessageHandler();

;// CONCATENATED MODULE: ./Extension/src/common/messages/send-message.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 

/**
 * TODO: Consider moving this file to the background folder, because all messages
 * from the UI should be send via methods of Messenger class instead of using
 * directly sendMessage to proper types checking.
 *
 * {@link sendMessage} sends app message via {@link browser.runtime.sendMessage} and
 * gets response from another extension page message handler
 *
 * @param message - partial {@link Message} record without {@link Message.handlerName} field
 *
 * @returns message handler response
 */ async function sendMessage(message) {
    try {
        return await browser_polyfill_default().runtime.sendMessage({
            handlerName: constants_APP_MESSAGE_HANDLER_NAME,
            ...message
        });
    } catch (e) {
    // do nothing
    }
}
/**
 * {@link sendTabMessage} sends message to specified tab via {@link browser.tabs.sendMessage} and
 * gets response from it
 *
 * @param tabId - tab id
 * @param message - partial {@link Message} record without {@link Message.handlerName} field
 *
 * @returns tab message handler response
 */ async function sendTabMessage(tabId, message) {
    return browser.tabs.sendMessage(tabId, {
        handlerName: APP_MESSAGE_HANDLER_NAME,
        ...message
    });
}

;// CONCATENATED MODULE: ./Extension/src/common/messages/index.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ // Since exports from './constants' are: the MessageType enum and a lot of types,
// and imports there are types only, so it should not affect bundle size
// eslint-disable-next-line no-restricted-syntax




;// CONCATENATED MODULE: ./Extension/src/background/schema/settings/enum.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ /**
 * Separate file with only enum to exclude imports of zod to other files.
 */ var enum_SettingOption = /*#__PURE__*/ function(SettingOption) {
    // General settings.
    SettingOption["AppearanceTheme"] = "appearance-theme";
    SettingOption["DisableShowPageStats"] = "disable-show-page-statistic";
    SettingOption["DisableDetectFilters"] = "detect-filters-disabled";
    SettingOption["DisableSafebrowsing"] = "safebrowsing-disabled";
    SettingOption["FiltersUpdatePeriod"] = "filters-update-period";
    // Is filtering disabled or not.
    SettingOption["DisableFiltering"] = "adguard-disabled";
    // Extension specific settings.
    SettingOption["UseOptimizedFilters"] = "use-optimized-filters";
    SettingOption["DisableCollectHits"] = "hits-count-disabled";
    SettingOption["AllowAnonymizedUsageData"] = "allow-anonymized-usage-data";
    SettingOption["DisableShowContextMenu"] = "context-menu-disabled";
    // Flag used to show link to comparison of desktop and browser extension versions.
    SettingOption["DisableShowAdguardPromoInfo"] = "show-info-about-adguard-disabled";
    SettingOption["DisableShowAppUpdatedNotification"] = "show-app-updated-disabled";
    SettingOption["HideRateBlock"] = "hide-rate-block";
    SettingOption["UserRulesEditorWrap"] = "user-rules-editor-wrap";
    // Allowlist section.
    SettingOption["AllowlistDomains"] = "allowlist-domains";
    SettingOption["InvertedAllowlistDomains"] = "block-list-domains";
    SettingOption["AllowlistEnabled"] = "allowlist-enabled";
    SettingOption["DefaultAllowlistMode"] = "default-allowlist-mode";
    // Tracking protection (formerly Stealth mode).
    SettingOption["DisableStealthMode"] = "stealth-disable-stealth-mode";
    SettingOption["HideReferrer"] = "stealth-hide-referrer";
    SettingOption["HideSearchQueries"] = "stealth-hide-search-queries";
    SettingOption["SendDoNotTrack"] = "stealth-send-do-not-track";
    SettingOption["RemoveXClientData"] = "stealth-remove-x-client";
    SettingOption["BlockFingerprinting"] = "stealth-block-fingerprinting";
    SettingOption["BlockWebRTC"] = "stealth-block-webrtc";
    SettingOption["SelfDestructThirdPartyCookies"] = "stealth-block-third-party-cookies";
    SettingOption["SelfDestructThirdPartyCookiesTime"] = "stealth-block-third-party-cookies-time";
    SettingOption["SelfDestructFirstPartyCookies"] = "stealth-block-first-party-cookies";
    SettingOption["SelfDestructFirstPartyCookiesTime"] = "stealth-block-first-party-cookies-time";
    // Filters' statuses and states.
    SettingOption["FiltersState"] = "filters-state";
    SettingOption["FiltersVersion"] = "filters-version";
    SettingOption["GroupsState"] = "groups-state";
    SettingOption["UserFilterEnabled"] = "user-filter-enabled";
    // Filters metadata.
    SettingOption["Metadata"] = "filters-metadata";
    SettingOption["I18nMetadata"] = "filters-i18n-metadata";
    SettingOption["CustomFilters"] = "custom-filters";
    // Preserve log.
    SettingOption["PreserveLogEnabled"] = "preserve-log-enabled";
    return SettingOption;
}({});

;// CONCATENATED MODULE: ./Extension/src/content-script/content-utils/elements.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ /**
 * Max zIndex value
 * https://www.w3.org/TR/CSS21/visuren.html#z-index
 */ const MAX_Z_INDEX = '2147483647';
/**
 * Helper class for creating and injecting html elements
 */ class Elements {
    /**
     * Create style element with provided css.
     *
     * @param css - css text
     */ static createStyleElement(css) {
        const styleElement = document.createElement('style');
        styleElement.appendChild(document.createTextNode(css));
        return styleElement;
    }
    /**
     * Creates iframe and appends it after target open tag.
     *
     * @param props - {@link AppendIframeProps}
     * @param props.target - Node where to append iframe with html
     * @param props.html - html string to write inside iframe
     * @param props.styles - iframe styles text
     *
     * @returns iframe element
     */ static appendIframe({ target, html, styles }) {
        const styleElement = Elements.createStyleElement(styles);
        const prependedHtml = `${styleElement.outerHTML}\n${html}`;
        const iframe = document.createElement('iframe');
        iframe.src = 'about:blank';
        iframe.style.position = 'fixed';
        iframe.style.zIndex = MAX_Z_INDEX;
        iframe.srcdoc = prependedHtml;
        target.insertAdjacentElement('afterbegin', iframe);
        return iframe;
    }
    /**
     * Creates div and appends it to the page.
     *
     * @param props - {@link AppendDivProps}
     * @param props.target - Node where to append div with html
     * @param props.html - Html string to write inside div
     *
     * @returns div element
     */ static appendDiv({ target, html }) {
        const div = document.createElement('div');
        div.innerHTML = html;
        target.insertAdjacentElement('afterbegin', div);
        div.style.zIndex = MAX_Z_INDEX;
        return div;
    }
}

;// CONCATENATED MODULE: ./Extension/src/content-script/content-utils/alerts.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 
/**
 * Helper class for creating and injecting alerts
 */ class Alerts {
    /**
     * If {@link isAdguardTab}, append div, else we append iframe
     *
     * @param props - {@link AppendAlertElementProps}
     *
     * @returns {HTMLElement}
     */ static appendAlertElement(props) {
        const { target, html, isAdguardTab, alertStyles, alertContainerStyles } = props;
        const alertContainerElement = Elements.createStyleElement(alertContainerStyles);
        document.body.insertAdjacentElement('afterbegin', alertContainerElement);
        if (isAdguardTab) {
            return Elements.appendDiv({
                target,
                html
            });
        }
        return Elements.appendIframe({
            target,
            html,
            styles: alertStyles
        });
    }
    /**
     * Generates alert html.
     *
     * @param props - {@link GenAlertHtmlProps}
     *
     * @returns html string
     */ static genAlertHtml(props) {
        const { title, text } = props;
        let descBlock = '';
        if (text && text.length > 0) {
            descBlock = `<div class="adguard-popup-alert__desc">
                            ${text}
                        </div>`;
        }
        // don't show description text if it is same as title or if it is equal to undefined
        if (title === text || text === 'undefined') {
            descBlock = '';
        }
        let titleBlock = '';
        if (title && title.length > 0) {
            titleBlock = `<div class="adguard-popup-alert__title">
                            ${title}
                        </div>`;
        }
        return `<div class="adguard-popup-alert">
                    <div class="adguard-popup-alert__content">
                        ${titleBlock}
                        ${descBlock}
                    </div>
                    <button
                        type="button"
                        class="adguard-popup-alert__close"
                        aria-label="close"
                    ></button>
                </div>`;
    }
}

;// CONCATENATED MODULE: ./Extension/src/content-script/content-utils/popups.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 




/**
 * Helper class for creating and injecting info popups
 */ class Popups {
    static triesCount = 10;
    static ALERT_CLOSE_ANIMATION_MS = 300;
    static alertDismissTimeoutId = null;
    /**
     * Time to live for alert popup.
     */ static HIDE_TIMEOUT_MS = 1000 * 4;
    static retryTimeoutMs = 500;
    // Remove iframe after click event fire on link
    // NOTICE: if here is used value equal to 0,
    // then iframe is closed early than link is clicked
    static removeFrameTimeoutMs = 10;
    /**
     * Class of elements that close only the offer block of a popup instead of the whole iframe.
     */ static CLOSE_OFFER_CLASS = 'close-offer';
    /**
     * Space the popup iframe keeps around the popup for its box-shadow, in pixels.
     */ static POPUP_SHADOW_SPACE_PX = 16;
    /**
     * Space kept between the popup iframe and the viewport edges: the iframe
     * offsets at the top and at the bottom, see `update-container.css`.
     */ static IFRAME_VIEWPORT_SPACE_PX = 20;
    /**
     * Font of the popup design. The popup iframe belongs to the web page,
     * so the font is loaded from the extension as a web accessible resource.
     */ static ROBOTO_FLEX_FONT_PATH = '/assets/fonts/Roboto-Flex-Regular.woff2';
    /**
     * Shows alert popup.
     * Popup content is added right to the page content.
     *
     * @param message - {@link ShowAlertPopupMessage}
     * @param message.data - {@link ShowAlertPopupMessage} payload
     */ static showAlertPopup({ data }) {
        const { text, title, isAdguardTab, alertStyles, alertContainerStyles } = data;
        if (!title && !text) {
            return;
        }
        let messages = [];
        if (Array.isArray(text)) {
            messages = text;
        } else {
            messages = [
                text
            ];
        }
        let fullText = '';
        for(let i = 0; i < messages.length; i += 1){
            if (i > 0) {
                fullText += ', ';
            }
            fullText += messages[i];
        }
        const html = Alerts.genAlertHtml({
            title,
            text: fullText
        });
        Popups.appendAlertPopup(0, {
            html,
            isAdguardTab,
            alertStyles,
            alertContainerStyles
        });
    }
    /**
     * Shows version updated popup.
     * Popup content is added right to the page content.
     *
     * @param message - {@link ShowVersionUpdatedPopupMessage}
     * @param message.data - {@link ShowVersionUpdatedPopupMessage} payload
     *
     * @returns execution flag
     */ static showVersionUpdatedPopup({ data }) {
        const { title, offer, offerBgImage, description, isAdguardTab, changelogHref, changelogText, offerButtonHref, offerButtonText, showPromoNotification, disableNotificationText, alertStyles, iframeStyles } = data;
        const offerStyle = offerBgImage ? `background-image: url('${offerBgImage}')` : '';
        /* eslint-disable max-len */ const iframeHtml = `
            <div id="adguard-new-version-popup" class="adguard-update-popup adguard-update-popup--active${showPromoNotification ? ' adguard-update-popup--promo' : ''}">
                <div id="adguard-new-version-popup-close" class="adguard-update-popup__close close-iframe"></div>
                <div class="adguard-update-popup__logo"></div>
                <div class="adguard-update-popup__title">
                    ${title}
                </div>
                <div class="adguard-update-popup__desc">
                    ${description}
                </div>
                <div class="adguard-update-popup__links">
                    <a href="${changelogHref}" class="adguard-update-popup__link close-iframe" target="_blank">
                        ${changelogText}
                    </a>
                    <a href="#" class="adguard-update-popup__link adguard-update-popup__link--disable close-iframe disable-notifications">
                        ${disableNotificationText}
                    </a>
                </div>
                <div
                    class="adguard-update-popup__offer${showPromoNotification ? ' adguard-update-popup__offer--show' : ''}"
                    style="${offerStyle}"
                >
                    <div class="adguard-update-popup__offer-close close-iframe ${Popups.CLOSE_OFFER_CLASS}"></div>
                    <div class="adguard-update-popup__offer-content">
                        <div class="adguard-update-popup__offer-title">
                            ${offer}
                        </div>
                        <a href="${offerButtonHref}" class="adguard-update-popup__btn close-iframe ${Popups.CLOSE_OFFER_CLASS}${showPromoNotification ? ' adguard-update-popup__btn--promo' : ''}" target="_blank">
                            ${offerButtonText}
                        </a>
                    </div>
                </div>
            </div>
        `;
        /* eslint-enable max-len */ Popups.appendPopup(0, {
            iframeHtml,
            iframeStyles,
            iframeClassName: 'adguard-update-iframe',
            alertStyles,
            isAdguardTab,
            showPromoNotification
        });
        return true;
    }
    /**
     * Shows the popup about the migration of the Edge extension from MV2 to MV3.
     * Popup content is added right to the page content.
     *
     * @param message {@link ShowEdgeMv3MigrationPopupMessage}
     * @param message.data {@link ShowEdgeMv3MigrationPopupMessage} payload
     *
     * @returns execution flag
     */ static showEdgeMv3MigrationPopup({ data }) {
        const { isAdguardTab, title, description, userScriptsText, alertStyles, iframeStyles } = data;
        // `dir="auto"` takes the text direction from the translation, so right-to-left
        // languages keep the Latin words and the punctuation in their places.
        /* eslint-disable max-len */ const iframeHtml = `
            <div id="adguard-edge-mv3-migration-popup" class="adguard-update-popup adguard-update-popup--edge-mv3-migration">
                <div class="adguard-update-popup__close close-iframe"></div>
                <div class="adguard-update-popup__logo"></div>
                <div class="adguard-update-popup__title" dir="auto">
                    ${title}
                </div>
                <div class="adguard-update-popup__migration-desc">
                    <p dir="auto">${description}</p>
                    <p dir="auto">${userScriptsText}</p>
                </div>
            </div>
        `;
        /* eslint-enable max-len */ Popups.appendPopup(0, {
            iframeHtml,
            iframeStyles,
            iframeClassName: 'adguard-edge-mv3-migration-iframe',
            alertStyles: `${Popups.getRobotoFlexFontFace()}${alertStyles}`,
            isAdguardTab,
            showPromoNotification: false,
            onIframeInjected: (iframe)=>{
                const isListening = Popups.handleOpenExtensionDetails(iframe);
                if (!isListening) {
                    iframe.addEventListener('load', ()=>{
                        Popups.handleOpenExtensionDetails(iframe);
                    });
                }
                // The popup height depends on the length of the translation.
                const isFitted = Popups.fitIframeToPopup(iframe);
                if (!isFitted) {
                    iframe.addEventListener('load', ()=>{
                        Popups.fitIframeToPopup(iframe);
                    });
                }
            }
        });
        return true;
    }
    /**
     * Shows rules limits exceeded message.
     *
     * @param message - {@link ShowRuleLimitsAlertMessage}
     * @param message.data - {@link ShowRuleLimitsAlertMessage} payload
     *
     * @returns execution flag
     */ static showRuleLimitsAlert({ data }) {
        const { isAdguardTab, mainText, linkText, alertStyles, alertContainerStyles } = data;
        const iframeHtml = `
            <div id="adguard-rules-limits-exceeded-popup" class="adguard-rules-limits-exceeded-popup">
                <div class="adguard-rules-limits-exceeded-popup__info-icon"></div>
                <div class="adguard-rules-limits-exceeded-popup__content">
                    <p> ${mainText} </p>
                    <button id="open-rule-limits-link" type="button"> ${linkText} </button>
                </div>
                <button
                    aria-label="close"
                    type="button"
                    class="adguard-rules-limits-exceeded-popup__close close-iframe"
                ></button>
            </div>
        `;
        Popups.appendPopup(0, {
            iframeHtml,
            iframeStyles: alertContainerStyles,
            iframeClassName: 'adguard-rules-limits-exceeded-iframe',
            alertStyles,
            isAdguardTab,
            showPromoNotification: false,
            onIframeInjected: (iframe)=>{
                const isListening = Popups.handleOpenRulesLimitsPage(iframe);
                if (!isListening) {
                    iframe.addEventListener('load', ()=>{
                        Popups.handleOpenRulesLimitsPage(iframe);
                    });
                }
                // iframe should be hidden after some time
                const removeTimeout = setTimeout(()=>{
                    iframe.parentNode?.removeChild(iframe);
                }, Popups.HIDE_TIMEOUT_MS);
                /**
                 * Mouseover event listener:
                 * - clear timeout to prevent iframe from closing if user hovers over the iframe;
                 * - remove event listener after first hover.
                 */ const focusListener = ()=>{
                    clearTimeout(removeTimeout);
                    iframe.removeEventListener('mouseover', focusListener);
                };
                iframe.addEventListener('mouseover', focusListener);
            }
        });
        return true;
    }
    /**
     * Appends alert popup to page.
     *
     * @param count - try count
     * @param props - {@link AppendAlertElementProps} with omitted target property
     */ static appendAlertPopup(count, props) {
        if (count >= Popups.triesCount) {
            return;
        }
        if (document.body) {
            const existingAlert = document.body.querySelector('.adguard-alert-iframe');
            if (existingAlert instanceof HTMLIFrameElement) {
                const isAppended = Popups.appendAlertToExistingIframe(existingAlert, props.html);
                if (isAppended) {
                    Popups.scheduleAlertDismiss(existingAlert);
                    return;
                }
            }
            const alertElement = Alerts.appendAlertElement({
                ...props,
                target: document.body
            });
            alertElement.classList.add('adguard-alert-iframe');
            alertElement.onload = ()=>{
                alertElement.style.visibility = 'visible';
                if (alertElement instanceof HTMLIFrameElement) {
                    Popups.registerAlertCloseHandlers(alertElement);
                }
            };
            if (alertElement instanceof HTMLIFrameElement) {
                Popups.scheduleAlertDismiss(alertElement);
            }
        } else {
            setTimeout(()=>{
                Popups.appendAlertPopup(count + 1, props);
            }, Popups.retryTimeoutMs);
        }
    }
    /**
     * Appends a new alert into an already mounted alert iframe.
     *
     * @param iframe Existing alert iframe.
     * @param html New alert HTML.
     *
     * @returns True if alert was appended, false otherwise.
     */ static appendAlertToExistingIframe(iframe, html) {
        const iframeDocument = iframe.contentDocument || iframe.contentWindow?.document;
        if (!iframeDocument?.body) {
            return false;
        }
        const template = iframeDocument.createElement('template');
        template.innerHTML = html.trim();
        const nextAlert = template.content.firstElementChild;
        if (!nextAlert) {
            return false;
        }
        iframeDocument.body.append(nextAlert);
        iframe.style.visibility = 'visible';
        Popups.registerAlertCloseHandlers(iframe);
        return true;
    }
    /**
     * Clears currently scheduled alert dismiss timeout.
     */ static clearAlertDismissTimeout() {
        if (Popups.alertDismissTimeoutId !== null) {
            window.clearTimeout(Popups.alertDismissTimeoutId);
            Popups.alertDismissTimeoutId = null;
        }
    }
    /**
     * Schedules iframe auto-dismiss and resets previous timer when stacking alerts.
     *
     * @param iframe Alert iframe element.
     */ static scheduleAlertDismiss(iframe) {
        Popups.clearAlertDismissTimeout();
        Popups.alertDismissTimeoutId = window.setTimeout(()=>{
            if (iframe.parentNode) {
                iframe.parentNode.removeChild(iframe);
            }
            Popups.alertDismissTimeoutId = null;
        }, Popups.HIDE_TIMEOUT_MS);
    }
    /**
     * Registers close handlers for alert cards inside the alert iframe.
     *
     * @param iframe Alert iframe element.
     */ static registerAlertCloseHandlers(iframe) {
        const iframeDocument = iframe.contentDocument || iframe.contentWindow?.document;
        if (!iframeDocument) {
            return;
        }
        const closeButtons = iframeDocument.querySelectorAll('.adguard-popup-alert__close');
        closeButtons.forEach((button)=>{
            if (button.dataset.bound === 'true') {
                return;
            }
            button.dataset.bound = 'true';
            button.addEventListener('click', ()=>{
                const alertCard = button.closest('.adguard-popup-alert');
                if (!alertCard) {
                    return;
                }
                if (alertCard.classList.contains('adguard-popup-alert--closing')) {
                    return;
                }
                alertCard.classList.add('adguard-popup-alert--closing');
                window.setTimeout(()=>{
                    alertCard.remove();
                    const hasRemainingAlerts = iframeDocument.querySelector('.adguard-popup-alert');
                    if (!hasRemainingAlerts) {
                        Popups.clearAlertDismissTimeout();
                        iframe.remove();
                    }
                }, Popups.ALERT_CLOSE_ANIMATION_MS);
            });
        });
    }
    /**
     * Appends version update popup to page.
     *
     * @param count - try count
     * @param props - {@link AppendVersionUpdatedPopupProps}
     */ static appendPopup(count, props) {
        if (count >= Popups.triesCount) {
            return;
        }
        const { isAdguardTab, showPromoNotification, iframeStyles, iframeClassName, iframeHtml, alertStyles, onIframeInjected } = props;
        if (document.body && !isAdguardTab) {
            const iframeCss = Elements.createStyleElement(iframeStyles);
            document.body.insertAdjacentElement('afterbegin', iframeCss);
            const iframe = Elements.appendIframe({
                target: document.body,
                html: iframeHtml,
                styles: alertStyles
            });
            iframe.classList.add(iframeClassName);
            const isListening = Popups.handleCloseIframe(iframe, showPromoNotification);
            if (!isListening) {
                iframe.addEventListener('load', ()=>{
                    Popups.handleCloseIframe(iframe, showPromoNotification);
                });
            }
            if (onIframeInjected) {
                onIframeInjected(iframe);
            }
        } else {
            setTimeout(()=>{
                Popups.appendPopup(count + 1, props);
            }, 500);
        }
    }
    /**
     * Handle manual close of iframe popup.
     *
     * @param iframe - iframe element
     * @param showPromoNotification - notification show flag
     *
     * @returns True if registered click listener, false otherwise.
     */ static handleCloseIframe(iframe, showPromoNotification) {
        const iframeDocument = iframe.contentDocument || iframe.contentWindow?.document;
        if (!iframeDocument) {
            return false;
        }
        const closeElements = iframeDocument.querySelectorAll('.close-iframe');
        if (closeElements.length === 0) {
            return false;
        }
        closeElements.forEach((element)=>{
            element.addEventListener('click', ()=>{
                if (element.classList.contains('disable-notifications')) {
                    // disable update notifications
                    sendMessage({
                        type: constants_MessageType.ChangeUserSettings,
                        data: {
                            key: enum_SettingOption.DisableShowAppUpdatedNotification,
                            value: true
                        }
                    });
                }
                // Mark promo notification as viewed if it was shown
                if (showPromoNotification) {
                    sendMessage({
                        type: constants_MessageType.SetNotificationViewed,
                        data: {
                            withDelay: false
                        }
                    });
                }
                if (element.classList.contains(Popups.CLOSE_OFFER_CLASS)) {
                    // close only the offer block, not whole iframe
                    Popups.removeOffer(iframe, iframeDocument);
                    // Prevent closing the whole iframe
                    return;
                }
                setTimeout(()=>{
                    iframe.parentNode?.removeChild(iframe);
                }, Popups.removeFrameTimeoutMs);
            });
        });
        return true;
    }
    /**
     * Removes the offer block from a popup and shrinks the popup and its iframe to the content,
     * so the iframe does not keep empty space over the page.
     *
     * @param iframe Popup iframe.
     * @param iframeDocument Document of the popup iframe.
     */ static removeOffer(iframe, iframeDocument) {
        const offer = iframeDocument.querySelector('.adguard-update-popup__offer');
        if (!offer) {
            return;
        }
        offer.parentNode?.removeChild(offer);
        const popup = iframeDocument.querySelector('.adguard-update-popup');
        if (!popup) {
            return;
        }
        // fix height of the frame
        popup.style.minHeight = '300px';
        Popups.fitIframeToPopup(iframe);
    }
    /**
     * Returns the `@font-face` rule for the popup font, pointing to the extension resource.
     *
     * @returns CSS with the font face rule.
     */ static getRobotoFlexFontFace() {
        const url = browser_polyfill_default().runtime.getURL(Popups.ROBOTO_FLEX_FONT_PATH);
        return `@font-face {
            font-family: 'Roboto Flex';
            src: url('${url}') format('woff2');
            font-weight: 100 1000;
            font-stretch: 25% 151%;
        }\n`;
    }
    /**
     * Sets the iframe height to the height of the popup inside it, but not taller
     * than the viewport: the iframe is fixed, so a popup below the viewport edge
     * could not be reached, and it scrolls inside the iframe instead.
     *
     * @param iframe Popup iframe.
     *
     * @returns True if the popup is rendered and the iframe is fitted, false otherwise.
     */ static fitIframeToPopup(iframe) {
        const iframeDocument = iframe.contentDocument || iframe.contentWindow?.document;
        const popup = iframeDocument?.querySelector('.adguard-update-popup');
        if (!popup) {
            return false;
        }
        const height = popup.offsetHeight + Popups.POPUP_SHADOW_SPACE_PX;
        iframe.style.minHeight = `min(${height}px, calc(100vh - ${Popups.IFRAME_VIEWPORT_SPACE_PX}px))`;
        return true;
    }
    /**
     * Handles the link to the extension details page in the migration popup.
     * The link opens the page and keeps the popup.
     *
     * @param iframe Iframe element.
     *
     * @returns True if registered click listener, false otherwise.
     */ static handleOpenExtensionDetails(iframe) {
        const iframeDocument = iframe.contentDocument || iframe.contentWindow?.document;
        if (!iframeDocument) {
            return false;
        }
        const link = iframeDocument.getElementById(EDGE_MV3_MIGRATION_SETTINGS_LINK_ID);
        if (!link) {
            return false;
        }
        link.addEventListener('click', (e)=>{
            e.preventDefault();
            // The iframe is same-origin with the page, so page scripts can click the link:
            // open the extensions page only for clicks made by the user.
            if (!e.isTrusted) {
                return;
            }
            sendMessage({
                type: constants_MessageType.OpenExtensionDetailsPage
            });
        });
        return true;
    }
    /**
     * Handle open rules limits settings page.
     *
     * @param iframe - iframe element
     *
     * @returns True if registered click listener, false otherwise.
     */ static handleOpenRulesLimitsPage(iframe) {
        const iframeDocument = iframe.contentDocument || iframe.contentWindow?.document;
        if (!iframeDocument) {
            return false;
        }
        const link = iframeDocument.querySelector('#open-rule-limits-link');
        if (!link) {
            return false;
        }
        const clickHandler = ()=>{
            // Open rules limits settings page.
            sendMessage({
                type: constants_MessageType.OpenRulesLimitsTab
            });
            // After redirect to settings page, close iframe.
            const removeTimeout = setTimeout(()=>{
                iframe.parentNode?.removeChild(iframe);
                clearTimeout(removeTimeout);
            }, Popups.removeFrameTimeoutMs);
            link.removeEventListener('click', clickHandler);
        };
        link.addEventListener('click', clickHandler);
        return true;
    }
}

;// CONCATENATED MODULE: ./Extension/src/content-script/content-utils/main.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 


class ContentUtils {
    /**
     * Initializes content utils.
     *
     * IMPORTANT! It is intentionally async so it can be called without await
     * to not slow down frames loading in Firefox.
     */ static async init() {
        if (window !== window.top) {
            return;
        }
        if (!(document instanceof Document)) {
            return;
        }
        messageHandler.init();
        messageHandler.addListener(constants_MessageType.ShowAlertPopup, Popups.showAlertPopup);
        messageHandler.addListener(constants_MessageType.ShowVersionUpdatedPopup, Popups.showVersionUpdatedPopup);
        messageHandler.addListener(constants_MessageType.ShowEdgeMv3MigrationPopup, Popups.showEdgeMv3MigrationPopup);
        messageHandler.addListener(constants_MessageType.ShowRuleLimitsAlert, Popups.showRuleLimitsAlert);
    }
}

;// CONCATENATED MODULE: ./Extension/src/content-script/subscribe-to-scriptlets.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 
/**
 * Script used to subscribe to scriptlets dispatched events
 * Loaded on content script start to ensure the fastest load
 */ class SubscribeToScriptlets {
    static removeListenerTimeoutMs = 1000;
    static closeWindowEventName = 'adguard:scriptlet-close-window';
    static subscribedToCloseWindowEventName = 'adguard:subscribed-to-close-window';
    /**
     * Initializing content script.
     *
     * IMPORTANT! It is intentionally async so it can be called without await
     * to not slow down frames loading in Firefox.
     */ static async init() {
        SubscribeToScriptlets.subscribeToCloseWindow();
    }
    /**
     * Subscribe to close-window scriptlet's event
     * window.close() usage is restricted in Chrome so we use tabs API to do that
     * https://github.com/AdguardTeam/Scriptlets/issues/170
     */ static subscribeToCloseWindow() {
        // Events may be passed differently in MV3
        window.addEventListener(SubscribeToScriptlets.closeWindowEventName, SubscribeToScriptlets.closeWindowHandler);
        setTimeout(()=>{
            window.removeEventListener(SubscribeToScriptlets.closeWindowEventName, SubscribeToScriptlets.closeWindowHandler);
        }, SubscribeToScriptlets.removeListenerTimeoutMs);
        // Scriptlet is loaded first so we notify it that content script is ready
        dispatchEvent(new Event(SubscribeToScriptlets.subscribedToCloseWindowEventName));
    }
    /**
     * Send {@link MessageType.ScriptletCloseWindow} to background
     */ static closeWindowHandler() {
        sendMessage({
            type: constants_MessageType.ScriptletCloseWindow
        });
    }
}

;// CONCATENATED MODULE: ./Extension/pages/content-script-start/mv3.ts
/**
 * Copyright (c) 2015-2026 Adguard Software Ltd.
 *
 * @file
 * This file is part of AdGuard Browser Extension (https://github.com/AdguardTeam/AdguardBrowserExtension).
 *
 * AdGuard Browser Extension is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * AdGuard Browser Extension is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AdGuard Browser Extension. If not, see <http://www.gnu.org/licenses/>.
 */ 


ContentUtils.init();
SubscribeToScriptlets.init();

})();

})()
;